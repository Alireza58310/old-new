cd /opt

cat << 'EOF' > /opt/alis-fake-ssl-manager.sh
#!/bin/bash
set +e

CERT_BASE="/root/cert"
ROOT_DIR="$CERT_BASE/_rootCA"
XUI_DB="/etc/x-ui/x-ui.db"

mkdir -p "$CERT_BASE" "$ROOT_DIR"

# لیست همه دامنه‌هایی که سرتیفیکیت دارن (قدیمی‌ترین به جدیدترین)
list_domains() {
    local d
    for d in $(ls -1tr "$CERT_BASE" 2>/dev/null); do
        [ "$d" = "_rootCA" ] && continue
        [ -f "$CERT_BASE/$d/fullchain.pem" ] && echo "$d"
    done
}

ensure_root_ca() {
    if [ ! -f "$ROOT_DIR/rootCA.crt" ] || [ ! -f "$ROOT_DIR/rootCA.key" ]; then
        echo "==> Root CA not found, creating a new one (shared for all domains)..."
        openssl req -x509 -new -nodes -newkey rsa:4096 \
            -keyout "$ROOT_DIR/rootCA.key" -out "$ROOT_DIR/rootCA.crt" \
            -sha256 -days 3650 \
            -subj "/C=US/ST=State/L=City/O=Alis Root Authority/CN=Alis-Root-CA" \
            -addext "basicConstraints=critical,CA:TRUE" \
            -addext "keyUsage=critical,keyCertSign,cRLSign" 2>/dev/null
        chmod 600 "$ROOT_DIR/rootCA.key"
        chmod 644 "$ROOT_DIR/rootCA.crt"
    fi
}

pause() { read -n 1 -s -r -p "Press any key to return to menu..."; }

show_menu() {
    clear
    local domains count
    domains=$(list_domains)
    count=$(echo "$domains" | grep -c .)
    echo "=================================================="
    echo "       Alis Interactive Multi-SSL Manager         "
    echo "=================================================="
    echo " [Status]: $count domain(s) with SSL stored"
    if [ "$count" -gt 0 ]; then
        echo "$domains" | sed 's/^/    - /'
    fi
    echo "=================================================="
    echo "1) Generate SSL for a new domain (Domain + Wildcard)"
    echo "2) Deploy ALL stored domains to 3x-ui (Panel, Sub, Inbounds)"
    echo "3) List domains & certificate details"
    echo "4) Delete a domain's SSL"
    echo "5) Exit"
    echo "=================================================="
    echo -n "Please select an option [1-5]: "
}

generate_ssl() {
    echo -e "\n==> [Generate SSL]"
    read -r -p "Enter your Domain name (e.g. s.alis1.ir): " DOMAIN
    DOMAIN=$(echo "$DOMAIN" | tr 'A-Z' 'a-z' | xargs)

    if [ -z "$DOMAIN" ]; then
        echo "[X] Domain cannot be empty!"; pause; return
    fi
    if ! echo "$DOMAIN" | grep -Eq '^[a-z0-9]([a-z0-9.-]*[a-z0-9])?$'; then
        echo "[X] Invalid domain format!"; pause; return
    fi

    ensure_root_ca

    local OUT="$CERT_BASE/$DOMAIN"
    local WORK
    WORK=$(mktemp -d)
    mkdir -p "$OUT"

    echo "==> [1/3] Creating OpenSSL config (SAN: $DOMAIN + *.$DOMAIN)..."
    cat << OPENSSL_CONF > "$WORK/openssl.cnf"
[req]
default_bits       = 2048
prompt             = no
default_md         = sha256
distinguished_name = dn

[dn]
C  = US
ST = State
L  = City
O  = Development
CN = $DOMAIN
OPENSSL_CONF

    cat << EXT_CONF > "$WORK/ext.cnf"
basicConstraints = CA:FALSE
keyUsage = digitalSignature, keyEncipherment
extendedKeyUsage = serverAuth
subjectAltName = @alt_names

[alt_names]
DNS.1 = $DOMAIN
DNS.2 = *.$DOMAIN
EXT_CONF

    echo "==> [2/3] Generating private key & CSR..."
    openssl req -new -nodes -newkey rsa:2048 \
        -keyout "$OUT/privkey.pem" -out "$WORK/server.csr" \
        -config "$WORK/openssl.cnf" 2>/dev/null

    echo "==> [3/3] Signing with shared Root CA (10-year validity)..."
    openssl x509 -req -in "$WORK/server.csr" \
        -CA "$ROOT_DIR/rootCA.crt" -CAkey "$ROOT_DIR/rootCA.key" \
        -CAcreateserial -CAserial "$ROOT_DIR/rootCA.srl" \
        -out "$OUT/cert.pem" -days 3650 -sha256 \
        -extfile "$WORK/ext.cnf" 2>/dev/null

    cat "$OUT/cert.pem" "$ROOT_DIR/rootCA.crt" > "$OUT/fullchain.pem"
    cp "$ROOT_DIR/rootCA.crt" "$OUT/chain.pem"
    cp "$ROOT_DIR/rootCA.crt" "$OUT/rootCA.crt"
    chmod 644 "$OUT"/*.pem "$OUT"/rootCA.crt
    chmod 600 "$OUT/privkey.pem"
    rm -rf "$WORK"

    if [ -s "$OUT/fullchain.pem" ] && [ -s "$OUT/privkey.pem" ]; then
        echo -e "\n[✓] SSL for $DOMAIN generated and stored."
        echo "    Directory: $OUT/"
        echo "    Root CA (install on clients once): $ROOT_DIR/rootCA.crt"
    else
        echo -e "\n[X] Something went wrong while generating SSL for $DOMAIN."
    fi
    pause
}

deploy_all() {
    echo -e "\n==> [Deploy ALL stored domains to 3x-ui]"
    local DOMAINS
    DOMAINS=$(list_domains | tr '\n' ' ')
    if [ -z "$(echo $DOMAINS)" ]; then
        echo "[!] No SSL stored yet! Please run Option 1 first."; pause; return
    fi

    echo "Stored domains:"
    local i=1 arr=() d
    for d in $DOMAINS; do echo "  $i) $d"; arr+=("$d"); i=$((i+1)); done
    local LAST="${arr[$((${#arr[@]}-1))]}"

    read -r -p "Which domain for Panel & Subscription? [number, Enter = $LAST]: " PICK
    local PANEL_DOMAIN="$LAST"
    if [[ "$PICK" =~ ^[0-9]+$ ]] && [ "$PICK" -ge 1 ] && [ "$PICK" -le "${#arr[@]}" ]; then
        PANEL_DOMAIN="${arr[$((PICK-1))]}"
    fi

    local FULLCHAIN="$CERT_BASE/$PANEL_DOMAIN/fullchain.pem"
    local KEY="$CERT_BASE/$PANEL_DOMAIN/privkey.pem"

    echo "==> [1/3] Panel & Subscription SSL -> $PANEL_DOMAIN"
    x-ui setting -webCert "$FULLCHAIN" -webKey "$KEY" 2>/dev/null || true
    x-ui setting -subCert "$FULLCHAIN" -subKey "$KEY" 2>/dev/null || true

    echo "==> [2/3] Adding ALL domains' certificates to TLS inbounds..."
    if [ -f "$XUI_DB" ] && command -v python3 >/dev/null 2>&1; then
        cp "$XUI_DB" "$XUI_DB.bak.$(date +%Y%m%d-%H%M%S)"
        CERT_BASE="$CERT_BASE" DOMAINS="$DOMAINS" XUI_DB="$XUI_DB" python3 - << 'PYEOF'
import sqlite3, json, os
base = os.environ["CERT_BASE"]
domains = os.environ["DOMAINS"].split()
db = os.environ["XUI_DB"]
certs = [{"certificateFile": f"{base}/{d}/fullchain.pem",
          "keyFile": f"{base}/{d}/privkey.pem"} for d in domains]
con = sqlite3.connect(db)
cur = con.cursor()
n = 0
for iid, s in cur.execute("select id, stream_settings from inbounds").fetchall():
    try:
        ss = json.loads(s)
    except Exception:
        continue
    if ss.get("security") == "tls":
        ss.setdefault("tlsSettings", {})["certificates"] = certs
        cur.execute("update inbounds set stream_settings=? where id=?",
                    (json.dumps(ss, indent=2), iid))
        n += 1
con.commit()
con.close()
print(f"    Updated {n} TLS inbound(s) with {len(certs)} certificate(s).")
PYEOF
    else
        echo "    [!] x-ui database or python3 not found, skipping inbounds."
    fi

    echo "==> [3/3] Restarting 3x-ui service..."
    x-ui restart 2>/dev/null || systemctl restart 3x-ui 2>/dev/null || systemctl restart x-ui 2>/dev/null || true

    echo -e "\n[✓] SUCCESS! Deployed ${#arr[@]} domain(s):"
    for d in $DOMAINS; do echo "    - $d"; done
    echo "[INF] Panel/Sub domain: $PANEL_DOMAIN"
    pause
}

list_details() {
    echo -e "\n==> [Stored certificates]"
    local d
    for d in $(list_domains); do
        echo "--------------------------------------------------"
        echo " Domain : $d"
        echo " Path   : $CERT_BASE/$d/"
        openssl x509 -in "$CERT_BASE/$d/cert.pem" -noout -enddate 2>/dev/null | sed 's/^/ /'
    done
    echo "--------------------------------------------------"
    echo " Root CA: $ROOT_DIR/rootCA.crt"
    pause
}

delete_domain() {
    echo -e "\n==> [Delete a domain's SSL]"
    read -r -p "Domain to delete: " DEL
    DEL=$(echo "$DEL" | tr 'A-Z' 'a-z' | xargs)
    if [ -z "$DEL" ] || [ "$DEL" = "_rootCA" ] || [ ! -d "$CERT_BASE/$DEL" ]; then
        echo "[X] Domain not found."; pause; return
    fi
    read -r -p "Delete $DEL permanently? [y/N]: " YN
    if [ "$YN" = "y" ] || [ "$YN" = "Y" ]; then
        rm -rf "$CERT_BASE/$DEL"
        echo "[✓] Deleted. (Run option 2 again to refresh 3x-ui.)"
    else
        echo "Cancelled."
    fi
    pause
}

while true; do
    show_menu
    read -r CHOICE
    case $CHOICE in
        1) generate_ssl ;;
        2) deploy_all ;;
        3) list_details ;;
        4) delete_domain ;;
        5) echo -e "\nExiting SSL Manager. Have a great time!"; exit 0 ;;
        *) echo "[!] Invalid option."; sleep 1 ;;
    esac
done
EOF

chmod +x /opt/alis-fake-ssl-manager.sh
/opt/alis-fake-ssl-manager.sh