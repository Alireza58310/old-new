Cd /opt

# ساخت پوشه‌های مورد نیاز در ریشه مسیر
mkdir -p subs 3x sslfr sslback mizback

cat << 'EOF' > /opt/alis-installer.sh
#!/bin/bash

# غیرفعال کردن توقف ناگهانی برای مدیریت راحت‌تر منو
set +e

# تنظیمات عدم دخالت اعلان‌های سیستم در اوبونتو ۲۴
export DEBIAN_FRONTEND=noninteractive
export NEEDRESTART_MODE=a

manage_sub_themes() {
    while true; do
        clear
        echo "========================================="
        echo "    Sub Themes Manager (MiTemplateSub)   "
        echo "========================================="
        echo "1) Install Dependencies & Theme Manager"
        echo "2) Launch Neotemplate Menu (Select / Change Theme)"
        echo "3) Show Sub Theme Directories & Config Guide"
        echo "4) Back to Main Menu"
        echo "========================================="
        echo -n "Please select an option [1-4]: "
        read -r SUB_CHOICE
        case $SUB_CHOICE in
            1)
                echo "==> [Sub-Theme] Installing prerequisites (unzip, jq)..."
                apt-get update -y
                apt-get install -y unzip jq
                echo "==> Downloading and running MiTemplateSub installer..."
                bash <(curl -Ls https://raw.githubusercontent.com/MrV2R/MiTemplateSub-XUI/main/theme-manager/install.sh)
                echo -e "\n[✓] Theme Manager installed successfully! Command 'neotemplate' is now active."
                read -n 1 -s -r -p "Press any key to continue..."
                ;;
            2)
                if command -v neotemplate >/dev/null 2>&1; then
                    neotemplate
                else
                    echo -e "\n[!] 'neotemplate' is not installed yet! Please run Option 1 first."
                fi
                read -n 1 -s -r -p "Press any key to continue..."
                ;;
            3)
                echo -e "\n========================================="
                echo "       3x-ui Sub Theme Paths Guide       "
                echo "========================================="
                echo "Default Sub Templates Directory:"
                echo " -> /etc/3x-ui/sub_templates/"
                echo ""
                echo "Example Theme Path (Signal Theme):"
                echo " -> /etc/3x-ui/sub_templates/mi-signal/"
                echo ""
                echo "How to apply in 3x-ui Panel:"
                echo "1. Copy the path of your active theme."
                echo "2. Open 3x-ui -> Panel Settings -> Subscription -> Profile."
                echo "3. Paste the path into 'Sub Theme Directory' and Save."
                echo "4. Restart Panel: x-ui restart"
                echo "========================================="
                read -n 1 -s -r -p "Press any key to continue..."
                ;;
            4)
                break
                ;;
            *)
                echo "[!] Invalid option. Please select between 1 and 4."
                sleep 1
                ;;
        esac
    done
}

show_menu() {
    clear
    echo "========================================="
    echo "    Alis Modular Installer (Ubuntu 24)   "
    echo "========================================="
    echo "1) Update, Create Folders & System Upgrade"
    echo "2) Configure Root and SSH Users & Passwords"
    echo "3) Configure DNS (Google / Cloudflare / Anti-Sanction)"
    echo "4) Restore Official Ubuntu Repositories"
    echo "5) Compile and Configure BadVPN (UDP Gateway)"
    echo "6) Disable UFW Firewall & Install 3x-ui Panel"
    echo "7) Manage 3x-ui Subscription Themes (MiTemplateSub)"
    echo "8) Exit Installer"
    echo "========================================="
    echo -n "Please select an option [1-8]: "
}

while true; do
    show_menu
    read -r CHOICE
    case $CHOICE in
        1)
            echo "==> [B1] Running Update, Folder Check & Upgrades..."
            # رفع توقیف قفل‌های احتمالی apt
            systemctl stop unattended-upgrades 2>/dev/null || true
            systemctl stop apt-daily.service 2>/dev/null || true
            systemctl stop apt-daily-upgrade.service 2>/dev/null || true
            
            while fuser /var/lib/dpkg/lock-frontend >/dev/null 2>&1; do
                echo "Waiting for apt lock..."
                sleep 5
            done
            
            dpkg --configure -a || true
            
            apt-get update -y
            apt-get upgrade -y -o Dpkg::Options::="--force-confnew" -o Dpkg::Options::="--force-confdef"
            
            echo "==> Installing basic packages..."
            apt-get install -y curl wget git unzip nano sudo cmake make gcc g++ build-essential net-tools ufw fail2ban ca-certificates expect python3 python3-pip lsof openssh-server

            # اطمینان از باز بودن پورت SSH در فایروال قبل از هرکاری
            ufw allow 22/tcp 2>/dev/null || true
            
            echo -e "\n[✓] Section 1 completed successfully!"
            read -n 1 -s -r -p "Press any key to return to menu..."
            ;;
        2)
            echo "==> [B2] Configuring Users and Passwords..."
            # تنظیم پسورد روت
            echo "root:alirezapoland" | chpasswd
            echo "[+] Root password updated."
            
            # ساخت و تنظیم یوزر alisssh با شل معتبر
            if ! id "alisssh" >/dev/null 2>&1; then
                useradd -m -s /bin/bash alisssh
            else
                usermod -s /bin/bash alisssh
            fi
            echo "alisssh:alirezaossh" | chpasswd
            echo "[+] User 'alisssh' configured."
            
            # ساخت و تنظیم یوزر runssh با شل معتبر
            if ! id "runssh" >/dev/null 2>&1; then
                useradd -m -s /bin/bash runssh
            else
                usermod -s /bin/bash runssh
            fi
            echo "runssh:runnerssh" | chpasswd
            echo "[+] User 'runssh' configured."

            # اصلاح تنظیمات SSH برای جلوگیری از قطع دسترسی
            sed -i 's/^#*PermitRootLogin.*/PermitRootLogin yes/' /etc/ssh/sshd_config
            sed -i 's/^#*PasswordAuthentication.*/PasswordAuthentication yes/' /etc/ssh/sshd_config
            
            # در اوبونتو ۲۴ کانفیگ‌های جدید SSH در sshd_config.d قرار دارند
            if [ -d "/etc/ssh/sshd_config.d" ]; then
                echo "PermitRootLogin yes" > /etc/ssh/sshd_config.d/50-cloud-init.conf
                echo "PasswordAuthentication yes" >> /etc/ssh/sshd_config.d/50-cloud-init.conf
            fi

            systemctl restart ssh || systemctl restart sshd || true
            echo "[+] SSH service reconfigured and restarted safely."
            
            echo -e "\n[✓] Section 2 completed successfully!"
            read -n 1 -s -r -p "Press any key to return to menu..."
            ;;
        3)
            echo "==> [B3] Configuring DNS Servers..."
            echo "-----------------------------------------"
            echo "Select DNS Mode:"
            echo "1) Google DNS (8.8.8.8 / 8.8.4.4)"
            echo "2) Cloudflare DNS (1.1.1.1 / 1.0.0.1)"
            echo "3) Anti-Sanction / Shecan (178.22.122.100 / 185.51.200.2)"
            echo "4) Reset to System Default"
            echo "-----------------------------------------"
            echo -n "Choose an option [1-4]: "
            read -r DNS_CHOICE
            
            # آن‌لاک کردن resolv.conf در صورت داشتن ویژگی immutable قبلی
            chattr -i /etc/resolv.conf 2>/dev/null || true
            rm -f /etc/resolv.conf 2>/dev/null
            
            case $DNS_CHOICE in
                1)
                    echo -e "nameserver 8.8.8.8\nnameserver 8.8.4.4" > /etc/resolv.conf
                    echo "[+] Google DNS configured successfully."
                    ;;
                2)
                    echo -e "nameserver 1.1.1.1\nnameserver 1.0.0.1" > /etc/resolv.conf
                    echo "[+] Cloudflare DNS configured successfully."
                    ;;
                3)
                    echo -e "nameserver 178.22.122.100\nnameserver 185.51.200.2" > /etc/resolv.conf
                    echo "[+] Anti-Sanction (Shecan) DNS configured (Useful for bypassing foreign blocks on Iran server)."
                    ;;
                4)
                    echo -e "nameserver 9.9.9.9\nnameserver 1.1.1.1" > /etc/resolv.conf
                    echo "[+] Reset to default Quad9 / Cloudflare DNS."
                    ;;
                *)
                    echo "[!] Invalid choice. Skipping DNS configuration."
                    ;;
            esac

            # قفل کردن فایل برای جلوگیری از اوررایت شدن توسط کارت شبکه دیتاسنتر بدون غیرفعال کردن شبکه
            chattr +i /etc/resolv.conf 2>/dev/null || true
            
            echo -e "\n[✓] Section 3 completed successfully!"
            read -n 1 -s -r -p "Press any key to return to menu..."
            ;;
        4)
            echo "==> [B4] Setting Official Ubuntu 24.04 Repositories..."
            
            # پشتیبان‌گیری از فایل‌های اصلی مخازن
            cp /etc/apt/sources.list /etc/apt/sources.list.bak 2>/dev/null || true
            
            # بازنویسی مخازن به سرورهای رسمی اصلی اوبونتو (Noble Numbat)
            cat << 'REPO_EOF' > /etc/apt/sources.list
deb http://archive.ubuntu.com/ubuntu/ noble main restricted universe multiverse
deb http://archive.ubuntu.com/ubuntu/ noble-updates main restricted universe multiverse
deb http://archive.ubuntu.com/ubuntu/ noble-backports main restricted universe multiverse
deb http://security.ubuntu.com/ubuntu noble-security main restricted universe multiverse
REPO_EOF

            # به روزرسانی اختصاصی ساختار جدید DEB822 اوبونتو ۲۴
            if [ -f "/etc/apt/sources.list.d/ubuntu.sources" ]; then
                cp /etc/apt/sources.list.d/ubuntu.sources /etc/apt/sources.list.d/ubuntu.sources.bak 2>/dev/null || true
                cat << 'DEB822_EOF' > /etc/apt/sources.list.d/ubuntu.sources
Types: deb
URIs: http://archive.ubuntu.com/ubuntu/
Suites: noble noble-updates noble-backports
Components: main restricted universe multiverse
Signed-By: /usr/share/keyrings/ubuntu-archive-keyring.gpg

Types: deb
URIs: http://security.ubuntu.com/ubuntu/
Suites: noble-security
Components: main restricted universe multiverse
Signed-By: /usr/share/keyrings/ubuntu-archive-keyring.gpg
DEB822_EOF
            fi

            echo "[+] Repositories successfully reset to official Ubuntu servers."
            apt-get update -y
            
            echo -e "\n[✓] Section 4 completed successfully!"
            read -n 1 -s -r -p "Press any key to return to menu..."
            ;;
        5)
            echo "==> [B5] Compiling and Launching BadVPN..."
            rm -rf /root/badvpn
            git clone https://github.com/ambrop72/badvpn.git /root/badvpn
            
            # اصلاح فایل تنظیمات کامپایلر برای اوبونتو 24
            sed -i 's/cmake_minimum_required(VERSION 2.8)/cmake_minimum_required(VERSION 3.5)/' /root/badvpn/CMakeLists.txt
            
            mkdir -p /root/badvpn/build && cd /root/badvpn/build
            cmake .. -DCMAKE_POLICY_VERSION_MINIMUM=3.5 -DBUILD_NOTHING_BY_DEFAULT=1 -DBUILD_UDPGW=1
            make -j$(nproc)
            
            cp udpgw/badvpn-udpgw /usr/local/bin/
            chmod +x /usr/local/bin/badvpn-udpgw
            
            # ایجاد سرویس سیستم‌دی برای ربات badvpn
            cat > /etc/systemd/system/badvpn.service << 'INNER_EOF'
[Unit]
Description=BadVPN UDP Gateway
After=network.target

[Service]
Type=simple
User=root
ExecStart=/usr/local/bin/badvpn-udpgw --listen-addr 127.0.0.1:7300 --max-clients 1000 --max-connections-for-client 100
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
INNER_EOF

            systemctl daemon-reload
            systemctl enable badvpn
            systemctl restart badvpn
            
            echo "[+] BadVPN service is up and running."
            echo -e "\n[✓] Section 5 completed successfully!"
            read -n 1 -s -r -p "Press any key to return to menu..."
            ;;
        6)
            echo "==> [B6] Disabling Firewall & Installing 3x-ui Panel..."
            # ریست و غیرفعال کردن کامل فایروال بدون مسدودسازی
            ufw --force reset || true
            ufw disable || true
            
            # اجرای اسکریپت نصب آسان پنل 3x-ui بدون عملیات اضافه بعد از آن
            mkdir -p /opt/3x && cd /opt/3x
            printf "1\ny\n2083\n\n\n" | bash <(curl -Ls https://raw.githubusercontent.com/mhsanaei/3x-ui/master/install.sh)
            
            echo -e "\n[✓] Section 6 completed successfully!"
            read -n 1 -s -r -p "Press any key to return to menu..."
            ;;
        7)
            manage_sub_themes
            ;;
        8)
            echo "Exiting Alis Installer. Have a good one!"
            exit 0
            ;;
        *)
            echo "[!] Invalid option. Please select between 1 and 8."
            sleep 2
            ;;
    esac
done
EOF

# دادن دسترسی و اجرای مستقیم اسکریپت منودار جدید
chmod +x /opt/alis-installer.sh
/opt/alis-installer.sh
