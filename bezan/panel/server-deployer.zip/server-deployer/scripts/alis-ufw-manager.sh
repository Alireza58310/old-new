cat << 'EOF' > /opt/alis-ufw-manager.sh
#!/bin/bash

# Prevent script from exiting unexpectedly
set +e

# Function to safely collect ports/ranges
get_ports() {
    # Redirecting prompts to stderr (>&2) so they don't corrupt the captured stdout variable
    echo "=========================================" >&2
    echo "Please enter the ports (one entry per line)." >&2
    echo "Format: Single port (e.g., 80) or range (e.g., 2000-3000)." >&2
    echo "Type 'END' and press Enter when finished:" >&2
    echo "-----------------------------------------" >&2
    
    local PORTS_LIST=""
    while true; do
        read -r INPUT
        # Clean trailing/leading spaces
        local CLEAN_INPUT
        CLEAN_INPUT=$(echo "$INPUT" | xargs)
        
        # Check for exit word (case-insensitive)
        if [ "${CLEAN_INPUT,,}" == "end" ]; then
            break
        fi
        
        if [ -n "$CLEAN_INPUT" ]; then
            # Convert '-' to ':' for standard UFW range compliance
            local FORMATTED_PORT
            FORMATTED_PORT=$(echo "$CLEAN_INPUT" | sed 's/-/:/g')
            
            # Regex validation: Only allow numbers or number:number (ranges)
            if [[ "$FORMATTED_PORT" =~ ^[0-9]+(:[0-9]+)?$ ]]; then
                PORTS_LIST="$PORTS_LIST $FORMATTED_PORT"
            else
                echo "  [!] Invalid format: '$CLEAN_INPUT' ignored. Use numbers or ranges only." >&2
            fi
        fi
    done
    # Output only the validated ports to stdout
    echo "$PORTS_LIST"
}

while true; do
    clear
    echo "========================================="
    echo "    Alis UFW Advanced Manager            "
    echo "========================================="
    echo "1) Install & Enable UFW (Auto-opens SSH)"
    echo "2) Open Ports / Ranges (TCP)"
    echo "3) Open Ports / Ranges (UDP)"
    echo "4) Open Ports / Ranges (Both TCP & UDP)"
    echo "5) View Firewall Status (Numbered)"
    echo "6) Exit"
    echo "-----------------------------------------"
    read -p "Select an option (1-6): " OPTION

    case $OPTION in
        1)
            echo "==> Installing and configuring UFW..."
            if command -v apt-get &> /dev/null; then
                apt-get update -y && apt-get install ufw -y
            elif command -v dnf &> /dev/null; then
                dnf install ufw -y
            elif command -v yum &> /dev/null; then
                yum install ufw -y
            else
                echo "[!] Package manager not found. Please install UFW manually."
                read -p "Press Enter to continue..." temp
                continue
            fi
            
            # Open SSH port to prevent locking yourself out
            ufw allow 22/tcp comment 'SSH Access'
            ufw --force enable
            echo "[✓] UFW enabled successfully. SSH port (22/tcp) is open."
            ;;
        2)
            MY_PORTS=$(get_ports)
            for p in $MY_PORTS; do
                if ufw allow "$p"/tcp; then
                    echo "[✓] Port/Range $p/tcp opened."
                fi
            done
            ufw reload &>/dev/null
            ;;
        3)
            MY_PORTS=$(get_ports)
            for p in $MY_PORTS; do
                if ufw allow "$p"/udp; then
                    echo "[✓] Port/Range $p/udp opened."
                fi
            done
            ufw reload &>/dev/null
            ;;
        4)
            MY_PORTS=$(get_ports)
            for p in $MY_PORTS; do
                # UFW requires protocol for ranges, so we apply both explicitly
                if ufw allow "$p"/tcp && ufw allow "$p"/udp; then
                    echo "[✓] Port/Range $p (TCP/UDP) opened."
                fi
            done
            ufw reload &>/dev/null
            ;;
        5)
            echo "========================================="
            ufw status numbered
            echo "========================================="
            ;;
        6)
            echo "Exiting... Goodbye!"
            exit 0
            ;;
        *)
            echo "[!] Invalid option. Please enter a number between 1 and 6."
            ;;
    esac
    echo ""
    read -p "Press Enter to return to the menu..." temp
done
EOF

chmod +x /opt/alis-ufw-manager.sh
/opt/alis-ufw-manager.sh
