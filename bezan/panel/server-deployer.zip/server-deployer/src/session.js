import { connect } from 'cloudflare:sockets';
import { SSH } from './ssh.js';
import SCRIPT_INSTALLER from '../scripts/alis-installer.sh';
import SCRIPT_UFW from '../scripts/alis-ufw-manager.sh';
import SCRIPT_FAKESSL from '../scripts/alis-fake-ssl-manager.sh';

const PANEL_PORTS = [22,47,80,346,428,440,441,442,443,444,445,446,447,448,449,450,451,452,453,454,455,456,457,458,459,460,461,462,463,464,465,466,467,468,469,470,471,472,473,474,475,476,477,478,479,480,481,482,483,484,485,486,487,488,489,490,491,492,493,494,495,496,497,498,499,500,501,502,503,504,505,506,507,508,509,510,1087,2053,2083,2095,2096,2097,2098,2100,2101,2102,2104,2110,2121,8000,62050,62051,62052,62053];
const DOMAINS = ['a.nami1.ir','b.nami1.ir','c.nami1.ir','vip.nami1.ir','didin.nami1.ir','vbnm.nami1.ir'];
const PANEL_DB_RAW_URL = 'https://raw.githubusercontent.com/Alireza58310/old-new/main/bezan/panel/x-ui.db';
const PS1_MARK = '###WRKRDY###';

function rid(n = 10) { const c = 'abcdefghijklmnopqrstuvwxyz0123456789'; let s = ''; for (let i = 0; i < n; i++) s += c[Math.floor(Math.random() * c.length)]; return s; }

export class SessionDO {
  constructor(state, env) {
    this.state = state; this.env = env;
    this.log = ''; this.sockets = new Set();
    this.status = 'idle'; // idle | connecting | running | need_input | waiting_db_upload | done | error
    this.detail = 'Waiting for connection details.';
    this.result = null; this.dbFile = null; this.ssh = null; this.manualMode = false;
    this.state.blockConcurrencyWhile(async () => {
      const saved = await this.state.storage.get(['log', 'status', 'detail', 'result']);
      if (saved.get('log')) this.log = saved.get('log');
      if (saved.get('status')) this.status = saved.get('status');
      if (saved.get('detail')) this.detail = saved.get('detail');
      if (saved.get('result')) this.result = saved.get('result');
    });
  }

  async persist() { await this.state.storage.put({ log: this.log.slice(-400000), status: this.status, detail: this.detail, result: this.result }); }

  broadcast(obj) { const msg = JSON.stringify(obj); for (const ws of this.sockets) { try { ws.send(msg); } catch (e) {} } }

  appendLog(s) { this.log += s; this.broadcast({ t: 'log', d: s }); }
  setDetail(s) { this.detail = s; this.broadcast({ t: 'detail', d: s }); this.persist(); }
  setStatus(s) { this.status = s; this.broadcast({ t: 'status', d: s }); this.persist(); }

  async fetch(request) {
    const url = new URL(request.url);
    if (url.pathname.endsWith('/ws')) return this.handleWs(request);
    if (url.pathname.endsWith('/start') && request.method === 'POST') return this.handleStart(request);
    if (url.pathname.endsWith('/input') && request.method === 'POST') return this.handleInput(request);
    if (url.pathname.endsWith('/upload-db') && request.method === 'POST') return this.handleUploadDb(request);
    if (url.pathname.endsWith('/state')) return new Response(JSON.stringify({ status: this.status, detail: this.detail, log: this.log, result: this.result, hasDb: !!this.dbFile }), { headers: { 'content-type': 'application/json' } });
    if (url.pathname.endsWith('/result.txt')) return new Response(this.result || 'Not finished yet.', { headers: { 'content-type': 'text/plain; charset=utf-8' } });
    return new Response('not found', { status: 404 });
  }

  async handleWs(request) {
    const pair = new WebSocketPair(); const [client, server] = Object.values(pair);
    server.accept(); this.sockets.add(server);
    server.send(JSON.stringify({ t: 'snapshot', status: this.status, detail: this.detail, log: this.log, result: this.result }));
    server.addEventListener('message', async (ev) => {
      try { const m = JSON.parse(ev.data); if (m.t === 'raw' && this.ssh && !this.ssh.closed) { this.manualMode = true; await this.ssh.write(m.d); } } catch (e) {}
    });
    server.addEventListener('close', () => this.sockets.delete(server));
    return new Response(null, { status: 101, webSocket: client });
  }

  async handleUploadDb(request) {
    const buf = await request.arrayBuffer();
    this.dbFile = new Uint8Array(buf);
    await this.state.storage.put('dbFileLen', this.dbFile.length);
    // store in chunks (DO storage values capped); keep in-memory for this session's lifetime, also persist as base64 split
    const b64 = btoa(String.fromCharCode(...this.dbFile));
    for (let i = 0; i < b64.length; i += 100000) await this.state.storage.put('dbb64_' + (i / 100000), b64.slice(i, i + 100000));
    await this.state.storage.put('dbb64_chunks', Math.ceil(b64.length / 100000));
    return new Response(JSON.stringify({ ok: true, bytes: this.dbFile.length }), { headers: { 'content-type': 'application/json' } });
  }

  async loadDbFromStorage() {
    if (this.dbFile) return this.dbFile;
    const n = await this.state.storage.get('dbb64_chunks'); if (!n) return null;
    let b64 = ''; for (let i = 0; i < n; i++) b64 += (await this.state.storage.get('dbb64_' + (i * 100000))) || '';
    if (!b64) return null;
    const bin = atob(b64); const arr = new Uint8Array(bin.length); for (let i = 0; i < bin.length; i++) arr[i] = bin.charCodeAt(i);
    this.dbFile = arr; return arr;
  }

  async handleInput(request) {
    const { data } = await request.json();
    if (this.ssh && !this.ssh.closed) { this.manualMode = true; await this.ssh.write(data); }
    return new Response('ok');
  }

  async handleStart(request) {
    if (this.status === 'running' || this.status === 'connecting') return new Response(JSON.stringify({ error: 'already running' }), { status: 409 });
    const body = await request.json();
    const { host, port, user, password } = body;
    if (!host || !user || !password) return new Response(JSON.stringify({ error: 'missing fields' }), { status: 400 });
    this.log = ''; this.result = null; this.manualMode = false;
    this.setStatus('connecting'); this.setDetail('Opening TCP connection to ' + host + ':' + (port || 22) + ' ...');
    // run in background; survives client disconnect because the DO itself keeps the promise alive via waitUntil-like behavior:
    // Durable Objects stay active while they have pending work, independent of any attached WebSocket/HTTP client.
    this.state.waitUntil ? this.state.waitUntil(this.runAutomation(host, port || 22, user, password)) : this.runAutomation(host, port || 22, user, password);
    return new Response(JSON.stringify({ ok: true }));
  }

  async waitFor(markers, timeoutMs, { onChunk } = {}) {
    const arr = Array.isArray(markers) ? markers : [markers];
    const start = this.buf?.length || 0;
    const deadline = Date.now() + timeoutMs;
    for (;;) {
      for (const m of arr) {
        const idx = this.buf.indexOf(m, Math.max(0, start - m.length));
        if (idx !== -1) return { marker: m, idx };
      }
      if (Date.now() > deadline) return null;
      await new Promise(r => setTimeout(r, 150));
    }
  }

  async runAutomation(host, port, user, password) {
    this.buf = '';
    try {
      const sock = connect({ hostname: host, port: Number(port) });
      const ssh = new SSH(sock); this.ssh = ssh;
      ssh.onData = (chunk) => { this.buf += chunk; this.appendLog(chunk); };
      ssh.onClose = (err) => {
        if (this.status !== 'done' && this.status !== 'error') {
          this.setDetail(err ? ('Connection closed: ' + err.message) : 'Connection closed by remote host.');
          this.setStatus(this.result ? 'done' : 'error');
        }
      };
      this.setDetail('Authenticating as ' + user + ' ...');
      await ssh.connect({ user, password, cols: 200, rows: 50 });
      this.setStatus('running');
      this.setDetail('Connected. Normalizing shell prompt...');
      await ssh.write(`stty -echo 2>/dev/null; export PS1='\\n${PS1_MARK}\\n'; export TERM=xterm; echo READY_${PS1_MARK}\n`);
      await this.waitFor('READY_' + PS1_MARK, 15000);

      await this.runScriptA(ssh);
      await this.runScriptB(ssh);
      await this.runScriptC(ssh);
      await this.checkXuiAndRestore(ssh);

      this.setStatus('done');
      this.setDetail('All steps completed. Result file is ready below.');
    } catch (e) {
      this.setDetail('Automation stopped: ' + (e && e.message ? e.message : String(e)) + '. The console is still live — you can continue manually.');
      this.setStatus('error');
    }
  }

  async shellCmd(ssh, cmd, waitMarker = PS1_MARK, timeout = 20000) {
    await ssh.write(cmd + '\n');
    const r = await this.waitFor(waitMarker, timeout);
    if (!r) throw new Error('Timed out waiting for: ' + cmd);
    return r;
  }

  async uploadHeredoc(ssh, remotePath, content) {
    const token = 'WRKUP_' + rid(12);
    await ssh.write(`cat > ${remotePath} << '${token}'\n`);
    // send in modest chunks to avoid overwhelming the channel
    for (let i = 0; i < content.length; i += 4000) { await ssh.write(content.slice(i, i + 4000)); await new Promise(r => setTimeout(r, 30)); }
    await ssh.write(`\n${token}\n`);
    await ssh.write(`chmod +x ${remotePath}\necho UPLOADED_${token}\n`);
    const r = await this.waitFor('UPLOADED_' + token, 30000);
    if (!r) throw new Error('Failed to upload ' + remotePath);
  }

  async runScriptA(ssh) {
    this.setDetail('Uploading & running alis-installer.sh ...');
    await this.uploadHeredoc(ssh, '/root/alis-installer.sh', SCRIPT_INSTALLER);
    await ssh.write('bash /root/alis-installer.sh\n');
    await this.waitFor('Please select an option [1-8]:', 20000);

    this.setDetail('Step 2/12: Configuring root & SSH users...');
    await ssh.write('2\n');
    await this.waitFor('Press any key to return to menu...', 60000);
    await ssh.write(' ');
    await this.waitFor('Please select an option [1-8]:', 15000);

    this.setDetail('Step 3/12: Setting DNS to Google (8.8.8.8/8.8.4.4)...');
    await ssh.write('3\n');
    await this.waitFor('Choose an option [1-4]:', 10000);
    await ssh.write('1\n');
    await this.waitFor('Press any key to return to menu...', 20000);
    await ssh.write(' ');
    await this.waitFor('Please select an option [1-8]:', 15000);

    this.setDetail('Step 4/12: Restoring official Ubuntu repositories...');
    await ssh.write('4\n');
    await this.waitFor('Press any key to return to menu...', 60000);
    await ssh.write(' ');
    await this.waitFor('Please select an option [1-8]:', 15000);

    this.setDetail('Step 5/12: Disabling UFW & installing 3x-ui panel (this can take a few minutes)...');
    const beforeLen = this.buf.length;
    await ssh.write('6\n');
    await this.waitFor('Press any key to return to menu...', 10 * 60 * 1000);
    const installOutput = this.buf.slice(beforeLen);
    this.panel = this.parsePanelOutput(installOutput);
    if (this.panel) this.setDetail('3x-ui installed — Access URL: ' + this.panel.url);
    await ssh.write(' ');
    await this.waitFor('Please select an option [1-8]:', 15000);

    await ssh.write('8\n');
    await this.waitFor(PS1_MARK, 15000);
  }

  parsePanelOutput(text) {
    const get = (re) => { const m = text.match(re); return m ? m[1].trim() : null; };
    const username = get(/Username:\s*(\S+)/);
    const password = get(/Password:\s*(\S+)/);
    const port = get(/Port:\s*(\S+)/);
    const base = get(/WebBasePath:\s*(\S+)/);
    const url = get(/Access URL:\s*(\S+)/);
    const token = get(/API Token:\s*(\S+)/);
    if (!username || !password || !url) return null;
    return { username, password, port, base, url, token };
  }

  async runScriptB(ssh) {
    this.setDetail('Step 6/12: Uploading & running alis-ufw-manager.sh ...');
    await this.uploadHeredoc(ssh, '/root/alis-ufw-manager.sh', SCRIPT_UFW);
    await ssh.write('bash /root/alis-ufw-manager.sh\n');
    await this.waitFor('Select an option (1-6):', 15000);

    this.setDetail('Step 7/12: Installing & enabling UFW...');
    await ssh.write('1\n');
    await this.waitFor('Press Enter to return to the menu...', 30000);
    await ssh.write('\n');
    await this.waitFor('Select an option (1-6):', 15000);

    this.setDetail('Step 7b/12: Opening the required TCP port list...');
    await ssh.write('2\n');
    await this.waitFor("Type 'END' and press Enter when finished:", 10000);
    for (const p of PANEL_PORTS) await ssh.write(p + '\n');
    await ssh.write('END\n');
    await this.waitFor('Press Enter to return to the menu...', 30000);
    await ssh.write('\n');
    await this.waitFor('Select an option (1-6):', 15000);

    await ssh.write('6\n');
    await this.waitFor(PS1_MARK, 15000);
  }

  async runScriptC(ssh) {
    this.setDetail('Step 9/12: Uploading & running alis-fake-ssl-manager.sh ...');
    await this.uploadHeredoc(ssh, '/root/alis-fake-ssl-manager.sh', SCRIPT_FAKESSL);
    await ssh.write('bash /root/alis-fake-ssl-manager.sh\n');
    await this.waitFor('Please select an option [1-5]:', 15000);

    for (const d of DOMAINS) {
      this.setDetail('Step 10/12: Generating SSL for ' + d + ' ...');
      await ssh.write('1\n');
      await this.waitFor('Enter your Domain name', 10000);
      await ssh.write(d + '\n');
      const r = await this.waitFor(['Press any key to return to menu...'], 30000);
      if (!r) { this.setDetail('Warning: SSL generation for ' + d + ' did not finish as expected — check console.'); }
      await ssh.write(' ');
      await this.waitFor('Please select an option [1-5]:', 15000);
    }

    this.setDetail('Step 11/12: Deploying all domains to 3x-ui (Panel, Sub, Inbounds)...');
    await ssh.write('2\n');
    const pick = await this.waitFor(['Which domain for Panel & Subscription?', 'Please select an option [1-5]:'], 10000);
    if (pick && pick.marker.startsWith('Which domain')) {
      await ssh.write('\n'); // accept default (last domain)
      await this.waitFor('Press any key to return to menu...', 60000);
      await ssh.write(' ');
      await this.waitFor('Please select an option [1-5]:', 15000);
    }

    await ssh.write('5\n');
    await this.waitFor(PS1_MARK, 15000);
  }

  async checkXuiAndRestore(ssh) {
    if (!this.panel) { this.setDetail('Could not read panel credentials automatically — check the console and finish the remaining steps manually.'); this.setStatus('need_input'); return; }

    // open the panel port in ufw just in case (the earlier big list already includes most common ports, but ensure the actual one is open)
    if (this.panel.port) {
      this.setDetail('Ensuring panel port ' + this.panel.port + ' is open in UFW...');
      await this.shellCmd(ssh, `ufw allow ${this.panel.port}/tcp`, PS1_MARK, 15000).catch(() => {});
    }

    // fetch the backup db — either user-uploaded, or from the GitHub repo
    this.setDetail('Preparing panel database backup file...');
    const db = await this.loadDbFromStorage();
    let dbBytes = db;
    if (!dbBytes) {
      try {
        const resp = await fetch(PANEL_DB_RAW_URL);
        if (resp.ok) dbBytes = new Uint8Array(await resp.arrayBuffer());
      } catch (e) {}
    }

    if (dbBytes && this.env.BROWSER) {
      await this.restoreViaBrowser(dbBytes).catch((e) => {
        this.setDetail('Automatic panel restore failed (' + e.message + '). Log in manually at ' + this.panel.url + ' and restore the backup yourself, then continue.');
      });
    } else if (!this.env.BROWSER) {
      this.setDetail('Browser Rendering binding is not configured — skipping automatic panel restore. See README to enable it, or restore the backup manually at ' + this.panel.url + '.');
    } else {
      this.setDetail('No backup .db file available (upload one or ensure the GitHub repo is reachable) — skipping automatic restore.');
    }

    this.setDetail('Step 12/12: Setting panel SSL cert path via the x-ui menu...');
    await ssh.write('x-ui\n');
    const menu = await this.waitFor(['Please choose an option', 'Please enter'], 15000);
    if (menu) {
      await ssh.write('20\n');
      await this.waitFor(['Please choose', 'Please enter'], 10000);
      await ssh.write('5\n');
      await this.waitFor(['Please choose', 'Please enter'], 10000);
      await ssh.write('1\n');
      await this.waitFor(['domain', 'Domain'], 10000);
      await ssh.write('a.nami1.ir\n');
      await this.waitFor(PS1_MARK, 20000).catch(() => {});

      await ssh.write('x-ui\n');
      await this.waitFor(['Please choose', 'Please enter'], 15000);
      const before = this.buf.length;
      await ssh.write('11\n');
      await this.waitFor(['Please choose', 'Please enter'], 10000);
      const settings = this.buf.slice(before);
      const portMatch = settings.match(/Port:\s*(\d+)/);
      if (portMatch && portMatch[1] !== '2083') {
        this.setDetail('Panel port is ' + portMatch[1] + ', changing it to 2083...');
        await ssh.write('10\n');
        await this.waitFor(['port', 'Port'], 10000);
        await ssh.write('2083\n');
        await this.waitFor(['Please choose', 'Please enter'], 15000);
      }
      await ssh.write('0\n');
      await this.waitFor(PS1_MARK, 10000).catch(() => {});
    } else {
      this.setDetail('Could not reliably detect the x-ui menu prompts — please run `x-ui`, option 20 → 5 → 1 → a.nami1.ir, and option 11 to verify/fix the port, manually in the console.');
    }

    this.result = this.buildResultText();
    await this.persist();
  }

  async restoreViaBrowser(dbBytes) {
    const puppeteer = await import('@cloudflare/puppeteer');
    const browser = await puppeteer.launch(this.env.BROWSER);
    try {
      const page = await browser.newPage();
      await page.setBypassCSP(true);
      const client = await page.target().createCDPSession().catch(() => null);
      if (client) await client.send('Security.setIgnoreCertificateErrors', { ignore: true }).catch(() => {});
      await page.goto(this.panel.url, { waitUntil: 'networkidle0', timeout: 30000 });
      await this.loginIfNeeded(page);
      await this.clickByText(page, ['Backup & Restore', 'Backup', 'backup']);
      await page.waitForTimeout(800);
      await this.clickByText(page, ['Restore', 'restore']);
      await page.waitForTimeout(500);
      const input = await page.$('input[type=file]');
      if (!input) throw new Error('could not find the file upload control');
      // Puppeteer needs a readable file path; write the db to a data URL via setInputFiles is not supported on raw bytes,
      // so we use the CDP DOM.setFileInputFiles equivalent via uploadFile with a Blob trick:
      await page.evaluate((b64) => {
        const bin = atob(b64); const arr = new Uint8Array(bin.length);
        for (let i = 0; i < bin.length; i++) arr[i] = bin.charCodeAt(i);
        const file = new File([arr], 'x-ui.db', { type: 'application/octet-stream' });
        const dt = new DataTransfer(); dt.items.add(file);
        const inp = document.querySelector('input[type=file]');
        inp.files = dt.files;
        inp.dispatchEvent(new Event('change', { bubbles: true }));
      }, btoa(String.fromCharCode(...dbBytes)));
      await page.waitForTimeout(1500);
      await this.clickByText(page, ['Upload', 'Confirm', 'OK', 'Restore']);
      await page.waitForTimeout(3000);
      this.setDetail('Panel database restored from backup.');
    } finally {
      await browser.close().catch(() => {});
    }
  }

  async loginIfNeeded(page) {
    const userSel = await page.$('input[placeholder*="sername" i], input[name="username"]');
    if (!userSel) return;
    await userSel.type(this.panel.username, { delay: 20 });
    const passSel = await page.$('input[type=password]');
    if (passSel) await passSel.type(this.panel.password, { delay: 20 });
    await this.clickByText(page, ['Login', 'Sign in', 'ورود']);
    await page.waitForTimeout(1500);
  }

  async clickByText(page, candidates) {
    const handle = await page.evaluateHandle((cands) => {
      const all = Array.from(document.querySelectorAll('button, a, div, span, li'));
      for (const c of cands) {
        const el = all.find(e => e.children.length === 0 && e.textContent && e.textContent.trim().toLowerCase().includes(c.toLowerCase()));
        if (el) return el;
      }
      return null;
    }, candidates);
    const el = handle.asElement();
    if (el) { await el.click(); return true; }
    return false;
  }

  buildResultText() {
    const p = this.panel || {};
    return [
      '=== Server ===',
      `Status: automation finished`,
      '',
      '=== 3x-ui Panel ===',
      `Username:    ${p.username || '?'}`,
      `Password:    ${p.password || '?'}`,
      `Port:        ${p.port || '?'}`,
      `WebBasePath: ${p.base || '?'}`,
      `Access URL:  ${p.url || '?'}`,
      `API Token:   ${p.token || '?'}`,
      '',
      '=== TLS domains ===',
      ...DOMAINS.map(d => ' - ' + d),
      '',
      'Panel cert path set to: a.nami1.ir (via x-ui > 20 > 5 > 1)',
      '',
      'Generated by the automation worker.',
    ].join('\n');
  }
}
