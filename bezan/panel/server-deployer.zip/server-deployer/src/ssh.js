// ===== Minimal SSH2 client (curve25519-sha256, aes128-ctr, hmac-sha2-256, password auth) =====
const te = new TextEncoder(), td = new TextDecoder();
const cat = (...a) => { let n = a.reduce((s, x) => s + x.length, 0), o = new Uint8Array(n), p = 0; for (const x of a) { o.set(x, p); p += x.length; } return o; };
const u32 = n => new Uint8Array([n >>> 24, n >>> 16 & 255, n >>> 8 & 255, n & 255]);
const str = s => { const b = typeof s === 'string' ? te.encode(s) : s; return cat(u32(b.length), b); };
const mpint = b => { let i = 0; while (i < b.length && b[i] === 0) i++; b = b.slice(i); if (b.length && b[0] & 128) b = cat(new Uint8Array([0]), b); return str(b); };
const rd = (b) => { let p = 0; return { u8: () => b[p++], u32: () => { const v = (b[p] * 16777216) + (b[p + 1] << 16) + (b[p + 2] << 8) + b[p + 3]; p += 4; return v; }, str: function () { const l = this.u32(); const v = b.slice(p, p + l); p += l; return v; }, rest: () => b.slice(p) }; };
const S = crypto.subtle;
const sha256 = async d => new Uint8Array(await S.digest('SHA-256', d));

export class SSH {
  constructor(sock) { this.sock = sock; this.w = sock.writable.getWriter(); this.r = sock.readable.getReader(); this.buf = new Uint8Array(0); this.sin = 0; this.sout = 0; this.enc = null; this.onData = null; this.closed = false; this.chan = { remote: 0, win: 0, max: 32768 }; }
  async fill(n) { while (this.buf.length < n) { const { value, done } = await this.r.read(); if (done) throw new Error('connection closed'); this.buf = cat(this.buf, value); } }
  async readLine() { for (;;) { const i = this.buf.indexOf(10); if (i >= 0) { const l = td.decode(this.buf.slice(0, i)).replace(/\r$/, ''); this.buf = this.buf.slice(i + 1); return l; } await this.fill(this.buf.length + 1); } }
  async ctr(st, data) { const out = new Uint8Array(await S.encrypt({ name: 'AES-CTR', counter: st.ctr, length: 128 }, st.key, data)); let c = 0n; for (const x of st.ctr) c = (c << 8n) | BigInt(x); c = (c + BigInt(data.length / 16)) & ((1n << 128n) - 1n); const n = new Uint8Array(16); for (let i = 15; i >= 0; i--) { n[i] = Number(c & 255n); c >>= 8n; } st.ctr = n; return out; }
  async mac(key, seq, d) { return new Uint8Array(await S.sign('HMAC', key, cat(u32(seq), d))); }
  async send(payload) {
    const bs = this.enc ? 16 : 8; let pad = bs - ((5 + payload.length) % bs); if (pad < 4) pad += bs;
    const rnd = crypto.getRandomValues(new Uint8Array(pad));
    let pkt = cat(u32(1 + payload.length + pad), new Uint8Array([pad]), payload, rnd);
    if (this.enc) { const m = await this.mac(this.enc.mac, this.sout, pkt); pkt = cat(await this.ctr(this.enc.c, pkt), m); }
    this.sout = (this.sout + 1) >>> 0; await this.w.write(pkt);
  }
  async recv() {
    let pl;
    if (!this.enc) { await this.fill(5); const len = rd(this.buf).u32(); await this.fill(4 + len); const pad = this.buf[4]; pl = this.buf.slice(5, 4 + len - pad); this.buf = this.buf.slice(4 + len); }
    else {
      await this.fill(16); const first = await this.ctr(this.enc.s, this.buf.slice(0, 16)); const len = rd(first).u32(); if (len > 262144) throw new Error('bad packet');
      const total = 4 + len; await this.fill(total + 32);
      const rest = total > 16 ? await this.ctr(this.enc.s, this.buf.slice(16, total)) : new Uint8Array(0);
      const pkt = cat(first, rest); const mac = this.buf.slice(total, total + 32); const exp = await this.mac(this.enc.smac, this.sin, pkt);
      if (mac.some((x, i) => x !== exp[i])) throw new Error('MAC mismatch');
      this.buf = this.buf.slice(total + 32); const pad = pkt[4]; pl = pkt.slice(5, total - pad);
    }
    this.sin = (this.sin + 1) >>> 0; return pl;
  }
  async nextMsg() { for (;;) { const p = await this.recv(); const t = p[0]; if (t === 2 || t === 4 || t === 53) continue; if (t === 1) throw new Error('server disconnect: ' + td.decode(rd(p.slice(5)).str())); return p; } }
  async connect({ user, password, cols = 120, rows = 30 }) {
    const vc = 'SSH-2.0-WorkerSSH_1.0'; await this.w.write(te.encode(vc + '\r\n'));
    let vs; for (let i = 0; i < 50; i++) { vs = await this.readLine(); if (vs.startsWith('SSH-')) break; } if (!vs || !vs.startsWith('SSH-')) throw new Error('not an SSH server');
    const kiList = ['curve25519-sha256,curve25519-sha256@libssh.org', 'ssh-ed25519,rsa-sha2-256,rsa-sha2-512,ecdsa-sha2-nistp256', 'aes128-ctr', 'aes128-ctr', 'hmac-sha2-256', 'hmac-sha2-256', 'none', 'none', '', ''];
    const ki = cat(new Uint8Array([20]), crypto.getRandomValues(new Uint8Array(16)), ...kiList.map(str), new Uint8Array([0]), u32(0));
    await this.send(ki); const sk = await this.nextMsg(); if (sk[0] !== 20) throw new Error('expected KEXINIT');
    const kp = await S.generateKey({ name: 'X25519' }, true, ['deriveBits']); const qc = new Uint8Array(await S.exportKey('raw', kp.publicKey));
    await this.send(cat(new Uint8Array([30]), str(qc)));
    const rep = await this.nextMsg(); if (rep[0] !== 31) throw new Error('kex failed (type ' + rep[0] + ')');
    const rr = rd(rep.slice(1)); const ks = rr.str(), qs = rr.str();
    const pub = await S.importKey('raw', qs, { name: 'X25519' }, true, []); const K = new Uint8Array(await S.deriveBits({ name: 'X25519', public: pub }, kp.privateKey, 256));
    const H = await sha256(cat(str(vc), str(vs), str(ki), str(sk), str(ks), str(qc), str(qs), mpint(K)));
    this.sid = H; const kk = mpint(K);
    const dk = async (ch) => sha256(cat(kk, H, te.encode(ch), H));
    await this.send(new Uint8Array([21])); const nk = await this.nextMsg(); if (nk[0] !== 21) throw new Error('expected NEWKEYS');
    const [iv1, iv2, e1, e2, m1, m2] = await Promise.all(['A', 'B', 'C', 'D', 'E', 'F'].map(dk));
    const hk = k => S.importKey('raw', k, { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']);
    const ak = k => S.importKey('raw', k.slice(0, 16), { name: 'AES-CTR' }, false, ['encrypt']);
    this.enc = { c: { key: await ak(e1), ctr: iv1.slice(0, 16) }, s: { key: await ak(e2), ctr: iv2.slice(0, 16) }, mac: await hk(m1), smac: await hk(m2) };
    await this.send(cat(new Uint8Array([5]), str('ssh-userauth'))); const sa = await this.nextMsg(); if (sa[0] !== 6) throw new Error('service refused');
    await this.send(cat(new Uint8Array([50]), str(user), str('ssh-connection'), str('password'), new Uint8Array([0]), str(password)));
    for (;;) { const m = await this.nextMsg(); if (m[0] === 52) break; if (m[0] === 51) throw new Error('authentication failed (allowed: ' + td.decode(rd(m.slice(1)).str()) + ')'); }
    await this.send(cat(new Uint8Array([90]), str('session'), u32(0), u32(2097152), u32(32768)));
    for (;;) { const m = await this.nextMsg(); if (m[0] === 91) { const x = rd(m.slice(1)); x.u32(); this.chan.remote = x.u32(); this.chan.win = x.u32(); this.chan.max = x.u32(); break; } if (m[0] === 92) throw new Error('channel open refused'); }
    await this.send(cat(new Uint8Array([98]), u32(this.chan.remote), str('pty-req'), new Uint8Array([0]), str('xterm-256color'), u32(cols), u32(rows), u32(0), u32(0), str('')));
    await this.send(cat(new Uint8Array([98]), u32(this.chan.remote), str('shell'), new Uint8Array([0])));
    this.pump();
  }
  async pump() {
    this.localWin = 2097152;
    try {
      for (;;) {
        const m = await this.recv(); const t = m[0];
        if (t === 94 || t === 95) { const x = rd(m.slice(1)); x.u32(); if (t === 95) x.u32(); const d = x.str(); this.localWin -= d.length; if (this.onData) this.onData(td.decode(d, { stream: true })); if (this.localWin < 1048576) { this.localWin += 1048576; await this.send(cat(new Uint8Array([93]), u32(this.chan.remote), u32(1048576))); } }
        else if (t === 93) { const x = rd(m.slice(1)); x.u32(); this.chan.win += x.u32(); }
        else if (t === 80) { const x = rd(m.slice(1)); x.str(); if (x.u8()) await this.send(new Uint8Array([82])); }
        else if (t === 96 || t === 97) { if (t === 97) break; }
        else if (t === 1) break;
      }
    } catch (e) { this.err = e; }
    this.closed = true; if (this.onClose) this.onClose(this.err);
  }
  async write(s) { if (this.closed) throw new Error('connection closed'); const b = typeof s === 'string' ? te.encode(s) : s; for (let i = 0; i < b.length; i += 16384) await this.send(cat(new Uint8Array([94]), u32(this.chan.remote), str(b.slice(i, i + 16384)))); }
  async close() { this.closed = true; try { await this.send(cat(new Uint8Array([97]), u32(this.chan.remote))); } catch (e) {} try { await this.sock.close(); } catch (e) {} }
}
