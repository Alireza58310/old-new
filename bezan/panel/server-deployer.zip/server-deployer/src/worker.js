import { SessionDO } from './session.js';
export { SessionDO };

function html() {
  return `<!doctype html>
<html lang="fa" dir="rtl">
<head>
<meta charset="utf-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1"/>
<title>Server Deployer</title>
<link rel="stylesheet" href="https://unpkg.com/xterm@5.3.0/css/xterm.css"/>
<script src="https://unpkg.com/xterm@5.3.0/lib/xterm.js"></script>
<script src="https://unpkg.com/xterm-addon-fit@0.8.0/lib/xterm-addon-fit.js"></script>
<style>
  :root{--bg:#0b0f14;--panel:#121820;--border:#232c37;--text:#e6edf3;--accent:#3b82f6;--ok:#22c55e;--err:#ef4444;--muted:#8b98a5}
  *{box-sizing:border-box}
  body{margin:0;background:var(--bg);color:var(--text);font-family:'Segoe UI',Tahoma,sans-serif;min-height:100vh;display:flex;flex-direction:column;align-items:center;padding:24px 12px}
  .wrap{width:100%;max-width:920px;display:flex;flex-direction:column;gap:16px}
  h1{font-size:20px;margin:0 0 4px}
  .card{background:var(--panel);border:1px solid var(--border);border-radius:14px;padding:18px}
  label{display:block;font-size:13px;color:var(--muted);margin:10px 0 4px}
  input{width:100%;padding:10px 12px;border-radius:8px;border:1px solid var(--border);background:#0e141b;color:var(--text);font-size:14px}
  .row{display:flex;gap:10px}
  .row>div{flex:1}
  button{cursor:pointer;border:none;border-radius:8px;padding:11px 18px;font-size:14px;font-weight:600}
  .btn-primary{background:var(--accent);color:#fff;width:100%;margin-top:14px}
  .btn-secondary{background:#1c2834;color:var(--text);border:1px solid var(--border)}
  .status{display:flex;align-items:center;gap:8px;font-size:13px;color:var(--muted)}
  .dot{width:9px;height:9px;border-radius:50%;background:var(--muted)}
  .dot.running{background:var(--accent);animation:pulse 1.2s infinite}
  .dot.done{background:var(--ok)}
  .dot.error{background:var(--err)}
  @keyframes pulse{0%,100%{opacity:1}50%{opacity:.3}}
  #termWrap{height:min(60vh,520px);border-radius:10px;overflow:hidden;background:#000;border:1px solid var(--border);padding:6px}
  #term{width:100%;height:100%}
  #term .xterm-viewport{-webkit-overflow-scrolling:touch;touch-action:pan-y;scrollbar-width:thin}
  #term .xterm-viewport::-webkit-scrollbar{width:12px}
  #term .xterm-viewport::-webkit-scrollbar-thumb{background:#3f4a5a;border-radius:6px}
  #term .xterm-screen{touch-action:pan-y}
  .ctrlRow{display:flex;flex-wrap:wrap;gap:6px;margin-top:8px}
  .ctrlRow button{flex:1 1 auto;min-width:54px;padding:8px 6px;font-size:12px;font-family:monospace;background:#1c2834;color:var(--text);border:1px solid var(--border)}
  .consoleInput{display:flex;gap:8px;margin-top:10px}
  .consoleInput input{flex:1;font-family:monospace}
  .detail{font-size:13.5px;line-height:1.7;white-space:pre-wrap}
  .hidden{display:none !important}
  .pill{display:inline-block;background:#1c2834;border:1px solid var(--border);border-radius:999px;padding:2px 10px;font-size:11.5px;color:var(--muted);margin-inline-start:8px}
  a.dl{color:var(--accent);text-decoration:none;font-size:13.5px}
  textarea{width:100%;min-height:220px;background:#0e141b;color:var(--text);border:1px solid var(--border);border-radius:8px;padding:10px;font-family:monospace;font-size:12.5px;line-height:1.6}
  .resultActions{display:flex;gap:10px;align-items:center;margin-top:8px;flex-wrap:wrap}
  .btn-exit{background:#3a1414;color:#ff8080;border:1px solid #5c1f1f;width:100%;margin-top:10px}
</style>
</head>
<body>
<div class="wrap">
  <h1>Server Deployer <span class="pill" id="sidPill"></span></h1>

  <div class="card" id="formCard">
    <div class="row">
      <div><label>IP Address</label><input id="host" placeholder="1.2.3.4"/></div>
      <div style="max-width:110px"><label>Port</label><input id="port" value="22"/></div>
    </div>
    <div class="row">
      <div><label>Username</label><input id="user" value="root"/></div>
      <div><label>Password</label><input id="pass" type="password"/></div>
    </div>
    <label>Optional: pre-upload x-ui.db backup (used for Backup &amp; Restore later; if skipped, the worker tries the GitHub copy automatically)</label>
    <input id="dbfile" type="file" accept=".db"/>
    <button class="btn-primary" id="startBtn">Connect &amp; Start</button>
  </div>

  <div class="card hidden" id="runCard">
    <div class="status"><span class="dot" id="statusDot"></span><span id="statusText">idle</span></div>
    <div id="termWrap"><div id="term"></div></div>
    <div class="ctrlRow">
      <button data-send="\\u0003">Ctrl+C</button>
      <button data-send="\\u0004">Ctrl+D</button>
      <button data-send="\\u001a">Ctrl+Z</button>
      <button data-send="\\t">Tab</button>
      <button data-send="\\u001b">Esc</button>
      <button data-send="\\r">Enter</button>
      <button data-send="\\u001b[A">↑</button>
      <button data-send="\\u001b[B">↓</button>
      <button data-send="\\u001b[D">←</button>
      <button data-send="\\u001b[C">→</button>
    </div>
    <div class="ctrlRow">
      <button id="scrollTopBtn" type="button">⤒ شروع</button>
      <button id="pgUpBtn" type="button">PgUp</button>
      <button id="pgDnBtn" type="button">PgDn</button>
      <button id="scrollBotBtn" type="button">⤓ پایان</button>
      <button id="copyTermBtn" type="button">کپی کنسول</button>
    </div>
    <div class="consoleInput">
      <input id="cmdInput" placeholder="Type a command and press Enter / Send (also works as a full line)"/>
      <button class="btn-secondary" id="sendBtn">Send</button>
    </div>
    <button class="btn-exit" id="exitBtn">Disconnect / Exit now</button>
  </div>

  <div class="card hidden" id="newSessionCard" style="text-align:center">
    <p class="detail" style="margin-bottom:10px">این Session تموم شده. برای یه دیپلوی جدید (سرور دیگه یا دوباره):</p>
    <button class="btn-primary" id="newSessionBtn" style="margin-top:0">شروع Session جدید</button>
  </div>

  <div class="card hidden" id="detailCard">
    <label style="margin-top:0">Progress / Details</label>
    <div class="detail" id="detailText">—</div>
    <div id="resultBox" class="hidden" style="margin-top:12px">
      <label>Result</label>
      <textarea id="resultText" readonly></textarea>
      <div class="resultActions">
        <a class="dl" id="dlLink" download="server-result.txt">Download result.txt</a>
        <button class="btn-secondary" id="copyBtn" type="button">Copy all</button>
      </div>
    </div>
  </div>
</div>

<script>
const qs = new URLSearchParams(location.search);
let sid = qs.get('s');
if (!sid) { sid = Math.random().toString(36).slice(2) + Date.now().toString(36); history.replaceState(null, '', '?s=' + sid); }
document.getElementById('sidPill').textContent = 'session: ' + sid;

const formCard = document.getElementById('formCard');
const runCard = document.getElementById('runCard');
const detailCard = document.getElementById('detailCard');
const statusDot = document.getElementById('statusDot');
const statusText = document.getElementById('statusText');
const detailText = document.getElementById('detailText');
const resultBox = document.getElementById('resultBox');
const resultText = document.getElementById('resultText');
const dlLink = document.getElementById('dlLink');

let term = new Terminal({ convertEol: true, fontSize: 13, scrollback: 8000, theme: { background: '#000000' }, copyOnSelect: true });
const fitAddon = new FitAddon.FitAddon();
term.loadAddon(fitAddon);
term.open(document.getElementById('term'));
fitAddon.fit();
window.addEventListener('resize', () => fitAddon.fit());
document.getElementById('termWrap').addEventListener('click', () => term.focus());
term.focus();

function lock(locked) {
  formCard.classList.toggle('hidden', locked);
  runCard.classList.toggle('hidden', !locked);
  detailCard.classList.toggle('hidden', !locked);
}

const newSessionCard = document.getElementById('newSessionCard');
function setStatus(s) {
  statusText.textContent = s;
  statusDot.className = 'dot ' + (s === 'running' || s === 'connecting' ? 'running' : s === 'done' ? 'done' : s === 'error' ? 'error' : '');
  const finished = s === 'done' || s === 'error' || s === 'closed';
  newSessionCard.classList.toggle('hidden', !finished);
}
document.getElementById('newSessionBtn').onclick = () => {
  const newSid = Math.random().toString(36).slice(2) + Date.now().toString(36);
  location.href = location.pathname + '?s=' + newSid;
};

function setResult(r) {
  if (!r) { resultBox.classList.add('hidden'); return; }
  resultBox.classList.remove('hidden');
  resultText.value = r;
  const blob = new Blob([r], { type: 'text/plain' });
  dlLink.href = URL.createObjectURL(blob);
}

let ws;
function connectWs() {
  ws = new WebSocket((location.protocol === 'https:' ? 'wss://' : 'ws://') + location.host + '/session/' + sid + '/ws');
  ws.onmessage = (ev) => {
    const m = JSON.parse(ev.data);
    if (m.t === 'snapshot') {
      if (m.status && m.status !== 'idle') lock(true);
      setStatus(m.status || 'idle');
      detailText.textContent = m.detail || '—';
      if (m.log) term.write(m.log);
      if (m.result) setResult(m.result);
    } else if (m.t === 'log') { term.write(m.d); }
    else if (m.t === 'detail') { detailText.textContent = m.d; }
    else if (m.t === 'status') { setStatus(m.d); if (m.d !== 'idle') lock(true); }
  };
  ws.onclose = () => setTimeout(connectWs, 2000);
}
connectWs();

term.onData((data) => { if (ws && ws.readyState === 1) ws.send(JSON.stringify({ t: 'raw', d: data })); });

function decodeEscapes(s) {
  return s.replace(/\\\\u([0-9a-fA-F]{4})/g, (_, h) => String.fromCharCode(parseInt(h, 16)))
          .replace(/\\\\t/g, '\\t').replace(/\\\\r/g, '\\r');
}
document.querySelectorAll('.ctrlRow [data-send]').forEach((btn) => {
  btn.addEventListener('click', () => {
    term.focus();
    if (ws && ws.readyState === 1) ws.send(JSON.stringify({ t: 'raw', d: decodeEscapes(btn.dataset.send) }));
  });
});

document.getElementById('scrollTopBtn').onclick = () => term.scrollToTop();
document.getElementById('scrollBotBtn').onclick = () => term.scrollToBottom();
document.getElementById('pgUpBtn').onclick = () => term.scrollLines(-Math.max(1, term.rows - 2));
document.getElementById('pgDnBtn').onclick = () => term.scrollLines(Math.max(1, term.rows - 2));
document.getElementById('copyTermBtn').onclick = async () => {
  term.selectAll();
  const text = term.getSelection();
  term.clearSelection();
  try { await navigator.clipboard.writeText(text); }
  catch (e) {
    const ta = document.createElement('textarea');
    ta.value = text; ta.style.position = 'fixed'; ta.style.opacity = '0';
    document.body.appendChild(ta); ta.select(); document.execCommand('copy'); document.body.removeChild(ta);
  }
};

document.getElementById('exitBtn').onclick = async () => {
  if (!confirm('اتصال به سرور قطع شود؟')) return;
  const btn = document.getElementById('exitBtn');
  btn.disabled = true; btn.textContent = 'در حال قطع کردن...';
  try {
    const r = await fetch('/session/' + sid + '/exit', { method: 'POST' });
    if (!r.ok) throw new Error('HTTP ' + r.status);
    setStatus('closed');
    detailText.textContent = 'اتصال قطع شد — برای یه دیپلوی جدید از دکمه‌ی پایین استفاده کن.';
  } catch (e) {
    alert('قطع کردن ناموفق بود: ' + e.message + ' — دوباره امتحان کن.');
  } finally {
    btn.disabled = false; btn.textContent = 'Disconnect / Exit now';
  }
};

document.getElementById('copyBtn').onclick = async () => {
  try { await navigator.clipboard.writeText(resultText.value); }
  catch (e) { resultText.select(); document.execCommand('copy'); }
};

document.getElementById('sendBtn').onclick = sendCmd;
document.getElementById('cmdInput').addEventListener('keydown', (e) => { if (e.key === 'Enter') sendCmd(); });
function sendCmd() {
  const el = document.getElementById('cmdInput');
  if (ws && ws.readyState === 1 && el.value) { ws.send(JSON.stringify({ t: 'raw', d: el.value + '\\n' })); el.value = ''; }
}

document.getElementById('startBtn').onclick = async () => {
  const host = document.getElementById('host').value.trim();
  const port = document.getElementById('port').value.trim() || '22';
  const user = document.getElementById('user').value.trim() || 'root';
  const pass = document.getElementById('pass').value;
  if (!host || !pass) { alert('IP و رمز عبور را وارد کنید'); return; }
  const dbf = document.getElementById('dbfile').files[0];
  if (dbf) {
    const buf = await dbf.arrayBuffer();
    await fetch('/session/' + sid + '/upload-db', { method: 'POST', body: buf });
  }
  lock(true);
  await fetch('/session/' + sid + '/start', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ host, port, user, password: pass }) });
};

// resume state on load in case the socket snapshot is missed
fetch('/session/' + sid + '/state').then(r => r.json()).then(s => {
  if (s.status && s.status !== 'idle') { lock(true); setStatus(s.status); detailText.textContent = s.detail || '—'; if (s.result) setResult(s.result); }
});
</script>
</body>
</html>`;
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    const m = url.pathname.match(/^\/session\/([a-z0-9]+)\/(.*)$/);
    if (m) {
      const id = env.SESSIONS.idFromName(m[1]);
      const stub = env.SESSIONS.get(id);
      const sub = new URL(request.url); sub.pathname = '/' + m[2];
      return stub.fetch(new Request(sub, request));
    }
    if (url.pathname === '/' || url.pathname === '') {
      return new Response(html(), { headers: { 'content-type': 'text/html; charset=utf-8' } });
    }
    return new Response('not found', { status: 404 });
  },
};
