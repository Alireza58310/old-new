<?php
require_once __DIR__ . '/lib/session.php';

define('DATA_DIR', __DIR__ . '/data');
if (!is_dir(DATA_DIR)) { @mkdir(DATA_DIR, 0700, true); }

function clean_sid($s)
{
    $s = preg_replace('/[^a-z0-9]/', '', strtolower((string) $s));
    return substr($s, 0, 40);
}

$action = $_GET['action'] ?? '';
$sid = clean_sid($_GET['s'] ?? '');

if ($action === '') {
    header('Content-Type: text/html; charset=utf-8');
    echo render_page();
    exit;
}

if ($sid === '') {
    http_response_code(400);
    header('Content-Type: application/json');
    echo json_encode(['error' => 'missing session id']);
    exit;
}

$runner = new SessionRunner($sid, DATA_DIR);

switch ($action) {
    case 'run':
        // ignore_user_abort یعنی حتی اگه مرورگر بسته بشه یا این درخواست
        // قطع بشه، PHP روی سرور به کارش ادامه می‌ده — دقیقاً همون چیزی که
        // برای "قطع نشدن کار بعد از بستن صفحه" لازم داریم.
        ignore_user_abort(true);
        set_time_limit(0);
        $host = trim($_POST['host'] ?? '');
        $port = (int) ($_POST['port'] ?? 22) ?: 22;
        $user = trim($_POST['user'] ?? 'root');
        $password = (string) ($_POST['password'] ?? '');
        $steps = json_decode($_POST['steps'] ?? '', true);
        if (!is_array($steps)) { $steps = default_steps(); }
        if ($host === '' || $password === '') {
            http_response_code(400);
            header('Content-Type: application/json');
            echo json_encode(['error' => 'host/password required']);
            exit;
        }
        header('Content-Type: application/json');
        echo json_encode(['ok' => true]);
        if (function_exists('fastcgi_finish_request')) {
            fastcgi_finish_request();
        } else {
            @ob_end_flush();
            @flush();
        }
        $runner->run($host, $port, $user, $password, $steps);
        exit;

    case 'poll':
        $since = (int) ($_GET['since'] ?? 0);
        header('Content-Type: application/json');
        echo json_encode([
            'status' => $runner->getStatus(),
            'detail' => $runner->getDetail(),
            'log' => $runner->getLog($since),
            'size' => $runner->logSize(),
            'result' => $runner->getResult(),
        ]);
        exit;

    case 'input':
        $body = json_decode(file_get_contents('php://input'), true);
        $data = $body['data'] ?? '';
        if ($data !== '') { $runner->queueInput($data); }
        header('Content-Type: application/json');
        echo json_encode(['ok' => true]);
        exit;

    case 'stop':
        $runner->requestStop();
        header('Content-Type: application/json');
        echo json_encode(['ok' => true]);
        exit;

    case 'uploaddb':
        $bytes = file_get_contents('php://input');
        $runner->setDbFile($bytes);
        header('Content-Type: application/json');
        echo json_encode(['ok' => true, 'bytes' => strlen($bytes)]);
        exit;

    default:
        http_response_code(404);
        echo 'not found';
        exit;
}

function render_page()
{
    return <<<'HTML'
<!doctype html>
<html lang="fa" dir="rtl">
<head>
<meta charset="utf-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1"/>
<title>Server Deployer (PHP)</title>
<link rel="stylesheet" href="https://unpkg.com/xterm@5.3.0/css/xterm.css"/>
<script src="https://unpkg.com/xterm@5.3.0/lib/xterm.js"></script>
<script src="https://unpkg.com/xterm-addon-fit@0.8.0/lib/xterm-addon-fit.js"></script>
<style>
  :root{--bg:#0b0f14;--panel:#121820;--border:#232c37;--text:#e6edf3;--accent:#3b82f6;--ok:#22c55e;--err:#ef4444;--muted:#8b98a5}
  *{box-sizing:border-box}
  body{margin:0;background:var(--bg);color:var(--text);font-family:'Segoe UI',Tahoma,sans-serif;min-height:100vh;display:flex;flex-direction:column;align-items:center;padding:24px 12px}
  .wrap{width:100%;max-width:920px;display:flex;flex-direction:column;gap:16px}
  h1{font-size:20px;margin:0 0 4px}
  .card{background:var(--panel);border:1px solid var(--border);border-radius:14px;padding:18px}
  label{display:block;font-size:13px;color:var(--muted);margin:10px 0 4px}
  input{width:100%;padding:10px 12px;border-radius:8px;border:1px solid var(--border);background:#0e141b;color:var(--text);font-size:14px}
  .row{display:flex;gap:10px}
  .row>div{flex:1}
  button{cursor:pointer;border:none;border-radius:8px;padding:11px 18px;font-size:14px;font-weight:600}
  .btn-primary{background:var(--accent);color:#fff;width:100%;margin-top:14px}
  .btn-secondary{background:#1c2834;color:var(--text);border:1px solid var(--border)}
  .btn-exit{background:#3a1414;color:#ff8080;border:1px solid #5c1f1f;width:100%;margin-top:10px}
  .status{display:flex;align-items:center;gap:8px;font-size:13px;color:var(--muted)}
  .dot{width:9px;height:9px;border-radius:50%;background:var(--muted)}
  .dot.running{background:var(--accent);animation:pulse 1.2s infinite}
  .dot.done{background:var(--ok)}
  .dot.error{background:var(--err)}
  @keyframes pulse{0%,100%{opacity:1}50%{opacity:.3}}
  #termWrap{height:min(60vh,520px);border-radius:10px;overflow:hidden;background:#000;border:1px solid var(--border);padding:6px}
  #term{width:100%;height:100%}
  #term .xterm-viewport{-webkit-overflow-scrolling:touch;touch-action:pan-y;scrollbar-width:thin}
  #term .xterm-viewport::-webkit-scrollbar{width:12px}
  #term .xterm-viewport::-webkit-scrollbar-thumb{background:#3f4a5a;border-radius:6px}
  .ctrlRow{display:flex;flex-wrap:wrap;gap:6px;margin-top:8px}
  .ctrlRow button{flex:1 1 auto;min-width:54px;padding:8px 6px;font-size:12px;font-family:monospace;background:#1c2834;color:var(--text);border:1px solid var(--border)}
  .consoleInput{display:flex;gap:8px;margin-top:10px}
  .consoleInput input{flex:1;font-family:monospace}
  .detail{font-size:13.5px;line-height:1.7;white-space:pre-wrap}
  .hidden{display:none !important}
  .pill{display:inline-block;background:#1c2834;border:1px solid var(--border);border-radius:999px;padding:2px 10px;font-size:11.5px;color:var(--muted);margin-inline-start:8px}
  a.dl{color:var(--accent);text-decoration:none;font-size:13.5px}
  textarea{width:100%;min-height:220px;background:#0e141b;color:var(--text);border:1px solid var(--border);border-radius:8px;padding:10px;font-family:monospace;font-size:12.5px;line-height:1.6}
  .resultActions{display:flex;gap:10px;align-items:center;margin-top:8px;flex-wrap:wrap}
  .stepList{display:flex;flex-direction:column;gap:8px;margin:4px 0 4px}
  .stepRow{display:flex;align-items:center;gap:8px;font-size:13.5px;background:#0e141b;border:1px solid var(--border);border-radius:8px;padding:9px 10px}
  .stepRow input{width:16px;height:16px;flex:none}
  .warn{font-size:12px;color:#f3c969;background:#2a2112;border:1px solid #4a3a16;border-radius:8px;padding:10px;margin-top:10px}
</style>
</head>
<body>
<div class="wrap">
  <h1>Server Deployer (PHP) <span class="pill" id="sidPill"></span></h1>

  <div class="card" id="formCard">
    <div class="row">
      <div><label>IP Address</label><input id="host" placeholder="1.2.3.4"/></div>
      <div style="max-width:110px"><label>Port</label><input id="port" value="22"/></div>
    </div>
    <div class="row">
      <div><label>Username</label><input id="user" value="root"/></div>
      <div><label>Password</label><input id="pass" type="password"/></div>
    </div>
    <label>Optional: pre-upload x-ui.db backup (manual Restore step will tell you to use this if provided)</label>
    <input id="dbfile" type="file" accept=".db"/>

    <label style="margin-top:16px">مراحلی که می‌خوای اجرا بشن (پیش‌فرض همه روشن — اگه بار قبل بخشی از کار انجام شده، فقط بقیه رو تیک بزن):</label>
    <div class="stepList">
      <label class="stepRow"><input type="checkbox" data-step="installer" checked/> مرحله ۱ — نصب (رمز/DNS/ریپو/نصب پنل 3x-ui)</label>
      <label class="stepRow"><input type="checkbox" data-step="ufw" checked/> مرحله ۲ — باز کردن پورت‌ها (UFW)</label>
      <label class="stepRow"><input type="checkbox" data-step="ssl" checked/> مرحله ۳ — گرفتن سرتیفیکیت دامنه‌ها</label>
      <label class="stepRow"><input type="checkbox" data-step="restore" checked/> مرحله ۴ — بررسی/آماده‌سازی ریستور بکاپ پنل</label>
      <label class="stepRow"><input type="checkbox" data-step="restart" checked/> مرحله ۵ — ری‌استارت پنل</label>
      <label class="stepRow"><input type="checkbox" data-step="panelConfig" checked/> مرحله ۶ — تنظیم پسورد/یوزر/پورت/دامنه‌ی پنل</label>
      <label class="stepRow"><input type="checkbox" data-step="finalSettings" checked/> مرحله ۷ — خوندن تنظیمات نهایی و ساخت نتیجه</label>
    </div>
    <div class="warn">⚠️ روی هاست‌های اشتراکی ارزون، اجرا ممکنه به سقف زمانی هاست بخوره و وسط کار قطع بشه. اگه این اتفاق افتاد، دوباره همین صفحه رو باز کن، فقط مرحله‌های باقی‌مونده رو تیک بزن و Start رو دوباره بزن — ادامه از همون‌جا می‌ره.</div>
    <button class="btn-primary" id="startBtn">Connect &amp; Start</button>
  </div>

  <div class="card hidden" id="runCard">
    <div class="status"><span class="dot" id="statusDot"></span><span id="statusText">idle</span></div>
    <div id="termWrap"><div id="term"></div></div>
    <div class="ctrlRow">
      <button data-send="\u0003">Ctrl+C</button>
      <button data-send="\u0004">Ctrl+D</button>
      <button data-send="\u001a">Ctrl+Z</button>
      <button data-send="\t">Tab</button>
      <button data-send="\u001b">Esc</button>
      <button data-send="\r">Enter</button>
      <button data-send="\u001b[A">↑</button>
      <button data-send="\u001b[B">↓</button>
      <button data-send="\u001b[D">←</button>
      <button data-send="\u001b[C">→</button>
    </div>
    <div class="ctrlRow">
      <button id="scrollTopBtn" type="button">⤒ شروع</button>
      <button id="pgUpBtn" type="button">PgUp</button>
      <button id="pgDnBtn" type="button">PgDn</button>
      <button id="scrollBotBtn" type="button">⤓ پایان</button>
      <button id="copyTermBtn" type="button">کپی کنسول</button>
    </div>
    <div class="consoleInput">
      <input id="cmdInput" placeholder="Type a command and press Enter / Send"/>
      <button class="btn-secondary" id="sendBtn">Send</button>
    </div>
    <button class="btn-exit" id="exitBtn">Stop now</button>
  </div>

  <div class="card hidden" id="newSessionCard" style="text-align:center">
    <p class="detail" style="margin-bottom:10px">این Session تموم شده. برای یه دیپلوی جدید (یا ادامه‌ی همین سرور با مراحل باقی‌مونده):</p>
    <button class="btn-primary" id="newSessionBtn" style="margin-top:0">شروع Session جدید</button>
  </div>

  <div class="card hidden" id="detailCard">
    <label style="margin-top:0">Progress / Details</label>
    <div class="detail" id="detailText">—</div>
    <div id="resultBox" class="hidden" style="margin-top:12px">
      <label>Result</label>
      <textarea id="resultText" readonly></textarea>
      <div class="resultActions">
        <a class="dl" id="dlLink" download="server-result.txt">Download result.txt</a>
        <button class="btn-secondary" id="copyBtn" type="button">Copy all</button>
      </div>
    </div>
  </div>
</div>

<script>
const qs = new URLSearchParams(location.search);
let sid = qs.get('s');
if (!sid) { sid = Math.random().toString(36).slice(2) + Date.now().toString(36); history.replaceState(null, '', '?s=' + sid); }
document.getElementById('sidPill').textContent = 'session: ' + sid;

const formCard = document.getElementById('formCard');
const runCard = document.getElementById('runCard');
const detailCard = document.getElementById('detailCard');
const statusDot = document.getElementById('statusDot');
const statusText = document.getElementById('statusText');
const detailText = document.getElementById('detailText');
const resultBox = document.getElementById('resultBox');
const resultText = document.getElementById('resultText');
const dlLink = document.getElementById('dlLink');
const newSessionCard = document.getElementById('newSessionCard');

let term = new Terminal({ convertEol: true, fontSize: 13, scrollback: 8000, theme: { background: '#000000' }, copyOnSelect: true });
const fitAddon = new FitAddon.FitAddon();
term.loadAddon(fitAddon);
term.open(document.getElementById('term'));
fitAddon.fit();
window.addEventListener('resize', () => fitAddon.fit());
document.getElementById('termWrap').addEventListener('click', () => term.focus());

function lock(locked) {
  formCard.classList.toggle('hidden', locked);
  runCard.classList.toggle('hidden', !locked);
  detailCard.classList.toggle('hidden', !locked);
}

function setStatus(s) {
  statusText.textContent = s;
  statusDot.className = 'dot ' + (s === 'running' || s === 'connecting' ? 'running' : s === 'done' ? 'done' : s === 'error' ? 'error' : '');
  const finished = s === 'done' || s === 'error' || s === 'closed';
  newSessionCard.classList.toggle('hidden', !finished);
}

function setResult(r) {
  if (!r) { resultBox.classList.add('hidden'); return; }
  resultBox.classList.remove('hidden');
  resultText.value = r;
  const blob = new Blob([r], { type: 'text/plain' });
  dlLink.href = URL.createObjectURL(blob);
}

document.getElementById('newSessionBtn').onclick = () => {
  const newSid = Math.random().toString(36).slice(2) + Date.now().toString(36);
  location.href = location.pathname + '?s=' + newSid;
};

let sinceByte = 0;
let polling = false;
async function poll() {
  if (polling) return;
  polling = true;
  try {
    const r = await fetch('index.php?action=poll&s=' + sid + '&since=' + sinceByte);
    const j = await r.json();
    if (j.log) { term.write(j.log); sinceByte = j.size; }
    if (j.status) { setStatus(j.status); if (j.status !== 'idle') lock(true); }
    if (j.detail) { detailText.textContent = j.detail; }
    if (j.result) { setResult(j.result); }
  } catch (e) {}
  polling = false;
}
setInterval(poll, 1500);
poll();

function decodeEscapes(s) {
  return s.replace(/\\u([0-9a-fA-F]{4})/g, (_, h) => String.fromCharCode(parseInt(h, 16)))
          .replace(/\\t/g, '\t').replace(/\\r/g, '\r');
}
async function sendRaw(data) {
  await fetch('index.php?action=input&s=' + sid, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ data }) });
}
term.onData((data) => { sendRaw(data); });
document.querySelectorAll('.ctrlRow [data-send]').forEach((btn) => {
  btn.addEventListener('click', () => { term.focus(); sendRaw(decodeEscapes(btn.dataset.send)); });
});

document.getElementById('scrollTopBtn').onclick = () => term.scrollToTop();
document.getElementById('scrollBotBtn').onclick = () => term.scrollToBottom();
document.getElementById('pgUpBtn').onclick = () => term.scrollLines(-Math.max(1, term.rows - 2));
document.getElementById('pgDnBtn').onclick = () => term.scrollLines(Math.max(1, term.rows - 2));
document.getElementById('copyTermBtn').onclick = async () => {
  term.selectAll();
  const text = term.getSelection();
  term.clearSelection();
  try { await navigator.clipboard.writeText(text); }
  catch (e) {
    const ta = document.createElement('textarea');
    ta.value = text; ta.style.position = 'fixed'; ta.style.opacity = '0';
    document.body.appendChild(ta); ta.select(); document.execCommand('copy'); document.body.removeChild(ta);
  }
};

document.getElementById('sendBtn').onclick = sendCmd;
document.getElementById('cmdInput').addEventListener('keydown', (e) => { if (e.key === 'Enter') sendCmd(); });
function sendCmd() {
  const el = document.getElementById('cmdInput');
  if (el.value) { sendRaw(el.value + '\n'); el.value = ''; }
}

document.getElementById('copyBtn').onclick = async () => {
  try { await navigator.clipboard.writeText(resultText.value); }
  catch (e) { resultText.select(); document.execCommand('copy'); }
};

document.getElementById('exitBtn').onclick = async () => {
  if (!confirm('کار متوقف بشه؟')) return;
  const btn = document.getElementById('exitBtn');
  btn.disabled = true; btn.textContent = 'در حال توقف...';
  try {
    await fetch('index.php?action=stop&s=' + sid, { method: 'POST' });
  } finally {
    btn.disabled = false; btn.textContent = 'Stop now';
  }
};

document.getElementById('startBtn').onclick = async () => {
  const host = document.getElementById('host').value.trim();
  const port = document.getElementById('port').value.trim() || '22';
  const user = document.getElementById('user').value.trim() || 'root';
  const pass = document.getElementById('pass').value;
  if (!host || !pass) { alert('IP و رمز عبور را وارد کنید'); return; }
  const dbf = document.getElementById('dbfile').files[0];
  if (dbf) {
    const buf = await dbf.arrayBuffer();
    await fetch('index.php?action=uploaddb&s=' + sid, { method: 'POST', body: buf });
  }
  const steps = {};
  document.querySelectorAll('#formCard [data-step]').forEach((el) => { steps[el.dataset.step] = el.checked; });

  lock(true);
  setStatus('connecting');
  const body = new URLSearchParams({ host, port, user, password: pass, steps: JSON.stringify(steps) });
  fetch('index.php?action=run&s=' + sid, { method: 'POST', body }).catch(() => {});
};

// resume state on load in case a previous run is already in progress/finished
poll();
</script>
</body>
</html>
HTML;
}
