<?php
require_once __DIR__ . '/ssh.php';

const PS1_MARK = '###WRKRDY###';
const FALLBACK_PANEL_PORTS_STR = '22 47 80 346 428 440 441 442 443 444 445 446 447 448 449 450 451 452 453 454 455 456 457 458 459 460 461 462 463 464 465 466 467 468 469 470 471 472 473 474 475 476 477 478 479 480 481 482 483 484 485 486 487 488 489 490 491 492 493 494 495 496 497 498 499 500 501 502 503 504 505 506 507 508 509 510 1087 2053 2083 2095 2096 2097 2098 2100 2101 2102 2104 2110 2121 8000 62050 62051 62052 62053';
const FALLBACK_DOMAINS = ['a.nami1.ir', 'b.nami1.ir', 'c.nami1.ir', 'vip.nami1.ir', 'didin.nami1.ir', 'vbnm.nami1.ir'];
const PANEL_PORTS_URL = 'https://raw.githubusercontent.com/Alireza58310/old-new/refs/heads/main/bezan/panel/ports.txt';
const DOMAINS_URL = 'https://raw.githubusercontent.com/Alireza58310/old-new/refs/heads/main/bezan/panel/domains.txt';
const PANEL_DB_RAW_URL = 'https://raw.githubusercontent.com/Alireza58310/old-new/main/bezan/panel/x-ui.db';
const STEP_KEYS = ['installer', 'ufw', 'ssl', 'restore', 'restart', 'panelConfig', 'finalSettings'];

function default_steps()
{
    $o = [];
    foreach (STEP_KEYS as $k) { $o[$k] = true; }
    return $o;
}

/** یک marker رجکسی برای waitFor — چون PHP کلاس RegExp جدا نداره */
class Rx
{
    public $pattern;
    public function __construct($pcrePattern) { $this->pattern = $pcrePattern; }
}

class SessionRunner
{
    public $sid;
    public $dir;
    /** @var SimpleSSH */
    public $ssh;

    public $panel = null;
    public $domains = null;
    public $certDomain = null;
    public $credsReset = false;
    public $portForced = false;
    public $liveSettingsOk = false;
    public $restoreStatus = null;
    public $warnings = [];
    public $stopped = false;

    public function __construct($sid, $baseDir)
    {
        $this->sid = $sid;
        $this->dir = rtrim($baseDir, '/') . '/' . $sid;
        if (!is_dir($this->dir)) { @mkdir($this->dir, 0700, true); }
    }

    // ---------- persistence ----------

    private function p($name) { return $this->dir . '/' . $name; }

    public function loadMeta()
    {
        $f = $this->p('meta.json');
        if (!file_exists($f)) { return; }
        $data = json_decode(@file_get_contents($f), true);
        if (!is_array($data)) { return; }
        $this->panel = $data['panel'] ?? null;
        $this->domains = $data['domains'] ?? null;
        $this->certDomain = $data['certDomain'] ?? null;
        $this->credsReset = !empty($data['credsReset']);
        $this->portForced = !empty($data['portForced']);
        $this->liveSettingsOk = !empty($data['liveSettingsOk']);
        $this->restoreStatus = $data['restoreStatus'] ?? null;
    }

    public function saveMeta()
    {
        $data = [
            'panel' => $this->panel,
            'domains' => $this->domains,
            'certDomain' => $this->certDomain,
            'credsReset' => $this->credsReset,
            'portForced' => $this->portForced,
            'liveSettingsOk' => $this->liveSettingsOk,
            'restoreStatus' => $this->restoreStatus,
        ];
        @file_put_contents($this->p('meta.json'), json_encode($data), LOCK_EX);
    }

    public function setStatus($s)
    {
        @file_put_contents($this->p('status.txt'), $s, LOCK_EX);
    }

    public function getStatus()
    {
        return @file_get_contents($this->p('status.txt')) ?: 'idle';
    }

    public function setDetail($s)
    {
        @file_put_contents($this->p('detail.txt'), $s, LOCK_EX);
    }

    public function getDetail()
    {
        return @file_get_contents($this->p('detail.txt')) ?: '';
    }

    public function appendLog($s)
    {
        @file_put_contents($this->p('log.txt'), $s, FILE_APPEND | LOCK_EX);
    }

    public function getLog($sinceByte = 0)
    {
        $f = $this->p('log.txt');
        if (!file_exists($f)) { return ''; }
        $fh = fopen($f, 'rb');
        if ($sinceByte > 0) { fseek($fh, $sinceByte); }
        $data = stream_get_contents($fh);
        fclose($fh);
        return $data;
    }

    public function logSize()
    {
        $f = $this->p('log.txt');
        return file_exists($f) ? filesize($f) : 0;
    }

    public function writeResult($text)
    {
        @file_put_contents($this->p('result.txt'), $text, LOCK_EX);
    }

    public function getResult()
    {
        $f = $this->p('result.txt');
        return file_exists($f) ? file_get_contents($f) : null;
    }

    public function queueInput($bytes)
    {
        @file_put_contents($this->p('pending_input.txt'), $bytes, FILE_APPEND | LOCK_EX);
    }

    private function drainPendingInput()
    {
        $f = $this->p('pending_input.txt');
        if (!file_exists($f) || filesize($f) === 0) { return; }
        $fh = fopen($f, 'c+b');
        if (!$fh) { return; }
        flock($fh, LOCK_EX);
        $data = stream_get_contents($fh);
        ftruncate($fh, 0);
        flock($fh, LOCK_UN);
        fclose($fh);
        if ($data !== '' && $this->ssh && !$this->ssh->closed) {
            $this->ssh->write($data);
        }
    }

    public function requestStop()
    {
        @file_put_contents($this->p('stop.flag'), '1', LOCK_EX);
    }

    private function stopRequested()
    {
        return file_exists($this->p('stop.flag'));
    }

    public function setDbFile($bytes)
    {
        @file_put_contents($this->p('db.bin'), $bytes, LOCK_EX);
    }

    private function loadDbFile()
    {
        $f = $this->p('db.bin');
        return file_exists($f) ? file_get_contents($f) : null;
    }

    // ---------- low-level ssh helpers ----------

    /** $markers: string یا Rx یا آرایه‌ای از این دوتا */
    private function waitFor($markers, $timeoutMs)
    {
        $markers = is_array($markers) ? $markers : [$markers];
        $buf0 = &$this->ssh->buf;
        $start = strlen($buf0);
        $deadline = microtime(true) + ($timeoutMs / 1000);
        while (true) {
            if ($this->stopRequested()) { $this->stopped = true; return null; }
            $this->drainPendingInput();
            $this->ssh->pump(250);
            if ($this->ssh->closed) { return null; }
            foreach ($markers as $m) {
                if ($m instanceof Rx) {
                    $from = max(0, $start - 80);
                    if (preg_match($m->pattern, substr($this->ssh->buf, $from), $mm, PREG_OFFSET_CAPTURE)) {
                        return ['marker' => $m, 'idx' => $from + $mm[0][1]];
                    }
                } else {
                    $from = max(0, $start - strlen($m));
                    $idx = strpos($this->ssh->buf, $m, $from);
                    if ($idx !== false) { return ['marker' => $m, 'idx' => $idx]; }
                }
            }
            if (microtime(true) > $deadline) { return null; }
        }
    }

    private function sleepMs($ms)
    {
        $deadline = microtime(true) + ($ms / 1000);
        while (microtime(true) < $deadline) {
            if ($this->stopRequested()) { $this->stopped = true; return; }
            $this->drainPendingInput();
            $this->ssh->pump(100);
        }
    }

    private function resync()
    {
        if (strpos(substr($this->ssh->buf, -200), PS1_MARK) !== false) { return; }
        for ($i = 0; $i < 2; $i++) {
            $this->ssh->write("\x03\x03\n");
            if ($this->waitFor(PS1_MARK, 6000)) { return; }
        }
    }

    private function shellCmd($cmd, $timeoutMs = 20000)
    {
        $this->ssh->write($cmd . "\n");
        return $this->waitFor(PS1_MARK, $timeoutMs);
    }

    private function uploadHeredoc($remotePath, $content)
    {
        $token = 'WRKUP_' . substr(bin2hex(random_bytes(8)), 0, 12);
        $this->ssh->write("cat > $remotePath << '$token'\n");
        $len = strlen($content);
        for ($i = 0; $i < $len; $i += 4000) {
            $this->ssh->write(substr($content, $i, 4000));
            $this->sleepMs(30);
        }
        $this->ssh->write("\n$token\n");
        $this->ssh->write("chmod +x $remotePath\necho UPLOADED_$token\n");
        $r = $this->waitFor('UPLOADED_' . $token, 30000);
        if (!$r) { throw new Exception('Failed to upload ' . $remotePath); }
    }

    private function fetchUrl($url)
    {
        $ctx = stream_context_create(['http' => ['timeout' => 15], 'https' => ['timeout' => 15]]);
        $data = @file_get_contents($url, false, $ctx);
        return $data === false ? null : $data;
    }

    private function fetchPanelPorts()
    {
        $text = $this->fetchUrl(PANEL_PORTS_URL . '?t=' . time());
        if ($text === null) { return preg_split('/\s+/', trim(FALLBACK_PANEL_PORTS_STR)); }
        $ports = array_values(array_filter(preg_split('/\s+/', trim($text))));
        return $ports ?: preg_split('/\s+/', trim(FALLBACK_PANEL_PORTS_STR));
    }

    private function fetchDomains()
    {
        $text = $this->fetchUrl(DOMAINS_URL . '?t=' . time());
        if ($text === null) { return FALLBACK_DOMAINS; }
        $domains = array_values(array_filter(preg_split('/\s+/', trim($text))));
        return $domains ?: FALLBACK_DOMAINS;
    }

    private function parsePanelOutput($rawText)
    {
        $text = preg_replace('/\x1b\[[0-9;]*m/', '', $rawText);
        $get = function ($re) use ($text) {
            if (preg_match($re, $text, $m)) { return trim($m[1]); }
            return null;
        };
        $username = $get('/Username:\s*(\S+)/');
        $password = $get('/Password:\s*(\S+)/');
        $port = $get('/Port:\s*(\S+)/');
        $base = $get('/WebBasePath:\s*(\S+)/');
        $url = $get('/Access URL:\s*(\S+)/');
        $token = $get('/API Token:\s*(\S+)/');
        if (!$username || !$password || !$url) { return null; }
        return compact('username', 'password', 'port', 'base', 'url', 'token');
    }

    private function parseLiveSettings($rawText)
    {
        $text = preg_replace('/\x1b\[[0-9;]*m/', '', $rawText);
        $get = function ($re) use ($text) {
            if (preg_match($re, $text, $m)) { return trim($m[1]); }
            return null;
        };
        $port = $get('/\bport:\s*(\d+)/i');
        $base = $get('/webBasePath:\s*(\S+)/i');
        $url = $get('/Access URL:\s*(\S+)/i');
        if (!$port && !$url) { return null; }
        return compact('port', 'base', 'url');
    }

    // ---------- phases (exact same prompts validated against real logs) ----------

    private function runScriptA()
    {
        $this->setDetail('Uploading & running alis-installer.sh ...');
        $this->uploadHeredoc('/root/alis-installer.sh', file_get_contents(__DIR__ . '/../scripts/alis-installer.sh'));
        $this->ssh->write("bash /root/alis-installer.sh\n");
        $this->waitFor('Please select an option [1-8]:', 20000);

        $this->setDetail('Configuring root & SSH users...');
        $this->ssh->write("2\n");
        $this->waitFor('Press any key to return to menu...', 60000);
        $this->ssh->write(' ');
        $this->waitFor('Please select an option [1-8]:', 15000);

        $this->setDetail('Setting DNS to Google...');
        $this->ssh->write("3\n");
        $this->waitFor('Choose an option [1-4]:', 10000);
        $this->ssh->write("1\n");
        $this->waitFor('Press any key to return to menu...', 20000);
        $this->ssh->write(' ');
        $this->waitFor('Please select an option [1-8]:', 15000);

        $this->setDetail('Restoring official Ubuntu repositories...');
        $this->ssh->write("4\n");
        $this->waitFor('Press any key to return to menu...', 60000);
        $this->ssh->write(' ');
        $this->waitFor('Please select an option [1-8]:', 15000);

        $this->setDetail('Disabling UFW & installing 3x-ui panel (a few minutes)...');
        $beforeLen = strlen($this->ssh->buf);
        $this->ssh->write("6\n");
        $this->waitFor('Press any key to return to menu...', 10 * 60 * 1000);
        $installOutput = substr($this->ssh->buf, $beforeLen);
        $parsed = $this->parsePanelOutput($installOutput);
        if ($parsed) {
            $this->panel = $parsed;
            $this->setDetail('3x-ui installed — Access URL: ' . $this->panel['url']);
        }
        $this->ssh->write(' ');
        $this->waitFor('Please select an option [1-8]:', 15000);

        $this->ssh->write("8\n");
        $this->waitFor(PS1_MARK, 15000);

        if ($this->panel && !empty($this->panel['port'])) {
            $this->shellCmd('ufw allow ' . $this->panel['port'] . '/tcp 2>/dev/null || true', 10000);
        }
        $this->saveMeta();
    }

    private function runScriptB()
    {
        $this->resync();
        $this->setDetail('Uploading & running alis-ufw-manager.sh ...');
        $this->uploadHeredoc('/root/alis-ufw-manager.sh', file_get_contents(__DIR__ . '/../scripts/alis-ufw-manager.sh'));
        $this->ssh->write("bash /root/alis-ufw-manager.sh\n");
        $this->waitFor('Select an option (1-6):', 15000);

        $this->setDetail('Installing & enabling UFW...');
        $this->ssh->write("1\n");
        $this->waitFor('Press Enter to return to the menu...', 30000);
        $this->ssh->write("\n");
        $this->waitFor('Select an option (1-6):', 15000);

        $this->setDetail('Fetching the port list and opening it...');
        $ports = $this->fetchPanelPorts();
        $this->ssh->write("2\n");
        $this->waitFor("Type 'END' and press Enter when finished:", 10000);
        foreach ($ports as $p) { $this->ssh->write($p . "\n"); }
        $this->ssh->write("END\n");
        $this->waitFor('Press Enter to return to the menu...', 30000);
        $this->ssh->write("\n");
        $this->waitFor('Select an option (1-6):', 15000);

        $this->ssh->write("6\n");
        $this->waitFor(PS1_MARK, 15000);
    }

    private function runScriptC()
    {
        $this->resync();
        $this->domains = $this->fetchDomains();
        $this->setDetail('Uploading & running alis-fake-ssl-manager.sh ...');
        $this->uploadHeredoc('/root/alis-fake-ssl-manager.sh', file_get_contents(__DIR__ . '/../scripts/alis-fake-ssl-manager.sh'));
        $this->ssh->write("bash /root/alis-fake-ssl-manager.sh\n");
        $this->waitFor('Please select an option [1-5]:', 15000);

        foreach ($this->domains as $d) {
            $this->setDetail('Generating SSL for ' . $d . ' ...');
            $this->ssh->write("1\n");
            $this->waitFor('Enter your Domain name', 10000);
            $this->ssh->write($d . "\n");
            $this->waitFor('Press any key to return to menu...', 30000);
            $this->ssh->write(' ');
            $this->waitFor('Please select an option [1-5]:', 15000);
        }

        $this->setDetail('Deploying all domains to 3x-ui (Panel, Sub, Inbounds)...');
        $this->ssh->write("2\n");
        $pick = $this->waitFor(['Which domain for Panel & Subscription?', 'Please select an option [1-5]:'], 10000);
        if ($pick && $pick['marker'] === 'Which domain for Panel & Subscription?') {
            $this->ssh->write("\n");
            $this->waitFor('Press any key to return to menu...', 60000);
            $this->ssh->write(' ');
            $this->waitFor('Please select an option [1-5]:', 15000);
        }

        $this->ssh->write("5\n");
        $this->waitFor(PS1_MARK, 15000);
        $this->saveMeta();
    }

    private function restorePanelBackup()
    {
        $this->resync();
        if (!$this->panel) {
            $this->restoreStatus = 'SKIPPED — panel install info is missing (run step 1 first, at least once).';
            $this->appendLog("\r\n[WARN] " . $this->restoreStatus . "\r\n");
            return;
        }
        if (!empty($this->panel['port'])) {
            $this->shellCmd('ufw allow ' . $this->panel['port'] . '/tcp', 15000);
        }
        $this->restoreStatus = 'SKIPPED — automatic browser-based restore is not available in this (PHP hosting) build. '
            . 'Restore it manually: open ' . ($this->panel['url'] ?? '?') . ', log in with '
            . ($this->panel['username'] ?? '?') . ' / ' . ($this->panel['password'] ?? '?')
            . ', go to Backup & Restore, and upload a .db backup yourself.';
        $this->appendLog("\r\n[INFO] " . $this->restoreStatus . "\r\n");
        $this->setDetail($this->restoreStatus);
        $this->saveMeta();
    }

    private function restartPanel()
    {
        $this->resync();
        $this->setDetail('Restarting the panel (x-ui > 14 Restart)...');
        $this->ssh->write("x-ui\n");
        $menu = $this->waitFor(['Please choose an option', 'Please enter'], 15000);
        if (!$menu) { $this->appendLog("\r\n[WARN] x-ui menu not detected — restart the panel manually: x-ui > 14\r\n"); return; }
        $this->ssh->write("14\n");
        $this->waitFor(['Press enter to return', 'Restarted successfully'], 20000);
        $this->ssh->write("\n");
        $this->sleepMs(500);
        $this->ssh->write("0\n");
        $this->resync();
        $this->sleepMs(4000);
    }

    private function resetPanelCredentials()
    {
        $this->resync();
        $this->setDetail('Resetting panel username & password to adminas / alirezavps...');
        $this->ssh->write("x-ui\n");
        $menu = $this->waitFor(['Please choose an option', 'Please enter'], 15000);
        if (!$menu) { $this->appendLog("\r\n[WARN] x-ui menu not detected — run `x-ui` then option 7 manually.\r\n"); return; }

        $this->ssh->write("7\n");
        if (!$this->waitFor('reset the username and password of the panel', 10000)) {
            $this->appendLog("\r\n[WARN] confirm prompt not detected for option 7.\r\n");
            $this->ssh->write("0\n"); $this->resync(); return;
        }
        $this->ssh->write("y\n");

        if (!$this->waitFor('set the login username', 10000)) {
            $this->appendLog("\r\n[WARN] username prompt not detected during credential reset.\r\n");
            $this->resync(); return;
        }
        $this->ssh->write("adminas\n");

        if (!$this->waitFor('set the login password', 10000)) {
            $this->appendLog("\r\n[WARN] password prompt not detected during credential reset.\r\n");
            $this->resync(); return;
        }
        $this->ssh->write("alirezavps\n");

        $after = $this->waitFor(['two-factor authentication', 'Restart the panel'], 15000);
        if ($after && $after['marker'] === 'two-factor authentication') {
            $this->ssh->write("y\n");
            $this->waitFor('Restart the panel', 15000);
        }
        $this->ssh->write("y\n");
        $this->sleepMs(2000);

        $this->ssh->write("0\n");
        $this->resync();

        $this->credsReset = true;
        $this->saveMeta();
    }

    private function finalizePanelPort()
    {
        $this->resync();
        $this->setDetail('Forcing the panel port to 2083 (x-ui > 10)...');
        $this->ssh->write("x-ui\n");
        $menu = $this->waitFor(['Please choose an option', 'Please enter'], 15000);
        if (!$menu) { $this->appendLog("\r\n[WARN] x-ui menu not detected — run x-ui > 10 manually.\r\n"); return; }

        $this->ssh->write("10\n");
        $portPrompt = $this->waitFor(new Rx('/port/i'), 10000);
        if (!$portPrompt) { $this->appendLog("\r\n[WARN] port prompt not detected on option 10.\r\n"); $this->ssh->write("0\n"); $this->resync(); return; }
        $this->ssh->write("2083\n");

        $restartPrompt = $this->waitFor('Restart the panel', 15000);
        if ($restartPrompt) { $this->ssh->write("y\n"); }
        $this->sleepMs(2000);

        $this->ssh->write("0\n");
        $this->resync();

        $this->shellCmd('ufw allow 2083/tcp 2>/dev/null || true', 10000);
        $this->portForced = true;
        $this->saveMeta();
    }

    private function setPanelCertPath()
    {
        $certDomain = ($this->domains[0] ?? null) ?: FALLBACK_DOMAINS[0];
        $this->certDomain = $certDomain;
        $this->resync();
        $this->setDetail("Setting panel SSL cert path via the x-ui menu (20 > 5 > 1 > $certDomain)...");
        $this->ssh->write("x-ui\n");
        $menu = $this->waitFor(['Please choose an option', 'Please enter'], 15000);
        if (!$menu) { $this->appendLog("\r\n[WARN] x-ui menu not detected — set manually: x-ui > 20 > 5 > 1 > $certDomain\r\n"); return; }

        $this->ssh->write("20\n");
        $this->waitFor('Choose an option:', 10000);
        $this->ssh->write("5\n");
        $this->waitFor('Choose an option:', 10000);
        $this->ssh->write("1\n");
        $this->waitFor(new Rx('/domain/i'), 10000);
        $this->ssh->write($certDomain . "\n");
        $this->waitFor(['Press enter to return', PS1_MARK], 20000);
        $this->ssh->write("\n");
        $this->sleepMs(500);
        $this->ssh->write("0\n");
        $this->resync();
        $this->saveMeta();
    }

    private function applyPanelConfig()
    {
        $this->resetPanelCredentials();
        $this->finalizePanelPort();
        $this->setPanelCertPath();
    }

    private function captureFinalSettings()
    {
        $this->resync();
        $this->setDetail('Reading final panel settings (x-ui > 11)...');
        $this->ssh->write("x-ui\n");
        $menu = $this->waitFor(['Please choose an option', 'Please enter'], 15000);
        if (!$menu) { $this->appendLog("\r\n[WARN] could not re-open the x-ui menu to read final settings.\r\n"); return; }

        $before = strlen($this->ssh->buf);
        $this->ssh->write("11\n");
        $this->sleepMs(2500);
        $settings = substr($this->ssh->buf, $before);
        $live = $this->parseLiveSettings($settings);
        if ($live) {
            if (!$this->panel) { $this->panel = []; }
            if (!empty($live['port'])) { $this->panel['port'] = $live['port']; }
            if (!empty($live['base'])) { $this->panel['base'] = $live['base']; }
            if (!empty($live['url'])) { $this->panel['url'] = $live['url']; }
            if ($this->credsReset) { $this->panel['username'] = 'adminas'; $this->panel['password'] = 'alirezavps'; }
            $this->liveSettingsOk = true;
        } else {
            $this->appendLog("\r\n[WARN] could not parse the option-11 output — the result below may fall back to earlier values.\r\n");
        }

        $this->ssh->write("0\n");
        $this->resync();
        $this->saveMeta();
    }

    private function buildResultText()
    {
        $p = $this->panel ?: [];
        $domains = $this->domains ?: FALLBACK_DOMAINS;
        $lines = [
            '=== Server ===',
            'Status: automation finished',
            '',
            '=== 3x-ui Panel ===',
            'Username:    ' . ($p['username'] ?? '?') . ($this->credsReset ? '  (reset at the end, via x-ui > 7)' : ''),
            'Password:    ' . ($p['password'] ?? '?') . ($this->credsReset ? '  (reset at the end, via x-ui > 7)' : ''),
            'Port:        ' . ($p['port'] ?? '?'),
            'WebBasePath: ' . ($p['base'] ?? '?'),
            'Access URL:  ' . ($p['url'] ?? '?'),
            'API Token:   ' . ($p['token'] ?? '?'),
            '',
            '=== TLS domains ===',
        ];
        foreach ($domains as $d) { $lines[] = ' - ' . $d; }
        $lines[] = '';
        $lines[] = 'Panel cert path set to: ' . ($this->certDomain ?: $domains[0]) . ' (via x-ui > 20 > 5 > 1)';
        $lines[] = 'Database restore: ' . ($this->restoreStatus ?: 'UNKNOWN — this step may not have run.');
        $lines[] = '';
        if ($this->warnings) {
            $lines[] = '=== Warnings (steps that may need a manual check) ===';
            foreach ($this->warnings as $w) { $lines[] = ' - ' . $w; }
            $lines[] = '';
        }
        $lines[] = 'Generated by the PHP automation runner.';
        return implode("\n", $lines);
    }

    // ---------- orchestration ----------

    public function run($host, $port, $user, $password, $steps)
    {
        $this->loadMeta();
        $this->setStatus('connecting');
        $this->setDetail('Opening TCP connection to ' . $host . ':' . $port . ' ...');

        $this->ssh = new SimpleSSH();
        $this->ssh->logCallback = function ($chunk) { $this->appendLog($chunk); };

        try {
            $this->ssh->connect($host, $port);
            $this->setDetail('Authenticating as ' . $user . ' ...');
            $this->ssh->handshakeAndAuth($user, $password, 200, 50);
            $this->setStatus('running');
            $this->setDetail('Connected. Normalizing shell prompt...');
            $this->ssh->write("stty -echo 2>/dev/null; export PS1='\\n" . PS1_MARK . "\\n'; export TERM=xterm; echo READY_" . PS1_MARK . "\n");
            $this->waitFor('READY_' . PS1_MARK, 15000);

            $phase = function ($key, $label, $fn) use ($steps) {
                if ($this->stopped || $this->stopRequested()) { $this->stopped = true; return; }
                if (isset($steps[$key]) && !$steps[$key]) {
                    $this->appendLog("\r\n[SKIP] $label — unchecked by user.\r\n");
                    return;
                }
                try { $fn(); }
                catch (Exception $e) {
                    $msg = $label . ': ' . $e->getMessage();
                    $this->warnings[] = $msg;
                    $this->appendLog("\r\n[WARN] $msg — continuing with the next step...\r\n");
                }
            };

            $phase('installer', 'Step 1: alis-installer.sh (password/DNS/repos/panel install)', [$this, 'runScriptA']);
            $phase('ufw', 'Step 2: alis-ufw-manager.sh (open ports)', [$this, 'runScriptB']);
            $phase('ssl', 'Step 3: alis-fake-ssl-manager.sh (domain certificates)', [$this, 'runScriptC']);
            $phase('restore', 'Step 4: restore panel database backup', [$this, 'restorePanelBackup']);
            $phase('restart', 'Step 5: restart panel (x-ui > 14)', [$this, 'restartPanel']);
            $phase('panelConfig', 'Step 6: set panel password + port + domain', [$this, 'applyPanelConfig']);
            $phase('finalSettings', 'Step 7: read final panel settings (x-ui > 11)', [$this, 'captureFinalSettings']);

            $this->saveMeta();
            if ($this->stopped) {
                $this->setStatus('closed');
                $this->setDetail('Stopped by user request.');
            } else {
                $this->writeResult($this->buildResultText());
                $this->setStatus('done');
                $this->setDetail($this->warnings
                    ? 'Finished with ' . count($this->warnings) . ' warning(s) — see the console log. Result file is ready below.'
                    : 'All selected steps completed. Result file is ready below.');
            }
        } catch (Exception $e) {
            $this->setDetail('Automation stopped: ' . $e->getMessage());
            $this->setStatus('error');
            $this->saveMeta();
        }

        if ($this->ssh) {
            try { $this->ssh->close(); } catch (Exception $e) {}
        }
    }
}
