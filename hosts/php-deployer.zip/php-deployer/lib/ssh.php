<?php
/**
 * SimpleSSH — یک کلاینت SSH2 سبک و خالص-PHP (بدون composer، بدون افزونه‌ی
 * ssh2 پکیجی، فقط openssl + sodium + hash که روی تقریباً همه‌ی هاست‌های
 * اشتراکی مدرن از قبل فعالن). پروتکل: curve25519-sha256 برای کی‌اکسچنج،
 * aes128-ctr برای رمزنگاری، hmac-sha256 برای MAC. پسورد-اوث + PTY shell.
 *
 * این پورتِ مستقیمِ همون کلاینت SSH ایه که برای نسخه‌ی Cloudflare Worker
 * این پروژه نوشته شده بود (lib/ssh.js آنجا)، با همون منطق پروتکل.
 *
 * ⚠️ ساده‌سازی امنیتی: مثل نسخه‌ی قبلی، امضای کلید میزبان (host key) تایید
 * نمی‌شه (هیچ چک known_hosts‌ای وجود نداره). این یعنی در برابر حمله‌ی
 * مرد-میانی تئوریک آسیب‌پذیره؛ برای این پروژه (اتصال یک‌باره به سرور خودِ
 * کاربر بلافاصله بعد از ساختش) ریسک قابل قبول در نظر گرفته شده، همون‌طور
 * که در نسخه‌ی قبلی هم همین‌طور بود.
 */

class SimpleSSH
{
    private $sock;
    public $buf = '';
    public $closed = false;
    public $logCallback = null; // function(string $chunk): void

    private $seqIn = 0;
    private $seqOut = 0;
    private $enc = null; // ['encKeyC','ivC','encKeyS','ivS','macKeyC','macKeyS']
    private $sessionId = null;

    private $chanRemote = 0;
    private $chanLocalWindow = 2097152;
    private $chanRemoteWindow = 0;

    const PS_NONE = 0;

    public function __construct() {}

    private static function u32($n)
    {
        return pack('N', $n);
    }

    private static function str($s)
    {
        return self::u32(strlen($s)) . $s;
    }

    private static function mpint($b)
    {
        $i = 0;
        $len = strlen($b);
        while ($i < $len && $b[$i] === "\x00") { $i++; }
        $b = substr($b, $i);
        if ($b !== '' && (ord($b[0]) & 0x80)) { $b = "\x00" . $b; }
        return self::str($b);
    }

    private static function readU32(&$data, &$pos)
    {
        $v = unpack('N', substr($data, $pos, 4))[1];
        $pos += 4;
        return $v;
    }

    private static function readStr(&$data, &$pos)
    {
        $len = self::readU32($data, $pos);
        $v = substr($data, $pos, $len);
        $pos += $len;
        return $v;
    }

    public function connect($host, $port, $timeoutSec = 15)
    {
        $errno = 0; $errstr = '';
        $this->sock = @stream_socket_client("tcp://$host:$port", $errno, $errstr, $timeoutSec);
        if (!$this->sock) {
            throw new Exception("TCP connect failed: $errstr ($errno)");
        }
        stream_set_blocking($this->sock, false);
    }

    /** چند بایت که همین الان روی سوکت آماده‌ست رو می‌خونه (بلاک نمی‌کنه بیشتر از $maxMs) */
    private function readRaw($minBytes, $maxMs = 15000)
    {
        $deadline = microtime(true) + ($maxMs / 1000);
        $out = '';
        while (strlen($out) < $minBytes) {
            if (microtime(true) > $deadline) { throw new Exception('read timeout'); }
            $read = [$this->sock]; $write = null; $except = null;
            $n = @stream_select($read, $write, $except, 0, 200000);
            if ($n === false) { throw new Exception('stream_select failed'); }
            if ($n > 0) {
                $chunk = fread($this->sock, max(65536, $minBytes - strlen($out)));
                if ($chunk === false || ($chunk === '' && feof($this->sock))) {
                    throw new Exception('connection closed by remote');
                }
                $out .= $chunk;
            }
        }
        return $out;
    }

    private function readLine($maxMs = 15000)
    {
        $line = '';
        $deadline = microtime(true) + ($maxMs / 1000);
        while (true) {
            if (microtime(true) > $deadline) { throw new Exception('banner read timeout'); }
            $b = $this->readRaw(1, 2000);
            if ($b === "\n") { return rtrim($line, "\r"); }
            $line .= $b;
            if (strlen($line) > 4096) { throw new Exception('banner too long'); }
        }
    }

    private function sendPacket($payload)
    {
        $bs = $this->enc ? 16 : 8;
        $pad = $bs - ((5 + strlen($payload)) % $bs);
        if ($pad < 4) { $pad += $bs; }
        $padding = random_bytes($pad);
        $pkt = self::u32(1 + strlen($payload) + $pad) . chr($pad) . $payload . $padding;
        if ($this->enc) {
            $enc = openssl_encrypt($pkt, 'aes-128-ctr', $this->enc['encKeyC'], OPENSSL_RAW_DATA, $this->enc['ivC']);
            $this->enc['ivC'] = self::ctrAdvance($this->enc['ivC'], strlen($pkt));
            $mac = hash_hmac('sha256', self::u32($this->seqOut) . $pkt, $this->enc['macKeyC'], true);
            $pkt = $enc . $mac;
        }
        $this->seqOut = ($this->seqOut + 1) & 0xFFFFFFFF;
        fwrite($this->sock, $pkt);
    }

    /** شمارنده‌ی ۱۲۸ بیتی CTR رو به‌صورت دستی (بدون نیاز به افزونه‌ی GMP) جلو می‌بره */
    private static function ctrAdvance($iv, $byteLen)
    {
        $blocks = intdiv($byteLen, 16);
        $bytes = array_values(unpack('C16', $iv));
        $carry = $blocks;
        for ($i = 15; $i >= 0 && $carry > 0; $i--) {
            $sum = $bytes[$i] + ($carry & 0xFF);
            $bytes[$i] = $sum & 0xFF;
            $carry = ($carry >> 8) + ($sum > 255 ? 1 : 0);
        }
        $out = '';
        foreach ($bytes as $b) { $out .= chr($b); }
        return $out;
    }

    private function recvPacket()
    {
        if (!$this->enc) {
            // ۴ بایت طول + ۱ بایت padding_length، بعد (len-1) بایت باقی‌مانده
            // (payload + padding) — فقط موقع KEXINIT/KEX (قبل از رمزنگاری) استفاده می‌شه.
            $head = $this->readRaw(5);
            $len = unpack('N', substr($head, 0, 4))[1];
            $pad = ord($head[4]);
            $rest = $this->readRaw($len - 1);
            $payload = substr($rest, 0, $len - 1 - $pad);
            $this->seqIn = ($this->seqIn + 1) & 0xFFFFFFFF;
            return $payload;
        }
        $first = $this->readRaw(16);
        $firstDec = openssl_decrypt($first, 'aes-128-ctr', $this->enc['encKeyS'], OPENSSL_RAW_DATA, $this->enc['ivS']);
        $len = unpack('N', substr($firstDec, 0, 4))[1];
        if ($len > 262144) { throw new Exception('bad packet length'); }
        $total = 4 + $len;
        $restCipher = $total > 16 ? $this->readRaw($total - 16) : '';
        $mac = $this->readRaw(32);
        $this->enc['ivS'] = self::ctrAdvance($this->enc['ivS'], 16);
        $restDec = $restCipher !== '' ? openssl_decrypt($restCipher, 'aes-128-ctr', $this->enc['encKeyS'], OPENSSL_RAW_DATA, $this->enc['ivS']) : '';
        if ($restCipher !== '') { $this->enc['ivS'] = self::ctrAdvance($this->enc['ivS'], strlen($restCipher)); }
        $pkt = $firstDec . $restDec;
        $expMac = hash_hmac('sha256', self::u32($this->seqIn) . $pkt, $this->enc['macKeyS'], true);
        if (!hash_equals($expMac, $mac)) { throw new Exception('MAC mismatch'); }
        $pad = ord($pkt[4]);
        $payload = substr($pkt, 5, $total - $pad - 5);
        $this->seqIn = ($this->seqIn + 1) & 0xFFFFFFFF;
        return $payload;
    }

    private function nextMsg()
    {
        while (true) {
            $p = $this->recvPacket();
            $t = ord($p[0]);
            if ($t === 2 || $t === 4 || $t === 53) { continue; } // ignore/debug/ext-info
            if ($t === 1) {
                $pos = 5; $msg = self::readStr($p, $pos);
                throw new Exception('server disconnect: ' . $msg);
            }
            return $p;
        }
    }

    public function handshakeAndAuth($user, $password, $cols = 200, $rows = 50)
    {
        $vc = 'SSH-2.0-SimplePHPSSH_1.0';
        fwrite($this->sock, $vc . "\r\n");
        $vs = '';
        for ($i = 0; $i < 60; $i++) {
            $vs = $this->readLine(3000);
            if (strpos($vs, 'SSH-') === 0) { break; }
        }
        if (strpos($vs, 'SSH-') !== 0) { throw new Exception('not an SSH server'); }

        $kexAlgos = ['curve25519-sha256', 'curve25519-sha256@libssh.org'];
        $hostKeyAlgos = ['ssh-ed25519', 'rsa-sha2-256', 'rsa-sha2-512', 'ecdsa-sha2-nistp256'];
        $cipher = ['aes128-ctr'];
        $mac = ['hmac-sha256'];
        $kiList = [
            implode(',', $kexAlgos), implode(',', $hostKeyAlgos),
            implode(',', $cipher), implode(',', $cipher),
            implode(',', $mac), implode(',', $mac),
            'none', 'none', '', '',
        ];
        $ki = chr(20) . random_bytes(16);
        foreach ($kiList as $x) { $ki .= self::str($x); }
        $ki .= chr(0) . self::u32(0);
        $this->sendPacket($ki);
        $sk = $this->nextMsg();
        if (ord($sk[0]) !== 20) { throw new Exception('expected KEXINIT'); }

        // X25519 keypair via libsodium
        $kp = sodium_crypto_box_keypair();
        $privRaw = sodium_crypto_box_secretkey($kp);
        $pubRaw = sodium_crypto_box_publickey($kp);
        // sodium_crypto_box keys ARE x25519 keys already (crypto_box uses Curve25519).

        $this->sendPacket(chr(30) . self::str($pubRaw));
        $rep = $this->nextMsg();
        if (ord($rep[0]) !== 31) { throw new Exception('kex failed (type ' . ord($rep[0]) . ')'); }
        $pos = 1;
        $ks = self::readStr($rep, $pos);
        $qs = self::readStr($rep, $pos);
        // امضای سرور رو عمداً چک نمی‌کنیم (مثل نسخه‌ی قبلی) — سادگی در برابر امنیت کامل.

        $sharedK = sodium_crypto_scalarmult($privRaw, $qs);
        $kk = self::mpint($sharedK);

        $H = hash('sha256', self::str($vc) . self::str($vs) . self::str($ki) . self::str($sk) . self::str($ks) . self::str($pubRaw) . self::str($qs) . $kk, true);
        $this->sessionId = $H;

        $this->sendPacket(chr(21));
        $nk = $this->nextMsg();
        if (ord($nk[0]) !== 21) { throw new Exception('expected NEWKEYS'); }

        $derive = function ($letter) use ($kk, $H) {
            return hash('sha256', $kk . $H . $letter . $H, true);
        };
        $ivC = substr($derive('A'), 0, 16);
        $ivS = substr($derive('B'), 0, 16);
        $encKeyC = substr($derive('C'), 0, 16);
        $encKeyS = substr($derive('D'), 0, 16);
        $macKeyC = substr($derive('E'), 0, 32);
        $macKeyS = substr($derive('F'), 0, 32);
        $this->enc = compact('ivC', 'ivS', 'encKeyC', 'encKeyS', 'macKeyC', 'macKeyS');

        $this->sendPacket(chr(5) . self::str('ssh-userauth'));
        $sa = $this->nextMsg();
        if (ord($sa[0]) !== 6) { throw new Exception('service refused'); }

        $this->sendPacket(chr(50) . self::str($user) . self::str('ssh-connection') . self::str('password') . chr(0) . self::str($password));
        while (true) {
            $m = $this->nextMsg();
            $t = ord($m[0]);
            if ($t === 52) { break; }
            if ($t === 51) {
                $pos = 1; $allowed = self::readStr($m, $pos);
                throw new Exception('authentication failed (allowed: ' . $allowed . ')');
            }
        }

        $this->sendPacket(chr(90) . self::str('session') . self::u32(0) . self::u32($this->chanLocalWindow) . self::u32(32768));
        while (true) {
            $m = $this->nextMsg();
            $t = ord($m[0]);
            if ($t === 91) {
                $pos = 1; self::readU32($m, $pos);
                $this->chanRemote = self::readU32($m, $pos);
                $this->chanRemoteWindow = self::readU32($m, $pos);
                break;
            }
            if ($t === 92) { throw new Exception('channel open refused'); }
        }

        $this->sendPacket(chr(98) . self::u32($this->chanRemote) . self::str('pty-req') . chr(0) . self::str('xterm-256color') . self::u32($cols) . self::u32($rows) . self::u32(0) . self::u32(0) . self::str(''));
        $this->sendPacket(chr(98) . self::u32($this->chanRemote) . self::str('shell') . chr(0));
    }

    public function write($s)
    {
        if ($this->closed) { throw new Exception('connection closed'); }
        $len = strlen($s);
        for ($i = 0; $i < $len; $i += 16384) {
            $chunk = substr($s, $i, 16384);
            $this->sendPacket(chr(94) . self::u32($this->chanRemote) . self::str($chunk));
        }
    }

    /**
     * برای حداکثر $maxMs میلی‌ثانیه، هر پکتی که آماده‌ست رو می‌خونه و داده‌ی
     * کانال رو به $this->buf اضافه می‌کنه (و لاگ می‌کنه). throw نمی‌کنه مگر
     * اتصال واقعاً قطع بشه.
     */
    public function pump($maxMs = 300)
    {
        $deadline = microtime(true) + ($maxMs / 1000);
        while (microtime(true) < $deadline) {
            $read = [$this->sock]; $write = null; $except = null;
            $n = @stream_select($read, $write, $except, 0, 100000);
            if ($n === false) { $this->closed = true; return; }
            if ($n === 0) { continue; }
            try {
                $p = $this->recvPacket();
            } catch (Exception $e) {
                $this->closed = true;
                return;
            }
            $t = ord($p[0]);
            if ($t === 94 || $t === 95) {
                $pos = 1; self::readU32($p, $pos);
                if ($t === 95) { self::readU32($p, $pos); }
                $data = self::readStr($p, $pos);
                $this->chanLocalWindow -= strlen($data);
                $this->buf .= $data;
                if ($this->logCallback) { call_user_func($this->logCallback, $data); }
                if ($this->chanLocalWindow < 1048576) {
                    $this->chanLocalWindow += 1048576;
                    $this->sendPacket(chr(93) . self::u32($this->chanRemote) . self::u32(1048576));
                }
            } elseif ($t === 93) {
                $pos = 1; self::readU32($p, $pos);
                $this->chanRemoteWindow += self::readU32($p, $pos);
            } elseif ($t === 80) {
                $pos = 1; self::readStr($p, $pos);
                $wantReply = ord(substr($p, $pos, 1));
                if ($wantReply) { $this->sendPacket(chr(82)); }
            } elseif ($t === 96 || $t === 97) {
                if ($t === 97) { $this->closed = true; return; }
            } elseif ($t === 1) {
                $this->closed = true; return;
            }
        }
    }

    public function close()
    {
        $this->closed = true;
        try { $this->sendPacket(chr(97) . self::u32($this->chanRemote)); } catch (Exception $e) {}
        if ($this->sock) { @fclose($this->sock); }
    }
}
