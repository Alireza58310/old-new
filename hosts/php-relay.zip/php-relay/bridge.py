#!/usr/bin/env python3
"""
bridge.py — یه SOCKS5 محلی که هر کانکشن رو از طریق tunnel.php (روی هاستت)
به اینترنت وصل می‌کنه. فقط کتابخونه‌ی استاندارد پایتونه، نیازی به
pip install نیست (روی Termux هم با همون python خام کار می‌کنه).

اجرا:
    python bridge.py --url https://your-host.com/tunnel.php --key alireza

بعدش توی اپ‌ها/مرورگرت: socks5://127.0.0.1:1080
"""
import argparse
import base64
import json
import socket
import struct
import threading
import time
import urllib.error
import urllib.parse
import urllib.request

POLL_INTERVAL = 0.15
HTTP_TIMEOUT = 20


def api_call(base_url, action, method, params, retries=2):
    for attempt in range(retries + 1):
        try:
            if method == 'POST':
                data = urllib.parse.urlencode(params).encode()
                req = urllib.request.Request(base_url + '?action=' + action, data=data, method='POST')
            else:
                qs = urllib.parse.urlencode(dict(params, action=action))
                req = urllib.request.Request(base_url + '?' + qs, method='GET')
            with urllib.request.urlopen(req, timeout=HTTP_TIMEOUT) as resp:
                return json.loads(resp.read().decode('utf-8'))
        except Exception as e:
            if attempt == retries:
                return {'ok': False, 'error': str(e)}
            time.sleep(0.4)


def recv_exact(conn, n):
    buf = b''
    while len(buf) < n:
        chunk = conn.recv(n - len(buf))
        if not chunk:
            raise ConnectionError('local socket closed')
        buf += chunk
    return buf


def socks5_reply(conn, rep):
    conn.sendall(bytes([5, rep, 0, 1, 0, 0, 0, 0, 0, 0]))


def uploader(conn, base_url, key, sid, stop_event):
    try:
        while not stop_event.is_set():
            data = conn.recv(32768)
            if not data:
                break
            res = api_call(base_url, 'send', 'POST', {'sid': sid, 'data': base64.b64encode(data).decode(), 'key': key})
            if not res or not res.get('ok'):
                break
    except Exception:
        pass
    finally:
        stop_event.set()
        api_call(base_url, 'close', 'POST', {'sid': sid, 'key': key}, retries=0)


def downloader(conn, base_url, key, sid, stop_event):
    since = 0
    try:
        while not stop_event.is_set():
            res = api_call(base_url, 'recv', 'GET', {'sid': sid, 'since': since, 'key': key})
            if not res or not res.get('ok'):
                break
            chunk = base64.b64decode(res.get('data', '') or '')
            if chunk:
                conn.sendall(chunk)
            since = res.get('size', since)
            if res.get('error'):
                break
            if res.get('closed') and not chunk:
                break
            time.sleep(POLL_INTERVAL)
    except Exception:
        pass
    finally:
        stop_event.set()


def handle_client(conn, base_url, key):
    try:
        conn.settimeout(30)
        hdr = recv_exact(conn, 2)
        nmethods = hdr[1]
        recv_exact(conn, nmethods)  # روش‌های auth پیشنهادی کلاینت رو نادیده می‌گیریم
        conn.sendall(bytes([5, 0]))  # همیشه "no auth" رو انتخاب می‌کنیم

        req = recv_exact(conn, 4)
        cmd, atyp = req[1], req[3]
        if cmd != 1:  # فقط CONNECT پشتیبانی می‌شه
            socks5_reply(conn, 7)
            return

        if atyp == 1:
            host = socket.inet_ntoa(recv_exact(conn, 4))
        elif atyp == 3:
            ln = recv_exact(conn, 1)[0]
            host = recv_exact(conn, ln).decode('utf-8', errors='replace')
        elif atyp == 4:
            host = socket.inet_ntop(socket.AF_INET6, recv_exact(conn, 16))
        else:
            socks5_reply(conn, 8)
            return
        port = struct.unpack('>H', recv_exact(conn, 2))[0]

        res = api_call(base_url, 'open', 'POST', {'host': host, 'port': port, 'key': key})
        if not res or not res.get('ok'):
            socks5_reply(conn, 1)
            return
        sid = res['sid']
        conn.settimeout(None)
        socks5_reply(conn, 0)

        stop_event = threading.Event()
        t_up = threading.Thread(target=uploader, args=(conn, base_url, key, sid, stop_event), daemon=True)
        t_down = threading.Thread(target=downloader, args=(conn, base_url, key, sid, stop_event), daemon=True)
        t_up.start()
        t_down.start()
        t_up.join()
        t_down.join()
    except Exception:
        pass
    finally:
        try:
            conn.close()
        except Exception:
            pass


def main():
    p = argparse.ArgumentParser(description='Local SOCKS5 bridge for the PHP tunnel.')
    p.add_argument('--url', required=True, help='e.g. https://your-host.com/tunnel.php')
    p.add_argument('--key', required=True, help='same as RELAY_PASSWORD in config.php')
    p.add_argument('--listen-host', default='127.0.0.1')
    p.add_argument('--listen-port', type=int, default=1080)
    args = p.parse_args()

    base_url = args.url.rstrip('/')
    srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    srv.bind((args.listen_host, args.listen_port))
    srv.listen(50)
    print('SOCKS5 listening on %s:%d' % (args.listen_host, args.listen_port))
    print('Backend: %s' % base_url)
    print('Point apps at: socks5://%s:%d' % (args.listen_host, args.listen_port))

    try:
        while True:
            conn, _addr = srv.accept()
            threading.Thread(target=handle_client, args=(conn, base_url, args.key), daemon=True).start()
    except KeyboardInterrupt:
        print('\nbye')
    finally:
        srv.close()


if __name__ == '__main__':
    main()
