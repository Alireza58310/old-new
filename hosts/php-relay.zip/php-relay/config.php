<?php
// ⚠️ اول این رمز رو عوض کن! هرکی این رمز رو بدونه می‌تونه از رله‌ی تو
// (که روی هاست با آیپی تمیزته) به‌عنوان یه پراکسی باز استفاده کنه — هم
// امنیتت رو به خطر می‌ندازه هم ممکنه هاستت رو به‌خاطر سوءاستفاده‌ی بقیه
// ببنده.
define('RELAY_PASSWORD', 'alireza');

// بعد از ورود موفق، لاگین چند ساعت یادش می‌مونه (نیازی به رمز دوباره نیست)
define('RELAY_SESSION_HOURS', 2);

/**
 * session_start() ساده کافی نیست: پیش‌فرض PHP یه session cookie بدون
 * عمر مشخصه (با بسته‌شدن اپ/قطعی پاک می‌شه)، و session.gc_maxlifetime
 * خیلی از هاست‌ها هم کوتاهه (مثلاً ۲۴ دقیقه) — یعنی حتی اگه کوکی بمونه،
 * خودِ فایل session روی هاست زودتر پاک می‌شه. برای همین صریح هم عمر کوکی
 * هم gc_maxlifetime رو با RELAY_SESSION_HOURS ست می‌کنیم.
 */
function relay_start_session()
{
    if (session_status() === PHP_SESSION_ACTIVE) { return; }
    $lifetime = RELAY_SESSION_HOURS * 3600;
    ini_set('session.gc_maxlifetime', (string) $lifetime);
    $secure = !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off';
    session_set_cookie_params([
        'lifetime' => $lifetime,
        'path' => '/',
        'secure' => $secure,
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
    session_start();
}

// حداکثر حجم هر پاسخ (بایت) که از سایت مقصد می‌گیریم — جلوی مصرف
// بیش‌ازحد منابع هاست رو می‌گیره. ۲۵ مگابایت برای اکثر صفحات کافیه.
define('RELAY_MAX_BYTES', 25 * 1024 * 1024);

// برای صفحاتی که گواهی SSL قدیمی/نامعتبر دارن و CA bundle هاست هم
// آپدیت نیست، اگه اتصال HTTPS شکست خورد یه بار بدون تایید گواهی هم
// امتحان می‌کنیم.
define('RELAY_SSL_FALLBACK', true);
