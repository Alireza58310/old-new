<?php
require_once __DIR__ . '/config.php';
relay_start_session();

// ---------------------------------------------------------------------
// احراز هویت ساده: بدون این، هر کسی که آدرس این صفحه رو حدس بزنه می‌تونه
// از رله‌ی تو مثل یه پراکسی باز استفاده کنه.
// ---------------------------------------------------------------------
function is_authed()
{
    return isset($_SESSION['relay_auth_until']) && $_SESSION['relay_auth_until'] > time();
}

if (isset($_POST['relay_password'])) {
    if (hash_equals(RELAY_PASSWORD, (string) $_POST['relay_password'])) {
        $_SESSION['relay_auth_until'] = time() + RELAY_SESSION_HOURS * 3600;
        header('Location: ' . strtok($_SERVER['REQUEST_URI'], '?'));
        exit;
    }
    $loginError = 'رمز اشتباهه.';
}

if (!is_authed()) {
    render_login($loginError ?? null);
    exit;
}

// ---------------------------------------------------------------------
// فچ از مقصد (با cURL، و اگه نبود با stream context)
// ---------------------------------------------------------------------
function cookie_jar_key($host) { return 'relay_cookies_' . $host; }

function cookie_header_for($host)
{
    $jar = $_SESSION[cookie_jar_key($host)] ?? [];
    if (!$jar) { return ''; }
    $parts = [];
    foreach ($jar as $k => $v) { $parts[] = $k . '=' . $v; }
    return implode('; ', $parts);
}

function store_set_cookies($host, $rawHeader)
{
    // ممکنه چندتا Set-Cookie پشت سر هم با \n جدا شده باشن (وقتی با cURL می‌گیریم)
    foreach (preg_split('/\r?\n/', $rawHeader) as $line) {
        if (stripos($line, 'set-cookie:') !== 0) { continue; }
        $value = trim(substr($line, strlen('set-cookie:')));
        $firstPart = explode(';', $value, 2)[0];
        if (strpos($firstPart, '=') === false) { continue; }
        [$k, $v] = explode('=', $firstPart, 2);
        $k = trim($k); $v = trim($v);
        if ($k === '') { continue; }
        $_SESSION[cookie_jar_key($host)][$k] = $v;
    }
}

function relay_fetch($url, $method = 'GET', $postFields = null)
{
    $host = parse_url($url, PHP_URL_HOST);
    $result = ['body' => '', 'contentType' => 'text/html; charset=utf-8', 'finalUrl' => $url, 'status' => 0];

    if (function_exists('curl_init')) {
        $attempt = function ($verifySsl) use ($url, $method, $postFields, $host) {
            $ch = curl_init();
            curl_setopt_array($ch, [
                CURLOPT_URL => $url,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_HEADER => true,
                CURLOPT_FOLLOWLOCATION => true,
                CURLOPT_MAXREDIRS => 8,
                CURLOPT_TIMEOUT => 30,
                CURLOPT_CONNECTTIMEOUT => 12,
                CURLOPT_SSL_VERIFYPEER => $verifySsl,
                CURLOPT_SSL_VERIFYHOST => $verifySsl ? 2 : 0,
                CURLOPT_ENCODING => '', // بذار cURL خودش gzip/deflate رو handle کنه
                CURLOPT_USERAGENT => 'Mozilla/5.0 (Linux; Android 13; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0 Mobile Safari/537.36',
                CURLOPT_HTTPHEADER => array_filter([
                    'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
                    'Accept-Language: fa,en-US;q=0.8,en;q=0.7',
                    $host ? ('Cookie: ' . cookie_header_for($host)) : null,
                ]),
                CURLOPT_BUFFERSIZE => 65536,
            ]);
            if ($method === 'POST') {
                curl_setopt($ch, CURLOPT_POST, true);
                curl_setopt($ch, CURLOPT_POSTFIELDS, $postFields ?? '');
            }
            $raw = curl_exec($ch);
            $err = curl_error($ch);
            $info = curl_getinfo($ch);
            curl_close($ch);
            return [$raw, $err, $info];
        };

        [$raw, $err, $info] = $attempt(true);
        if (($raw === false || $raw === null) && RELAY_SSL_FALLBACK) {
            [$raw, $err, $info] = $attempt(false);
        }
        if ($raw === false || $raw === null) {
            throw new Exception('fetch failed: ' . $err);
        }

        $headerSize = $info['header_size'] ?? 0;
        $rawHeaders = substr($raw, 0, $headerSize);
        $body = substr($raw, $headerSize);
        if (strlen($body) > RELAY_MAX_BYTES) { $body = substr($body, 0, RELAY_MAX_BYTES); }

        if ($host) { store_set_cookies($host, $rawHeaders); }

        $ct = $info['content_type'] ?: 'application/octet-stream';
        $result['body'] = $body;
        $result['contentType'] = $ct;
        $result['finalUrl'] = $info['url'] ?: $url;
        $result['status'] = $info['http_code'];
        return $result;
    }

    // --- fallback بدون cURL (نادره، ولی برای کامل بودن) ---
    $headers = [
        'Accept: text/html,application/xhtml+xml,*/*;q=0.8',
        'User-Agent: Mozilla/5.0 (Linux; Android 13; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0 Mobile Safari/537.36',
    ];
    if ($host) { $headers[] = 'Cookie: ' . cookie_header_for($host); }
    $opts = ['http' => ['method' => $method, 'header' => implode("\r\n", $headers), 'timeout' => 30, 'follow_location' => 1, 'ignore_errors' => true],
             'https' => ['method' => $method, 'header' => implode("\r\n", $headers), 'timeout' => 30, 'follow_location' => 1, 'ignore_errors' => true]];
    if ($method === 'POST') { $opts['http']['content'] = $postFields ?? ''; $opts['https']['content'] = $postFields ?? ''; }
    $ctx = stream_context_create($opts);
    $body = @file_get_contents($url, false, $ctx);
    if ($body === false) { throw new Exception('fetch failed (stream fallback)'); }
    if (strlen($body) > RELAY_MAX_BYTES) { $body = substr($body, 0, RELAY_MAX_BYTES); }
    $ct = 'text/html; charset=utf-8';
    if (isset($http_response_header)) {
        foreach ($http_response_header as $h) {
            if (stripos($h, 'content-type:') === 0) { $ct = trim(substr($h, 13)); }
            if ($host && stripos($h, 'set-cookie:') === 0) { store_set_cookies($host, $h); }
        }
    }
    $result['body'] = $body;
    $result['contentType'] = $ct;
    return $result;
}

// ---------------------------------------------------------------------
// تبدیل آدرس نسبی به مطلق، و ساخت لینک‌هایی که از رله‌ی خودمون رد می‌شن
// ---------------------------------------------------------------------
function self_script()
{
    return strtok($_SERVER['REQUEST_URI'], '?');
}

function proxy_link($absoluteUrl, $forceWrapper = false)
{
    global $inFrame;
    $url = self_script() . '?u=' . rawurlencode($absoluteUrl);
    if ($inFrame && !$forceWrapper) { $url .= '&frame=1'; }
    return $url;
}

function resolve_url($base, $rel)
{
    $rel = trim($rel);
    if ($rel === '' || stripos($rel, 'javascript:') === 0 || stripos($rel, 'data:') === 0 || stripos($rel, 'mailto:') === 0 || stripos($rel, 'tel:') === 0 || $rel[0] === '#') {
        return null; // این‌جور لینک‌ها دست‌نخورده می‌مونن (یا نادیده گرفته می‌شن)
    }
    if (preg_match('#^[a-z][a-z0-9+.-]*://#i', $rel)) { return $rel; } // از قبل مطلقه
    $baseParts = parse_url($base);
    $scheme = $baseParts['scheme'] ?? 'https';
    $host = $baseParts['host'] ?? '';
    if (strpos($rel, '//') === 0) { return $scheme . ':' . $rel; }
    if ($rel[0] === '/') { return $scheme . '://' . $host . $rel; }
    // مسیر نسبی: نسبت به دایرکتوری base
    $basePath = $baseParts['path'] ?? '/';
    $slashPos = strrpos($basePath, '/');
    $dir = ($slashPos !== false) ? substr($basePath, 0, $slashPos + 1) : '/';
    if ($dir === '') { $dir = '/'; }
    $combined = $dir . $rel;
    // حذف ./ و ../
    $segs = explode('/', $combined);
    $out = [];
    foreach ($segs as $seg) {
        if ($seg === '.' || $seg === '') { continue; }
        if ($seg === '..') { array_pop($out); continue; }
        $out[] = $seg;
    }
    $path = '/' . implode('/', $out);
    return $scheme . '://' . $host . $path;
}

// ---------------------------------------------------------------------
// بازنویسی HTML: همه‌ی لینک‌ها/فرم‌ها/منابع از رله رد بشن + نوار آدرس تزریق بشه
// ---------------------------------------------------------------------
function rewrite_html($html, $baseUrl)
{
    $attrs = ['href' => 'a,link,area', 'src' => 'img,script,iframe,source,audio,video,embed', 'action' => 'form'];
    $doc = new DOMDocument();
    libxml_use_internal_errors(true);
    $doc->loadHTML('<?xml encoding="utf-8"?>' . $html, LIBXML_NOWARNING | LIBXML_NOERROR);
    libxml_clear_errors();

    foreach ($attrs as $attr => $tagsCsv) {
        foreach (explode(',', $tagsCsv) as $tag) {
            foreach ($doc->getElementsByTagName($tag) as $el) {
                if ($tag === 'form') {
                    // فرم GET: مرورگر هنگام سابمیت، هر query string موجود
                    // توی action رو کاملاً دور می‌ریزه، پس "?u=..." از بین
                    // می‌ره. برای همین "u" رو به‌جاش یه input مخفی می‌کنیم.
                    $formAction = $el->hasAttribute('action') ? $el->getAttribute('action') : $baseUrl;
                    $abs = resolve_url($baseUrl, $formAction) ?? $baseUrl;
                    $method = strtolower($el->getAttribute('method') ?: 'get');
                    if ($method === 'post') {
                        $el->setAttribute('action', proxy_link($abs));
                    } else {
                        global $inFrame;
                        $el->setAttribute('action', self_script());
                        $hidden = $doc->createElement('input');
                        $hidden->setAttribute('type', 'hidden');
                        $hidden->setAttribute('name', 'u');
                        $hidden->setAttribute('value', $abs);
                        if ($el->firstChild) { $el->insertBefore($hidden, $el->firstChild); } else { $el->appendChild($hidden); }
                        if ($inFrame) {
                            $hiddenFrame = $doc->createElement('input');
                            $hiddenFrame->setAttribute('type', 'hidden');
                            $hiddenFrame->setAttribute('name', 'frame');
                            $hiddenFrame->setAttribute('value', '1');
                            $el->insertBefore($hiddenFrame, $hidden->nextSibling);
                        }
                    }
                    continue;
                }
                if (!$el->hasAttribute($attr)) { continue; }
                $val = $el->getAttribute($attr);
                $abs = resolve_url($baseUrl, $val);
                if ($abs === null) { continue; }
                // لینک‌هایی که target="_blank" دارن توی یه تب جدید باز می‌شن —
                // اونجا باید حالت wrapper (با نوار آدرس) نشون بدیم، نه frame خام.
                $forceWrapper = ($tag === 'a' && strtolower($el->getAttribute('target')) === '_blank');
                $el->setAttribute($attr, proxy_link($abs, $forceWrapper));
            }
        }
    }
    // srcset (چند تا منبع با کاما، برای تصاویر ریسپانسیو)
    foreach ($doc->getElementsByTagName('img') as $el) {
        if (!$el->hasAttribute('srcset')) { continue; }
        $parts = array_map('trim', explode(',', $el->getAttribute('srcset')));
        $new = [];
        foreach ($parts as $p) {
            $bits = preg_split('/\s+/', $p, 2);
            $abs = resolve_url($baseUrl, $bits[0]);
            if ($abs !== null) { $bits[0] = proxy_link($abs); }
            $new[] = implode(' ', $bits);
        }
        $el->setAttribute('srcset', implode(', ', $new));
    }
    // <meta http-equiv="refresh" content="N;url=..."> هم باید به رله برگرده
    foreach ($doc->getElementsByTagName('meta') as $el) {
        if (strtolower($el->getAttribute('http-equiv')) !== 'refresh') { continue; }
        $content = $el->getAttribute('content');
        if (preg_match('/^(\d+)\s*;\s*url=(.+)$/i', trim($content), $mm)) {
            $abs = resolve_url($baseUrl, trim($mm[2], " \t'\""));
            if ($abs !== null) { $el->setAttribute('content', $mm[1] . ';url=' . proxy_link($abs)); }
        }
    }
    // <base> رو حذف می‌کنیم چون خودمون base رو مدیریت می‌کنیم
    foreach (iterator_to_array($doc->getElementsByTagName('base')) as $el) {
        $el->parentNode->removeChild($el);
    }
    // style های اینلاین با url(...)
    $xpath = new DOMXPath($doc);
    foreach ($xpath->query('//*[@style]') as $el) {
        $el->setAttribute('style', rewrite_css_urls($el->getAttribute('style'), $baseUrl));
    }
    foreach ($doc->getElementsByTagName('style') as $el) {
        $el->textContent = rewrite_css_urls($el->textContent, $baseUrl);
    }

    $out = $doc->saveHTML();
    return inject_shim($out, $baseUrl);
}

/**
 * جاوااسکریپت سایت‌های نیمه‌پویا (که دیتاشون رو با fetch/XHR میارن، نه
 * کامل SPA) رو هم از رله رد می‌کنه، و لینک/تصویرهایی که بعد از لود صفحه
 * با جاوااسکریپت ساخته می‌شن (نه توی HTML اولیه) رو هم می‌گیره.
 * ⚠️ این فقط پوشش رو بیشتر می‌کنه، نه کامل‌شون — اپ‌های تک‌صفحه‌ای مدرن
 * (React/Vue با روتینگ کامل کلاینتی) همچنان ممکنه کامل کار نکنن.
 */
function inject_shim($html, $baseUrl)
{
    $base = json_encode($baseUrl);
    $self = json_encode(self_script());
    $js = <<<JS
<script>(function(){
  var BASE = {$base}, SELF = {$self};
  // این شیم همیشه داخل iframe (حالت frame=1) اجراش می‌شه، پس هر لینک
  // جدیدی هم که خودِ صفحه بسازه باید توی همون iframe بمونه.
  function resolve(u){ try { return new URL(u, BASE).href; } catch(e){ return null; } }
  function toProxy(u){
    if (!u || /^(javascript:|data:|mailto:|tel:|#)/i.test(u) || u.indexOf(SELF) === 0) return u;
    var abs = resolve(u);
    return abs ? (SELF + '?u=' + encodeURIComponent(abs) + '&frame=1') : u;
  }
  // وانمود کردن به یه مرورگر موبایل کروم بروز، برای اسکریپت‌های سایت که
  // خودشون (نه سرور) دارن navigator.userAgent رو چک می‌کنن.
  try {
    var UA = 'Mozilla/5.0 (Linux; Android 13; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0 Mobile Safari/537.36';
    Object.defineProperty(navigator, 'userAgent', { get: function(){ return UA; }, configurable: true });
    Object.defineProperty(navigator, 'appVersion', { get: function(){ return '5.0 (Linux; Android 13; Mobile)'; }, configurable: true });
    Object.defineProperty(navigator, 'vendor', { get: function(){ return 'Google Inc.'; }, configurable: true });
    Object.defineProperty(navigator, 'platform', { get: function(){ return 'Linux armv8l'; }, configurable: true });
  } catch(e){}
  // به صفحه‌ی بیرونی (نوار آدرس) بگو الان واقعاً کجاییم، تا آدرس/عنوان رو آپدیت کنه.
  try { window.parent.postMessage({ type: 'relay-nav', url: BASE, title: document.title }, '*'); } catch(e){}
  document.addEventListener('DOMContentLoaded', function(){
    try { window.parent.postMessage({ type: 'relay-nav', url: BASE, title: document.title }, '*'); } catch(e){}
  });
  if (window.fetch) {
    var origFetch = window.fetch;
    window.fetch = function(input, init){
      try {
        if (typeof input === 'string') { input = toProxy(input); }
        else if (input && input.url) { input = new Request(toProxy(input.url), input); }
      } catch(e){}
      return origFetch.call(this, input, init);
    };
  }
  var origOpen = XMLHttpRequest.prototype.open;
  XMLHttpRequest.prototype.open = function(method, url){
    var args = Array.prototype.slice.call(arguments);
    try { args[1] = toProxy(url); } catch(e){}
    return origOpen.apply(this, args);
  };
  function rewriteEl(el){
    if (!el.getAttribute) return;
    ['href','src'].forEach(function(attr){
      var v = el.getAttribute(attr);
      if (v) { el.setAttribute(attr, toProxy(v)); }
    });
  }
  function scan(root){
    if (root.querySelectorAll) {
      root.querySelectorAll('[href],[src]').forEach(rewriteEl);
    }
  }
  document.addEventListener('DOMContentLoaded', function(){ scan(document); });
  new MutationObserver(function(muts){
    muts.forEach(function(m){
      m.addedNodes && m.addedNodes.forEach(function(n){
        if (n.nodeType !== 1) return;
        rewriteEl(n);
        scan(n);
      });
    });
  }).observe(document.documentElement, { childList: true, subtree: true });
})();</script>
JS;
    if (stripos($html, '<head') !== false) {
        $html = preg_replace_callback('/(<head[^>]*>)/i', function ($m) use ($js) { return $m[1] . $js; }, $html, 1);
    } else {
        $html = $js . $html;
    }
    return $html;
}

function rewrite_css_urls($css, $baseUrl)
{
    return preg_replace_callback('/url\(\s*([\'"]?)([^\'")]+)\1\s*\)/i', function ($m) use ($baseUrl) {
        $abs = resolve_url($baseUrl, $m[2]);
        if ($abs === null) { return $m[0]; }
        return 'url(' . proxy_link($abs) . ')';
    }, $css);
}

/**
 * صفحه‌ی بیرونی: فقط نوار آدرس + یه iframe که محتوای واقعی (حالت frame=1)
 * توش لود می‌شه. چون صفحه‌ی اصلی (همینی که مرورگر توی نوار آدرسش نشون
 * می‌ده) همیشه همین رله‌ست، هر navigation داخلی (کلیک لینک، فرم، حتی
 * window.location از جاوااسکریپت خودِ سایت) فقط داخل iframe اتفاق
 * می‌افته و آدرس واقعی مرورگر دست‌نخورده می‌مونه.
 */
function render_wrapper($targetUrl)
{
    header('Content-Type: text/html; charset=utf-8');
    $frameSrc = self_script() . '?u=' . rawurlencode($targetUrl) . '&frame=1';
    echo '<!doctype html><html lang="fa" dir="rtl"><head><meta charset="utf-8"/>'
        . '<meta name="viewport" content="width=device-width, initial-scale=1"/>'
        . '<title>Relay</title>' . relay_base_style()
        . '<style>
        html,body{margin:0;height:100%;background:#0a0d12}
        #bar{display:flex;gap:7px;align-items:center;padding:8px 10px;background:#11161dee;border-bottom:1px solid #232c37;
             direction:ltr;box-shadow:0 2px 14px rgba(0,0,0,.35)}
        #bar a{color:#8b98a5;text-decoration:none;width:34px;height:34px;display:flex;align-items:center;justify-content:center;
               background:#1c2834;border-radius:9px;font-size:15px;flex:none}
        #bar form{display:flex;gap:7px;flex:1;min-width:0}
        #bar input{flex:1;min-width:0;padding:9px 12px;border-radius:9px;border:1px solid #232c37;background:#0e141b;color:#e6edf3;font-size:12.5px}
        #bar button{padding:0 16px;border-radius:9px;border:none;background:#3b82f6;color:#fff;font-size:13px;font-weight:700;cursor:pointer;flex:none}
        #relayFrame{border:0;width:100%;display:block;height:calc(100vh - 52px)}
        </style></head><body>'
        . '<div id="bar" dir="ltr">'
        . '<a href="' . htmlspecialchars(self_script()) . '" title="Home">🏠</a>'
        . '<a href="tunnel.php" title="SOCKS5 Tunnel" target="_top">⚙️</a>'
        . '<form method="get" action="' . htmlspecialchars(self_script()) . '">'
        . '<input name="u" value="' . htmlspecialchars($targetUrl) . '"/>'
        . '<button>Go</button>'
        . '</form></div>'
        . '<iframe id="relayFrame" src="' . htmlspecialchars($frameSrc) . '"></iframe>'
        . '<script>
        window.addEventListener("message", function(e){
          if (e.data && e.data.type === "relay-nav") {
            var inp = document.querySelector("#bar input[name=u]");
            if (inp && document.activeElement !== inp) { inp.value = e.data.url; }
            if (e.data.title) { document.title = e.data.title + " · Relay"; }
          }
        });
        </script>'
        . '</body></html>';
}

// ---------------------------------------------------------------------
// صفحه‌ی لاگین
// ---------------------------------------------------------------------
function relay_base_style()
{
    return '<link href="https://cdn.jsdelivr.net/gh/rastikerdar/vazirmatn@v33.003/Vazirmatn-font-face.css" rel="stylesheet"/>'
        . '<style>
        :root{--bg:#0a0d12;--panel:#121820;--panel2:#161d27;--border:#232c37;--text:#e6edf3;--muted:#8b98a5;--accent:#3b82f6;--accent2:#60a5fa}
        *{box-sizing:border-box}
        body{font-family:Vazirmatn,Tahoma,Arial,sans-serif}
        ::-webkit-scrollbar{width:8px;height:8px}
        ::-webkit-scrollbar-thumb{background:#2a3140;border-radius:5px}
        </style>';
}

function render_login($error)
{
    header('Content-Type: text/html; charset=utf-8');
    echo '<!doctype html><html lang="fa" dir="rtl"><head><meta charset="utf-8"/>'
        . '<meta name="viewport" content="width=device-width, initial-scale=1"/>'
        . '<title>Relay</title>' . relay_base_style()
        . '<style>
        body{background:radial-gradient(circle at 20% 15%,#111826,transparent 45%),radial-gradient(circle at 85% 80%,#0f1a2a,transparent 45%),#0a0d12;color:var(--text);
             display:flex;align-items:center;justify-content:center;min-height:100vh;margin:0}
        .card{background:var(--panel);border:1px solid var(--border);border-radius:18px;padding:30px;width:min(90vw,360px);
              box-shadow:0 20px 60px rgba(0,0,0,.45)}
        .logo{width:46px;height:46px;border-radius:12px;background:linear-gradient(135deg,var(--accent),#8b5cf6);
              display:flex;align-items:center;justify-content:center;font-size:22px;margin-bottom:14px}
        h2{margin:0 0 4px;font-size:19px}
        p.sub{color:var(--muted);font-size:13px;margin:0 0 18px}
        input{width:100%;padding:13px 14px;border-radius:10px;border:1px solid var(--border);background:#0e141b;color:var(--text);
              font-size:14px;box-sizing:border-box;transition:border-color .15s}
        input:focus{outline:none;border-color:var(--accent)}
        button{width:100%;padding:13px;border-radius:10px;border:none;background:var(--accent);color:#fff;margin-top:14px;
               font-weight:700;font-size:14px;cursor:pointer;transition:background .15s}
        button:hover{background:var(--accent2)}
        .err{color:#ef4444;font-size:13px;margin-top:10px;background:#2a1414;border:1px solid #4a1f1f;border-radius:8px;padding:8px 10px}
        </style></head><body>'
        . '<form class="card" method="post"><div class="logo">🌐</div><h2>Relay</h2><p class="sub">برای ورود به رله رمزت رو بزن</p>'
        . '<input type="password" name="relay_password" placeholder="رمز" autofocus/>'
        . '<button>ورود</button>'
        . ($error ? '<div class="err">' . htmlspecialchars($error) . '</div>' : '')
        . '</form></body></html>';
}

// ---------------------------------------------------------------------
// صفحه‌ی خانه (جستجو/آدرس — شبیه گوگل)
// ---------------------------------------------------------------------
function render_home()
{
    header('Content-Type: text/html; charset=utf-8');
    echo '<!doctype html><html lang="fa" dir="rtl"><head><meta charset="utf-8"/>'
        . '<meta name="viewport" content="width=device-width, initial-scale=1"/>'
        . '<title>Relay</title>' . relay_base_style()
        . '<style>
        body{background:radial-gradient(circle at 20% 15%,#111826,transparent 45%),radial-gradient(circle at 85% 80%,#0f1a2a,transparent 45%),#0a0d12;
             color:var(--text);display:flex;flex-direction:column;align-items:center;justify-content:center;min-height:100vh;margin:0;gap:22px;padding:16px}
        .logo{width:64px;height:64px;border-radius:18px;background:linear-gradient(135deg,var(--accent),#8b5cf6);
              display:flex;align-items:center;justify-content:center;font-size:30px;box-shadow:0 12px 30px rgba(59,130,246,.25)}
        h1{font-size:21px;margin:0}
        form{width:min(92vw,540px);display:flex;gap:8px;background:var(--panel);border:1px solid var(--border);border-radius:999px;padding:5px;
             box-shadow:0 16px 40px rgba(0,0,0,.4)}
        input{flex:1;padding:13px 18px;border-radius:999px;border:none;background:transparent;color:var(--text);font-size:15px}
        input:focus{outline:none}
        button{padding:0 24px;border-radius:999px;border:none;background:var(--accent);color:#fff;font-weight:700;cursor:pointer}
        .quick{display:flex;gap:8px;flex-wrap:wrap;justify-content:center;max-width:420px}
        .quick a{color:var(--muted);text-decoration:none;font-size:12.5px;background:var(--panel2);border:1px solid var(--border);
                 border-radius:999px;padding:6px 12px}
        .hint{color:var(--muted);font-size:12.5px;text-align:center;max-width:380px;line-height:1.7}
        </style></head><body>'
        . '<div class="logo">🌐</div><h1>Relay</h1>'
        . '<form method="get"><input name="u" placeholder="جستجو یا آدرس سایت..." autofocus/><button>Go</button></form>'
        . '<div class="quick">'
        . '<a href="?u=' . rawurlencode('https://html.duckduckgo.com/html/') . '">DuckDuckGo</a>'
        . '<a href="?u=' . rawurlencode('https://www.wikipedia.org') . '">Wikipedia</a>'
        . '<a href="tunnel.php">⚙️ تبدیل به SOCKS5</a>'
        . '</div>'
        . '<div class="hint">هر چیزی بزنی — یا یه آدرس سایت می‌ره، یا مثل یه موتور جستجو سرچش می‌کنه. همه‌ی لینک‌هایی که بعدش کلیک کنی هم از همین رله رد می‌شن.</div>'
        . '</body></html>';
}

// ---------------------------------------------------------------------
// روتینگ اصلی
// ---------------------------------------------------------------------
$u = $_GET['u'] ?? '';
if ($u === '') {
    render_home();
    exit;
}

$inFrame = isset($_GET['frame']) && $_GET['frame'] === '1';

// اگه شبیه آدرس نیست (فاصله داره یا نقطه نداره)، به‌عنوان سرچ گوگل درش بیار
$looksLikeUrl = (bool) preg_match('#^[a-z][a-z0-9+.-]*://#i', $u) || (strpos($u, ' ') === false && strpos($u, '.') !== false);
if (!$looksLikeUrl) {
    // گوگل برای ترافیک پراکسی/دیتاسنتری خیلی راحت کپچا می‌زنه؛
    // DuckDuckGo (نسخه‌ی HTML ساده‌ش) خیلی کمتر این مشکل رو داره.
    $target = 'https://html.duckduckgo.com/html/?q=' . rawurlencode($u);
} elseif (!preg_match('#^[a-z][a-z0-9+.-]*://#i', $u)) {
    $target = 'https://' . $u;
} else {
    $target = $u;
}

// اگه این یه سابمیت فرم GET بود (با input مخفی "u")، بقیه‌ی فیلدهای فرم
// هم توی $_GET هستن و باید به کوئری‌استرینگ مقصد اضافه بشن ("frame" مال
// خودمونه، نباید به سایت مقصد برسه).
$extraGet = $_GET; unset($extraGet['u'], $extraGet['frame']);
if ($extraGet) {
    $sep = (strpos($target, '?') !== false) ? '&' : '?';
    $target .= $sep . http_build_query($extraGet);
}

// ناوبری سطح بالا (نه داخل iframe) و نه POST: فقط پوسته‌ی نوار آدرس +
// iframe رو نشون بده؛ خودِ محتوا رو iframe با frame=1 جداگانه می‌گیره.
// این باعث می‌شه نوار آدرس واقعی مرورگر همیشه رو رله بمونه.
if (!$inFrame && $_SERVER['REQUEST_METHOD'] !== 'POST') {
    render_wrapper($target);
    exit;
}

try {
    $method = ($_SERVER['REQUEST_METHOD'] === 'POST') ? 'POST' : 'GET';
    $postFields = null;
    if ($method === 'POST') {
        $fields = $_POST; unset($fields['u']);
        $postFields = http_build_query($fields);
    }
    $res = relay_fetch($target, $method, $postFields);
} catch (Exception $e) {
    header('Content-Type: text/html; charset=utf-8');
    echo '<!doctype html><html lang="fa" dir="rtl"><head><meta charset="utf-8"/>'
        . '<meta name="viewport" content="width=device-width, initial-scale=1"/>' . relay_base_style()
        . '<style>body{background:#0a0d12;color:#e6edf3;min-height:100vh;margin:0;display:flex;align-items:center;justify-content:center;padding:20px}
        .card{background:#121820;border:1px solid #232c37;border-radius:16px;padding:26px;max-width:420px;text-align:center}
        a{color:#60a5fa;text-decoration:none;font-size:13.5px}</style></head><body>'
        . '<div class="card"><div style="font-size:30px">⚠️</div><h3>نشد به این آدرس وصل بشم</h3>'
        . '<p style="color:#8b98a5;font-size:13px">' . htmlspecialchars($e->getMessage()) . '</p>'
        . '<a href="' . htmlspecialchars(self_script()) . '">برگشت به خانه</a></div></body></html>';
    exit;
}

$ct = $res['contentType'];
if (stripos($ct, 'text/html') !== false) {
    $out = rewrite_html($res['body'], $res['finalUrl']);
    header('Content-Type: text/html; charset=utf-8');
    echo $out;
} elseif (stripos($ct, 'text/css') !== false) {
    $out = rewrite_css_urls($res['body'], $res['finalUrl']);
    header('Content-Type: ' . $ct);
    echo $out;
} else {
    header('Content-Type: ' . $ct);
    echo $res['body'];
}
