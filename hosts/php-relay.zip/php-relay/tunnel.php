<?php
/**
 * این فایل هاست رو تبدیل به یه "بک‌اند تونل" می‌کنه — چون هاست‌های
 * اشتراکی ارزون هیچ پورت ورودی‌ای غیر از 80/443 ندارن (و SSH/روت هم
 * ندارن)، نمی‌شه یه SOCKS5 واقعی که گوشی مستقیم بهش وصل بشه روی خودِ
 * هاست باز کرد. برای همین معماری اینه:
 *
 *   گوشی/برنامه‌ها --(socks5://127.0.0.1:1080)--> bridge.py (رو گوشی/PC خودت)
 *                                                      |
 *                                         HTTP polling روی 443
 *                                                      v
 *                                         همین tunnel.php (رو هاست)
 *                                                      |
 *                                            fsockopen واقعی
 *                                                      v
 *                                              اینترنت بین‌الملل
 *
 * یعنی SOCKS5 واقعی روی خودِ گوشی/PC‌ت اجرا می‌شه (با bridge.py)، نه
 * روی هاست؛ bridge.py هر کانکشن SOCKS5 رو با یه سری درخواست HTTP به
 * همین فایل می‌فرسته. چون قاصدک HTTP معمولیه، تاخیر (latency) بیشتر از
 * یه تونل واقعیه، ولی برای مرور عادی/چت/اکثر اپ‌ها کاملاً کار می‌کنه.
 */

require_once __DIR__ . '/config.php';

define('TUNNEL_DIR', __DIR__ . '/data/tunnels');
if (!is_dir(TUNNEL_DIR)) { @mkdir(TUNNEL_DIR, 0700, true); }

function clean_sid($s)
{
    $s = preg_replace('/[^a-f0-9]/', '', strtolower((string) $s));
    return substr($s, 0, 32);
}

function require_key()
{
    $key = $_REQUEST['key'] ?? ($_SERVER['HTTP_X_RELAY_KEY'] ?? '');
    if (!hash_equals(RELAY_PASSWORD, (string) $key)) {
        http_response_code(403);
        header('Content-Type: application/json');
        echo json_encode(['ok' => false, 'error' => 'bad key']);
        exit;
    }
}

function tunnel_pump($dir, $host, $port)
{
    $sock = @stream_socket_client("tcp://$host:$port", $errno, $errstr, 10);
    if (!$sock) {
        @file_put_contents($dir . '/error.txt', "$errstr ($errno)");
        @touch($dir . '/closed.flag');
        return;
    }
    stream_set_blocking($sock, false);
    $uploadPos = 0;
    $idleStart = time();
    while (true) {
        if (file_exists($dir . '/stop.flag')) { break; }
        clearstatcache();
        $uploadFile = $dir . '/upload.bin';
        $size = file_exists($uploadFile) ? filesize($uploadFile) : 0;
        if ($size > $uploadPos) {
            $fh = fopen($uploadFile, 'rb');
            fseek($fh, $uploadPos);
            $chunk = fread($fh, $size - $uploadPos);
            fclose($fh);
            if ($chunk !== false && $chunk !== '') {
                fwrite($sock, $chunk);
                $uploadPos = $size;
                $idleStart = time();
            }
        }
        $read = [$sock]; $write = null; $except = null;
        $n = @stream_select($read, $write, $except, 0, 150000);
        if ($n === false) { break; }
        if ($n > 0) {
            $data = fread($sock, 65536);
            if ($data === false || ($data === '' && feof($sock))) { break; }
            if ($data !== '') {
                @file_put_contents($dir . '/download.bin', $data, FILE_APPEND | LOCK_EX);
                $idleStart = time();
            }
        }
        if (time() - $idleStart > 300) { break; } // ۵ دقیقه بی‌کاری = قطع خودکار
    }
    @fclose($sock);
    @touch($dir . '/closed.flag');
}

$action = $_GET['action'] ?? $_POST['action'] ?? '';

if ($action === '') {
    render_tunnel_info();
    exit;
}

require_key();

switch ($action) {
    case 'open':
        $host = trim($_POST['host'] ?? '');
        $port = (int) ($_POST['port'] ?? 0);
        if ($host === '' || $port <= 0 || $port > 65535) {
            http_response_code(400);
            header('Content-Type: application/json');
            echo json_encode(['ok' => false, 'error' => 'bad host/port']);
            exit;
        }
        $sid = bin2hex(random_bytes(12));
        $dir = TUNNEL_DIR . '/' . $sid;
        @mkdir($dir, 0700, true);

        header('Content-Type: application/json');
        echo json_encode(['ok' => true, 'sid' => $sid]);
        if (function_exists('fastcgi_finish_request')) {
            fastcgi_finish_request();
        } else {
            @ob_end_flush();
            @flush();
        }
        ignore_user_abort(true);
        set_time_limit(0);
        tunnel_pump($dir, $host, $port);
        exit;

    case 'send':
        $sid = clean_sid($_POST['sid'] ?? '');
        $dir = TUNNEL_DIR . '/' . $sid;
        header('Content-Type: application/json');
        if (!$sid || !is_dir($dir)) { echo json_encode(['ok' => false, 'error' => 'no such session']); exit; }
        $data = base64_decode($_POST['data'] ?? '', true);
        if ($data !== false && $data !== '') {
            file_put_contents($dir . '/upload.bin', $data, FILE_APPEND | LOCK_EX);
        }
        echo json_encode(['ok' => true]);
        exit;

    case 'recv':
        $sid = clean_sid($_GET['sid'] ?? '');
        $since = max(0, (int) ($_GET['since'] ?? 0));
        $dir = TUNNEL_DIR . '/' . $sid;
        header('Content-Type: application/json');
        if (!$sid || !is_dir($dir)) { echo json_encode(['ok' => false, 'error' => 'no such session']); exit; }
        $f = $dir . '/download.bin';
        $data = '';
        if (file_exists($f)) {
            $fh = fopen($f, 'rb');
            fseek($fh, $since);
            $data = stream_get_contents($fh);
            fclose($fh);
        }
        $size = file_exists($f) ? filesize($f) : $since;
        echo json_encode([
            'ok' => true,
            'data' => base64_encode($data),
            'size' => $size,
            'closed' => file_exists($dir . '/closed.flag'),
            'error' => file_exists($dir . '/error.txt') ? file_get_contents($dir . '/error.txt') : null,
        ]);
        exit;

    case 'close':
        $sid = clean_sid($_POST['sid'] ?? $_GET['sid'] ?? '');
        $dir = TUNNEL_DIR . '/' . $sid;
        if ($sid && is_dir($dir)) { @touch($dir . '/stop.flag'); }
        header('Content-Type: application/json');
        echo json_encode(['ok' => true]);
        exit;

    default:
        http_response_code(404);
        header('Content-Type: application/json');
        echo json_encode(['ok' => false, 'error' => 'unknown action']);
        exit;
}

function render_tunnel_info()
{
    // همون گیت رمز نشست (کوکی) که بقیه‌ی سایت داره — برای دیدن این
    // صفحه‌ی راهنما باید از index.php لاگین کرده باشی.
    relay_start_session();
    $authed = isset($_SESSION['relay_auth_until']) && $_SESSION['relay_auth_until'] > time();
    if (!$authed) {
        header('Location: index.php');
        exit;
    }
    $scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
    $host = $_SERVER['HTTP_HOST'] ?? 'your-host.com';
    $dir = rtrim(dirname($_SERVER['SCRIPT_NAME']), '/');
    $selfUrl = $scheme . '://' . $host . $dir . '/tunnel.php';

    header('Content-Type: text/html; charset=utf-8');
    echo '<!doctype html><html lang="fa" dir="rtl"><head><meta charset="utf-8"/>'
        . '<meta name="viewport" content="width=device-width, initial-scale=1"/>'
        . '<title>Tunnel</title>'
        . '<link href="https://cdn.jsdelivr.net/gh/rastikerdar/vazirmatn@v33.003/Vazirmatn-font-face.css" rel="stylesheet"/>'
        . '<style>
        :root{--bg:#0a0d12;--panel:#121820;--border:#232c37;--text:#e6edf3;--muted:#8b98a5;--accent:#3b82f6}
        *{box-sizing:border-box}
        body{font-family:Vazirmatn,Tahoma,Arial,sans-serif;background:#0a0d12;color:var(--text);margin:0;padding:18px;max-width:640px;margin:0 auto}
        h1{font-size:19px}
        .card{background:var(--panel);border:1px solid var(--border);border-radius:14px;padding:18px;margin-top:14px}
        .row{display:flex;justify-content:space-between;gap:10px;padding:8px 0;border-bottom:1px solid #1b222c;font-size:13.5px}
        .row:last-child{border-bottom:none}
        .row b{color:var(--muted);font-weight:500}
        code{background:#0e141b;border:1px solid var(--border);border-radius:6px;padding:2px 7px;font-size:12.5px;direction:ltr;display:inline-block}
        pre{background:#0e141b;border:1px solid var(--border);border-radius:10px;padding:12px;overflow-x:auto;font-size:12px;direction:ltr;text-align:left}
        a.btn{display:inline-block;margin-top:10px;background:var(--accent);color:#fff;text-decoration:none;padding:10px 16px;border-radius:9px;font-size:13.5px;font-weight:700}
        .warn{font-size:12.5px;color:#f3c969;background:#2a2112;border:1px solid #4a3a16;border-radius:8px;padding:10px;margin-top:12px;line-height:1.8}
        ol{font-size:13.5px;line-height:2;padding-right:20px}
        </style></head><body>'
        . '<h1>⚙️ تبدیل این هاست به تونل SOCKS5</h1>'
        . '<div class="card">'
        . '<div class="row"><b>آدرس Tunnel Backend</b><code>' . htmlspecialchars($selfUrl) . '</code></div>'
        . '<div class="row"><b>رمز (key)</b><code>' . htmlspecialchars(RELAY_PASSWORD) . '</code></div>'
        . '</div>'
        . '<div class="warn">⚠️ این یه SOCKS5 واقعی روی خودِ هاست نیست (هاست اشتراکی پورت ورودی غیر از 80/443 نداره). '
        . 'یه اسکریپت کوچیک (<code>bridge.py</code>) باید روی خودِ گوشی یا کامپیوترت اجرا بشه که یه SOCKS5 محلی '
        . '(<code>127.0.0.1:1080</code>) باز می‌کنه و هر کانکشن رو از طریق همین آدرس بالا به هاست می‌فرسته.</div>'
        . '<div class="card"><b>نصب (یک‌بار):</b>'
        . '<ol>'
        . '<li>Termux رو از F-Droid نصب کن (نه از Google Play، نسخه‌ی قدیمیه)</li>'
        . '<li><code>pkg install python -y</code> (همین کافیه — bridge.py فقط از کتابخونه‌ی استاندارد پایتون استفاده می‌کنه، نیازی به pip نیست)</li>'
        . '<li>فایل <code>bridge.py</code> رو بریز توی گوشی (همون پوشه‌ی Download کافیه، بعد با <code>cd</code> برو همونجا)</li>'
        . '</ol>'
        . '<b>هر بار که خواستی وصل شی:</b>'
        . '<pre>python bridge.py --url ' . htmlspecialchars($selfUrl) . ' --key ' . htmlspecialchars(RELAY_PASSWORD) . '</pre>'
        . '<p style="font-size:13px;color:var(--muted)">بعدش توی تنظیمات پراکسی هر اپی که می‌خوای (یا کل گوشی، با یه اپ کمکی مثل <b>Proxy Droid</b>)، آدرس <code>socks5://127.0.0.1:1080</code> رو بذار.</p>'
        . '</div>'
        . '<div class="warn">سرعت و تاخیرش به‌خاطر اینکه از روی HTTP polling کار می‌کنه، کندتر از یه تونل واقعیه — '
        . 'برای مرور عادی و چت خوبه، برای دانلود سنگین/استریم زنده انتظار نداشته باش عالی باشه. '
        . 'همچنین چون مرورگر برای هر صفحه چندین کانکشن همزمان باز می‌کنه و هر کدوم یه پردازش PHP جدا روی هاست مصرف می‌کنه، '
        . 'روی هاست‌های خیلی محدود ممکنه با باز بودن خیلی تب/کانکشن همزمان کند بشه.</div>'
        . '<a class="btn" href="index.php">برگشت به رله</a>'
        . '</body></html>';
}
