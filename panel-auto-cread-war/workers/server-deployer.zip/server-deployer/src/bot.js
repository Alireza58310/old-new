// منطق ربات تلگرام: API تنظیمات (برای صفحه‌ی وب) + هندلر وبهوک (چت)
import { tgApi, tgSendDoc, esc, ICON, STEP_LABELS, controlKeyboard, stepsKeyboard, keysKeyboard, KEY_CODES } from './tg.js';

// ---------- ذخیره‌سازی (DO مخصوص config؛ از بیرون قابل دسترسی نیست) ----------
const CFG = (env) => env.SESSIONS.get(env.SESSIONS.idFromName('__cfg__'));
export async function kvGet(env, k) {
  const j = await (await CFG(env).fetch('https://do/kv-get?k=' + encodeURIComponent(k))).json();
  return j.v === undefined ? null : j.v;
}
export async function kvSet(env, k, v) { await CFG(env).fetch('https://do/kv-set', { method: 'POST', body: JSON.stringify({ k, v }) }); }
export async function kvDel(env, k) { await CFG(env).fetch('https://do/kv-del', { method: 'POST', body: JSON.stringify({ k }) }); }

async function sess(env, sid, path, method, body) {
  const stub = env.SESSIONS.get(env.SESSIONS.idFromName(sid));
  const init = { method: method || 'GET', headers: { 'x-sid': sid, 'content-type': 'application/json' } };
  if (body !== undefined) init.body = JSON.stringify(body);
  try { return await (await stub.fetch('https://do/' + path, init)).json(); } catch (e) { return null; }
}

function rnd(n, hex) {
  const a = new Uint8Array(n); crypto.getRandomValues(a);
  const cs = hex ? '0123456789abcdef' : 'abcdefghijklmnopqrstuvwxyz0123456789';
  let s = ''; for (const b of a) s += cs[b % cs.length]; return s;
}
async function sha(s) {
  const b = await crypto.subtle.digest('SHA-256', new TextEncoder().encode('sd:' + s));
  return [...new Uint8Array(b)].map((x) => x.toString(16).padStart(2, '0')).join('');
}
const json = (o, s) => new Response(JSON.stringify(o), { status: s || 200, headers: { 'content-type': 'application/json; charset=utf-8' } });

const COMMANDS = [
  { command: 'menu', description: 'منوی اصلی' }, { command: 'deploy', description: 'دیپلوی جدید' },
  { command: 'status', description: 'وضعیت Session' }, { command: 'log', description: 'لاگ کنسول' },
  { command: 'result', description: 'فایل نتیجه' }, { command: 'cmd', description: 'اجرای دستور روی سرور' },
  { command: 'console', description: 'حالت کنسول' }, { command: 'exit', description: 'قطع اتصال' },
];

// ---------- API تنظیمات برای صفحه‌ی وب ----------
export async function handleTgApi(request, env) {
  const path = new URL(request.url).pathname;
  const cfg = (await kvGet(env, 'tg')) || {};
  if (path === '/api/tg/status') {
    return json({ configured: !!cfg.token, bot: cfg.botUsername || null, tokenMasked: cfg.token ? '••••' + cfg.token.slice(-6) : null, ownerSet: !!cfg.owner, hasAdmin: !!cfg.adminHash, webhook: !!cfg.webhookUrl });
  }
  if (request.method !== 'POST') return json({ ok: false, error: 'POST required' }, 405);
  let body = {}; try { body = await request.json(); } catch (e) {}
  const key = String(body.adminKey || '');

  if (cfg.adminHash) {
    if (!key || (await sha(key)) !== cfg.adminHash) return json({ ok: false, error: 'رمز مدیریت اشتباه است.' }, 403);
  } else if (path !== '/api/tg/save') {
    return json({ ok: false, error: 'اول توکن را ذخیره کن.' }, 400);
  } else if (key.length < 6) {
    return json({ ok: false, error: 'یک رمز مدیریت حداقل ۶ کاراکتری انتخاب کن (برای اینکه کس دیگه‌ای نتونه تنظیمات ربات رو عوض کنه).' }, 400);
  }

  if (path === '/api/tg/save') {
    const token = String(body.token || '').trim() || cfg.token || '';
    if (!/^\d{6,}:[A-Za-z0-9_-]{30,}$/.test(token)) return json({ ok: false, error: 'فرمت توکن درست نیست (مثل 123456:ABC...).' }, 400);
    const me = await tgApi(token, 'getMe');
    if (!me.ok) return json({ ok: false, error: 'توکن معتبر نیست: ' + (me.description || '') }, 400);
    const next = Object.assign({}, cfg, { token, botUsername: me.result.username });
    if (!cfg.adminHash) next.adminHash = await sha(key);
    if (!next.secret) next.secret = rnd(24, true);
    if (cfg.token && cfg.token !== token && cfg.webhookUrl) { await tgApi(cfg.token, 'deleteWebhook', {}); next.webhookUrl = null; }
    const chatId = String(body.chatId || '').trim();
    if (chatId) {
      if (!/^-?\d+$/.test(chatId)) return json({ ok: false, error: 'Chat ID باید عدد باشد.' }, 400);
      next.owner = chatId; delete next.pairCode;
    } else if (!next.owner) { next.pairCode = next.pairCode || rnd(6); }
    await kvSet(env, 'tg', next);
    return json({ ok: true, bot: me.result.username, ownerSet: !!next.owner, pairCode: next.owner ? null : next.pairCode });
  }

  if (path === '/api/tg/webhook') {
    if (!cfg.token) return json({ ok: false, error: 'توکن ذخیره نشده.' }, 400);
    const origin = new URL(request.url).origin;
    if (!origin.startsWith('https://')) return json({ ok: false, error: 'وبهوک تلگرام فقط https قبول می‌کند؛ صفحه را از آدرس https (workers.dev یا دامنه‌ی خودت) باز کن.' }, 400);
    const wurl = origin + '/tg/' + cfg.secret;
    const r = await tgApi(cfg.token, 'setWebhook', { url: wurl, secret_token: cfg.secret, allowed_updates: ['message', 'callback_query'], drop_pending_updates: true, max_connections: 5 });
    if (!r.ok) return json({ ok: false, error: 'setWebhook ناموفق: ' + (r.description || '') }, 400);
    await tgApi(cfg.token, 'setMyCommands', { commands: COMMANDS });
    await kvSet(env, 'tg', Object.assign({}, cfg, { webhookUrl: wurl }));
    return json({ ok: true, pairCode: cfg.owner ? null : (cfg.pairCode || null) });
  }

  if (path === '/api/tg/test') {
    if (!cfg.token) return json({ ok: false, error: 'توکن ذخیره نشده.' }, 400);
    if (!cfg.owner) return json({ ok: false, error: 'هنوز چتی به ربات وصل نشده. در تلگرام به ربات بفرست: /start ' + cfg.pairCode, pairCode: cfg.pairCode }, 400);
    const info = await tgApi(cfg.token, 'getWebhookInfo');
    const wi = info && info.result ? info.result : {};
    const okHook = cfg.webhookUrl && wi.url === cfg.webhookUrl;
    const origin = new URL(request.url).origin;
    const text = '🧪 <b>پیام تست — Server Deployer</b>\n✅ ربات با موفقیت به Worker وصل است.\n🌐 <code>' + esc(origin) + '</code>\n🔗 وبهوک: ' + (okHook ? 'فعال ✅' : 'ست نشده ⚠️') + (wi.last_error_message ? '\n⚠️ آخرین خطای تلگرام: ' + esc(wi.last_error_message) : '') + '\n\nبرای شروع /menu را بزن.';
    const r = await tgApi(cfg.token, 'sendMessage', { chat_id: cfg.owner, text, parse_mode: 'HTML', reply_markup: MENU });
    if (!r.ok) return json({ ok: false, error: 'ارسال ناموفق: ' + (r.description || '') + ' — مطمئن شو یک‌بار به ربات /start زده‌ای.' }, 400);
    return json({ ok: true, webhookOk: !!okHook, lastError: wi.last_error_message || null, pending: wi.pending_update_count || 0 });
  }

  if (path === '/api/tg/remove') {
    if (cfg.token) await tgApi(cfg.token, 'deleteWebhook', {});
    await kvDel(env, 'tg'); await kvDel(env, 'wiz'); await kvDel(env, 'console'); await kvDel(env, 'active');
    return json({ ok: true });
  }
  return json({ ok: false, error: 'unknown' }, 404);
}

// تأیید درخواست وبهوک (مسیر + هدر secret) و برگرداندن update
export async function verifyWebhook(request, env, secretInPath) {
  const cfg = await kvGet(env, 'tg');
  if (!cfg || !cfg.token || !cfg.secret || secretInPath !== cfg.secret) return null;
  if (request.headers.get('x-telegram-bot-api-secret-token') !== cfg.secret) return null;
  try { return await request.json(); } catch (e) { return null; }
}

// ---------- چت ----------
const MENU = { inline_keyboard: [
  [{ text: '🚀 دیپلوی جدید', callback_data: 'm:new' }],
  [{ text: '📊 وضعیت', callback_data: 'm:status' }, { text: '📜 لاگ کنسول', callback_data: 'm:log' }],
  [{ text: '📄 نتیجه', callback_data: 'm:result' }, { text: '⌨️ حالت کنسول', callback_data: 'm:console' }],
  [{ text: '⛔ قطع اتصال', callback_data: 'm:exit' }],
] };
const CANCEL = { inline_keyboard: [[{ text: '✖️ لغو', callback_data: 'w:cancel' }]] };
const withDefault = (label) => ({ inline_keyboard: [[{ text: label, callback_data: 'w:def' }], [{ text: '✖️ لغو', callback_data: 'w:cancel' }]] });

const say = (c, chat, text, extra) => tgApi(c.T, 'sendMessage', Object.assign({ chat_id: chat, text: String(text).slice(0, 4000), parse_mode: 'HTML', disable_web_page_preview: true }, extra || {}));
const pre = (s) => '<pre>' + esc(s) + '</pre>';

export async function handleUpdate(env, upd, origin) {
  const cfg = await kvGet(env, 'tg');
  if (!cfg || !cfg.token) return;
  const c = { env, cfg, T: cfg.token, origin };
  if (upd.callback_query) return onCallback(c, upd.callback_query);
  if (upd.message) return onMessage(c, upd.message);
}

async function activeSid(env) { return await kvGet(env, 'active'); }
async function needSid(c, chat, sid) {
  if (!sid) { await say(c, chat, 'Session فعالی نیست. با /deploy یکی بساز.', { reply_markup: MENU }); return false; }
  return true;
}

async function onMessage(c, m) {
  const { env, cfg } = c;
  const chat = String(m.chat.id);
  const text = (m.text || '').trim();
  if (!cfg.owner) {
    const mm = text.match(/^\/start(?:@\w+)?\s+(\S+)/);
    if (mm && cfg.pairCode && mm[1] === cfg.pairCode) {
      const next = Object.assign({}, cfg, { owner: chat }); delete next.pairCode;
      await kvSet(env, 'tg', next);
      await say(c, chat, '✅ <b>جفت شد!</b> از این به بعد فقط همین چت به ربات دسترسی دارد.\nنتیجه‌ی همه‌ی Sessionها هم اینجا میاد.', { reply_markup: MENU });
    } else {
      await say(c, chat, '🔒 این ربات هنوز جفت نشده. کدی که در صفحه‌ی Worker نشان داده شده را این‌طوری بفرست:\n<code>/start CODE</code>');
    }
    return;
  }
  if (chat !== String(cfg.owner)) return;

  const cm = text.match(/^\/([A-Za-z_]+)(?:@\w+)?(?:\s+([\s\S]*))?$/);
  if (cm) return onCommand(c, chat, m, cm[1].toLowerCase(), (cm[2] || '').trim());
  const wiz = await kvGet(env, 'wiz');
  if (wiz) return onWizard(c, chat, m, wiz);
  const con = await kvGet(env, 'console');
  if (con && text) return runCmd(c, chat, con, text + '\n');
  if (text) await say(c, chat, 'برای منوی اصلی /menu را بزن.', { reply_markup: MENU });
}

async function onCommand(c, chat, m, name, arg) {
  const { env } = c;
  if (name !== 'cmd') { /* هر دستور جدید، wizard نیمه‌کاره را لغو می‌کند */ if (name !== 'deploy') await kvDel(env, 'wiz'); }
  const sid = await activeSid(env);
  switch (name) {
    case 'start': case 'menu': case 'help':
      return say(c, chat, '🤖 <b>Server Deployer</b>\nهر کاری که توی صفحه‌ی Worker می‌کنی از اینجا هم می‌شه:\n/deploy — دیپلوی جدید (مرحله‌به‌مرحله)\n<code>/deploy IP USER PASS [PORT]</code> — یک‌خطی\n/status /log /result — وضعیت، لاگ، نتیجه\n/cmd دستور — اجرای دستور روی سرور\n/console — حالت کنسول (هر پیام = یک دستور)\n/exit — قطع اتصال', { reply_markup: MENU });
    case 'deploy': return arg ? quickDeploy(c, chat, m, arg) : startWizard(c, chat);
    case 'cancel': await kvDel(env, 'wiz'); return say(c, chat, 'لغو شد.', { reply_markup: MENU });
    case 'status': return (await needSid(c, chat, sid)) && doStatus(c, chat, sid);
    case 'log': return (await needSid(c, chat, sid)) && doLog(c, chat, sid);
    case 'result': return (await needSid(c, chat, sid)) && doResult(c, chat, sid);
    case 'console': return (await needSid(c, chat, sid)) && enterConsole(c, chat, sid);
    case 'console_off': case 'consoleoff': await kvDel(env, 'console'); return say(c, chat, '⌨️ حالت کنسول خاموش شد.', { reply_markup: MENU });
    case 'cmd':
      if (!(await needSid(c, chat, sid))) return;
      if (!arg) return say(c, chat, 'مثال: <code>/cmd x-ui status</code>');
      return runCmd(c, chat, sid, arg + '\n');
    case 'exit': return (await needSid(c, chat, sid)) && confirmExit(c, chat, sid);
    default: return say(c, chat, 'دستور ناشناخته. /menu', { reply_markup: MENU });
  }
}

// ---- wizard دیپلوی ----
async function startWizard(c, chat) {
  await kvSet(c.env, 'wiz', { step: 'ip', d: {} });
  return wizPrompt(c, chat, 'ip');
}
async function wizPrompt(c, chat, step) {
  if (step === 'ip') return say(c, chat, '🖥 <b>IP سرور</b> را بفرست:', { reply_markup: CANCEL });
  if (step === 'port') return say(c, chat, '🔢 <b>پورت SSH</b> را بفرست:', { reply_markup: withDefault('پیش‌فرض: 22') });
  if (step === 'user') return say(c, chat, '👤 <b>یوزر SSH</b> را بفرست:', { reply_markup: withDefault('پیش‌فرض: root') });
  if (step === 'pass') return say(c, chat, '🔑 <b>رمز SSH</b> را بفرست (بعد از دریافت، پیامت پاک می‌شود):', { reply_markup: CANCEL });
  if (step === 'db') return say(c, chat, '📦 اگر بکاپ <code>x-ui.db</code> داری همین‌جا <b>به‌صورت فایل</b> بفرست؛ وگرنه دکمه‌ی زیر (نسخه‌ی گیت‌هاب استفاده می‌شود):', { reply_markup: withDefault('⏭ بدون فایل') });
}
async function onWizard(c, chat, m, wiz) {
  const text = (m.text || '').trim();
  if (wiz.step === 'port2') return setPanelPort(c, chat, wiz, text);
  if (wiz.step === 'db' && m.document) return wizDb(c, chat, wiz, m.document);
  if (!text) return;
  return wizAdvance(c, chat, wiz, text, m);
}
async function wizAdvance(c, chat, wiz, value, m) {
  const { env } = c; const d = wiz.d;
  if (wiz.step === 'ip') {
    if (!value || !/^[A-Za-z0-9.\-:]{3,255}$/.test(value)) return say(c, chat, '⚠️ IP/هاست معتبر نیست؛ دوباره بفرست.', { reply_markup: CANCEL });
    d.host = value; wiz.step = 'port';
  } else if (wiz.step === 'port') {
    const p = value == null ? 22 : parseInt(value, 10);
    if (!(p >= 1 && p <= 65535)) return say(c, chat, '⚠️ پورت باید عدد ۱ تا ۶۵۵۳۵ باشد.', { reply_markup: withDefault('پیش‌فرض: 22') });
    d.port = p; wiz.step = 'user';
  } else if (wiz.step === 'user') {
    d.user = value || 'root'; wiz.step = 'pass';
  } else if (wiz.step === 'pass') {
    if (!value) return;
    d.pass = value; wiz.step = 'db'; wiz.sid = 'tg' + rnd(12);
    if (m && m.message_id) await tgApi(c.T, 'deleteMessage', { chat_id: chat, message_id: m.message_id });
  } else if (wiz.step === 'db') {
    return finishWizard(c, chat, wiz);
  }
  await kvSet(env, 'wiz', wiz);
  return wizPrompt(c, chat, wiz.step);
}
async function wizDb(c, chat, wiz, doc) {
  const f = await tgApi(c.T, 'getFile', { file_id: doc.file_id });
  if (!f.ok) return say(c, chat, '⚠️ دریافت فایل ناموفق: ' + esc(f.description || ''));
  const r = await fetch('https://api.telegram.org/file/bot' + c.T + '/' + f.result.file_path);
  const buf = await r.arrayBuffer();
  const stub = c.env.SESSIONS.get(c.env.SESSIONS.idFromName(wiz.sid));
  await stub.fetch('https://do/upload-db', { method: 'POST', headers: { 'x-sid': wiz.sid }, body: buf });
  await say(c, chat, '📦 فایل دریافت شد (' + buf.byteLength + ' بایت).');
  return finishWizard(c, chat, wiz);
}
async function finishWizard(c, chat, wiz) {
  await kvDel(c.env, 'wiz');
  return startSession(c, chat, wiz.sid || ('tg' + rnd(12)), wiz.d);
}
async function startSession(c, chat, sid, d) {
  await kvSet(c.env, 'active', sid);
  const r = await sess(c.env, sid, 'start', 'POST', { host: d.host, port: d.port || 22, user: d.user || 'root', password: d.pass });
  if (!r || r.error) return say(c, chat, '❌ شروع ناموفق: ' + esc(r && r.error ? r.error : 'خطای نامشخص'));
  return say(c, chat, '🚀 Session ساخته شد و در حال اتصال به <code>' + esc(d.host) + '</code> است؛ پیشرفت در پیام بعدی نمایش داده می‌شود.\n🌐 همین Session در وب: <code>' + esc(c.origin) + '/?s=' + sid + '</code>');
}
async function quickDeploy(c, chat, m, arg) {
  const p = arg.split(/\s+/);
  if (m.message_id) await tgApi(c.T, 'deleteMessage', { chat_id: chat, message_id: m.message_id });
  if (p.length < 3) return say(c, chat, 'فرمت: <code>/deploy IP USER PASS [PORT]</code>');
  const port = p[3] ? parseInt(p[3], 10) : 22;
  if (!/^[A-Za-z0-9.\-:]{3,255}$/.test(p[0]) || !(port >= 1 && port <= 65535)) return say(c, chat, '⚠️ IP یا پورت معتبر نیست.');
  return startSession(c, chat, 'tg' + rnd(12), { host: p[0], user: p[1], pass: p[2], port });
}
async function setPanelPort(c, chat, wiz, text) {
  const n = parseInt(text, 10);
  if (!(n >= 1 && n <= 65535)) return say(c, chat, '⚠️ عدد ۱ تا ۶۵۵۳۵ بفرست.');
  const r = await sess(c.env, wiz.sid, 'tg-port', 'POST', { port: n });
  await kvDel(c.env, 'wiz');
  if (r && r.ok && wiz.msg) await tgApi(c.T, 'editMessageReplyMarkup', { chat_id: chat, message_id: wiz.msg, reply_markup: stepsKeyboard(wiz.sid, r.steps, r.port) });
  return say(c, chat, r && r.ok ? '✅ پورت پنل روی <code>' + n + '</code> تنظیم شد.' : '⚠️ ثبت نشد.');
}

// ---- عملیات روی Session ----
async function doStatus(c, chat, sid) {
  const i = await sess(c.env, sid, 'tg-info');
  if (!i) return say(c, chat, 'Session پیدا نشد.');
  return say(c, chat, (ICON[i.status] || 'ℹ️') + ' <b>' + esc(i.status) + '</b>' + (i.host ? ' — <code>' + esc(i.host) + '</code>' : '') + '\n\n' + esc(String(i.detail || '').slice(0, 3000)), { reply_markup: controlKeyboard(sid) });
}
async function doLog(c, chat, sid) {
  const j = await sess(c.env, sid, 'tg-tail?n=3400');
  return say(c, chat, j && j.text ? pre(j.text) : '(لاگ خالی است)', { reply_markup: controlKeyboard(sid) });
}
async function doResult(c, chat, sid) {
  const j = await sess(c.env, sid, 'tg-result');
  if (!j || !j.result) return say(c, chat, 'هنوز نتیجه‌ای آماده نیست.');
  await say(c, chat, pre(j.result.slice(0, 3800)));
  return tgSendDoc(c.T, chat, 'server-result.txt', j.result, 'server-result.txt');
}
async function enterConsole(c, chat, sid) {
  await kvSet(c.env, 'console', sid);
  return say(c, chat, '⌨️ <b>حالت کنسول روشن شد.</b> هر پیام متنی = یک دستور روی سرور و خروجی همین‌جا برمی‌گردد.\n⚠️ وسط اجرای مراحل خودکار، تایپ دستی ممکن است آن‌ها را به‌هم بریزد.', { reply_markup: keysKeyboard(sid) });
}
async function runCmd(c, chat, sid, data) {
  const j = await sess(c.env, sid, 'tg-exec', 'POST', { data });
  if (!j || !j.ok) return say(c, chat, '⚠️ ' + esc(j && j.error ? j.error : 'ارسال نشد'));
  return say(c, chat, pre(j.out || '(بدون خروجی)'), { reply_markup: keysKeyboard(sid) });
}
async function confirmExit(c, chat, sid) {
  return say(c, chat, '⛔ اتصال SSH قطع شود؟', { reply_markup: { inline_keyboard: [[{ text: 'بله، قطع کن', callback_data: 'xy:' + sid }, { text: 'خیر', callback_data: 'xn:' + sid }]] } });
}

async function onCallback(c, cb) {
  const { env, cfg, T } = c;
  const chat = cb.message ? String(cb.message.chat.id) : '';
  await tgApi(T, 'answerCallbackQuery', { callback_query_id: cb.id });
  if (!chat || chat !== String(cfg.owner)) return;
  const parts = String(cb.data || '').split(':');
  let a = parts[0]; let sid = parts[1];
  if (a === 'm') {
    const map = { new: 'new', status: 's', log: 'l', result: 'r', console: 'c', exit: 'x' };
    a = map[parts[1]]; sid = await activeSid(env);
    if (a === 'new') return startWizard(c, chat);
  }
  if (a === 'w') {
    if (parts[1] === 'cancel') { await kvDel(env, 'wiz'); return say(c, chat, 'لغو شد.', { reply_markup: MENU }); }
    const wiz = await kvGet(env, 'wiz');
    if (!wiz) return;
    return wizAdvance(c, chat, wiz, null, null);
  }
  if (a === 'co') { await kvDel(env, 'console'); return say(c, chat, '⌨️ حالت کنسول خاموش شد.', { reply_markup: MENU }); }
  if (a === 'xn') return say(c, chat, 'باشه، قطع نشد.');
  if (!(await needSid(c, chat, sid))) return;
  switch (a) {
    case 's': return doStatus(c, chat, sid);
    case 'l': return doLog(c, chat, sid);
    case 'r': return doResult(c, chat, sid);
    case 'c': return enterConsole(c, chat, sid);
    case 'x': return confirmExit(c, chat, sid);
    case 'xy': {
      await sess(env, sid, 'exit', 'POST', {});
      await kvDel(env, 'console');
      return say(c, chat, '🔒 اتصال قطع شد.', { reply_markup: MENU });
    }
    case 'k': {
      const code = KEY_CODES[parts[2]];
      if (code == null) return;
      return runCmd(c, chat, sid, code);
    }
    case 't': {
      const r = await sess(env, sid, 'tg-toggle', 'POST', { key: parts[2] });
      if (r && r.ok) await tgApi(T, 'editMessageReplyMarkup', { chat_id: chat, message_id: cb.message.message_id, reply_markup: stepsKeyboard(sid, r.steps, r.port) });
      else await say(c, chat, 'این Session دیگر در مرحله‌ی انتخاب نیست.');
      return;
    }
    case 'p':
      await kvSet(env, 'wiz', { step: 'port2', sid, msg: cb.message.message_id, d: {} });
      return say(c, chat, '🔌 عدد <b>پورت پنل</b> را بفرست (۱ تا ۶۵۵۳۵):', { reply_markup: CANCEL });
    case 'b': {
      const r = await sess(env, sid, 'tg-begin', 'POST', {});
      if (!r || !r.ok) await say(c, chat, '⚠️ Session هنوز آماده‌ی شروع نیست یا قبلاً شروع شده.');
      return;
    }
  }
}
