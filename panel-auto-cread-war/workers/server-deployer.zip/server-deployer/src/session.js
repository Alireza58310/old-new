import { connect } from 'cloudflare:sockets';
import { SSH } from './ssh.js';
import SCRIPT_INSTALLER from '../scripts/alis-installer.sh';
import SCRIPT_UFW from '../scripts/alis-ufw-manager.sh';
import SCRIPT_FAKESSL from '../scripts/alis-fake-ssl-manager.sh';

// فقط اگه گرفتن لیست پورت از گیت‌هاب (پایین) شکست خورد استفاده می‌شه.
const FALLBACK_PANEL_PORTS = [22,47,80,346,428,440,441,442,443,444,445,446,447,448,449,450,451,452,453,454,455,456,457,458,459,460,461,462,463,464,465,466,467,468,469,470,471,472,473,474,475,476,477,478,479,480,481,482,483,484,485,486,487,488,489,490,491,492,493,494,495,496,497,498,499,500,501,502,503,504,505,506,507,508,509,510,1087,2053,2083,2095,2096,2097,2098,2100,2101,2102,2104,2110,2121,8000,62050,62051,62052,62053];
const PANEL_PORTS_URL = 'https://raw.githubusercontent.com/Alireza58310/old-new/refs/heads/main/bezan/panel/ports.txt';
// فقط اگه گرفتن لیست دامنه از گیت‌هاب (پایین) شکست خورد استفاده می‌شه.
const FALLBACK_DOMAINS = ['a.nami1.ir','b.nami1.ir','c.nami1.ir','vip.nami1.ir','didin.nami1.ir','vbnm.nami1.ir'];
const DOMAINS_URL = 'https://raw.githubusercontent.com/Alireza58310/old-new/refs/heads/main/bezan/panel/domains.txt';
const PANEL_DB_RAW_URL = 'https://raw.githubusercontent.com/Alireza58310/old-new/main/bezan/panel/x-ui.db';
const PS1_MARK = '###WRKRDY###';

function rid(n = 10) { const c = 'abcdefghijklmnopqrstuvwxyz0123456789'; let s = ''; for (let i = 0; i < n; i++) s += c[Math.floor(Math.random() * c.length)]; return s; }

const STEP_KEYS = ['installer', 'ufw', 'ssl', 'restore', 'restart', 'panelConfig', 'panelPort', 'finalSettings'];
const DEFAULT_PANEL_PORT = 443;
function DEFAULT_STEPS() { const o = {}; for (const k of STEP_KEYS) o[k] = true; return o; }

export class SessionDO {
  constructor(state, env) {
    this.state = state; this.env = env;
    this.log = ''; this.sockets = new Set();
    this.status = 'idle'; // idle | connecting | running | need_input | waiting_db_upload | done | error
    this.detail = 'Waiting for connection details.';
    this.result = null; this.dbFile = null; this.ssh = null; this.manualMode = false;
    this.beginResolver = null;
    this.selectedSteps = null;
    this.panelPortChoice = DEFAULT_PANEL_PORT;
    this.state.blockConcurrencyWhile(async () => {
      const saved = await this.state.storage.get(['log', 'status', 'detail', 'result']);
      if (saved.get('log')) this.log = saved.get('log');
      if (saved.get('status')) this.status = saved.get('status');
      if (saved.get('detail')) this.detail = saved.get('detail');
      if (saved.get('result')) this.result = saved.get('result');
    });
  }

  async persist() { await this.state.storage.put({ log: this.log.slice(-400000), status: this.status, detail: this.detail, result: this.result }); }

  broadcast(obj) { const msg = JSON.stringify(obj); for (const ws of this.sockets) { try { ws.send(msg); } catch (e) {} } }

  appendLog(s) { this.log += s; this.broadcast({ t: 'log', d: s }); }
  setDetail(s) { this.detail = s; this.broadcast({ t: 'detail', d: s }); this.persist(); }
  setStatus(s) { this.status = s; this.broadcast({ t: 'status', d: s }); this.persist(); }

  async fetch(request) {
    const url = new URL(request.url);
    if (url.pathname.endsWith('/ws')) return this.handleWs(request);
    if (url.pathname.endsWith('/start') && request.method === 'POST') return this.handleStart(request);
    if (url.pathname.endsWith('/input') && request.method === 'POST') return this.handleInput(request);
    if (url.pathname.endsWith('/exit') && request.method === 'POST') return this.handleExit();
    if (url.pathname.endsWith('/begin') && request.method === 'POST') return this.handleBegin(request);
    if (url.pathname.endsWith('/upload-db') && request.method === 'POST') return this.handleUploadDb(request);
    if (url.pathname.endsWith('/state')) return new Response(JSON.stringify({ status: this.status, detail: this.detail, log: this.log, result: this.result, hasDb: !!this.dbFile }), { headers: { 'content-type': 'application/json' } });
    if (url.pathname.endsWith('/result.txt')) return new Response(this.result || 'Not finished yet.', { headers: { 'content-type': 'text/plain; charset=utf-8' } });
    return new Response('not found', { status: 404 });
  }

  async handleWs(request) {
    const pair = new WebSocketPair(); const [client, server] = Object.values(pair);
    server.accept(); this.sockets.add(server);
    server.send(JSON.stringify({ t: 'snapshot', status: this.status, detail: this.detail, log: this.log, result: this.result }));
    server.addEventListener('message', async (ev) => {
      try { const m = JSON.parse(ev.data); if (m.t === 'raw' && this.ssh && !this.ssh.closed) { this.manualMode = true; await this.ssh.write(m.d); } } catch (e) {}
    });
    server.addEventListener('close', () => this.sockets.delete(server));
    return new Response(null, { status: 101, webSocket: client });
  }

  async handleUploadDb(request) {
    const buf = await request.arrayBuffer();
    this.dbFile = new Uint8Array(buf);
    await this.state.storage.put('dbFileLen', this.dbFile.length);
    // store in chunks (DO storage values capped); keep in-memory for this session's lifetime, also persist as base64 split
    const b64 = btoa(String.fromCharCode(...this.dbFile));
    for (let i = 0; i < b64.length; i += 100000) await this.state.storage.put('dbb64_' + (i / 100000), b64.slice(i, i + 100000));
    await this.state.storage.put('dbb64_chunks', Math.ceil(b64.length / 100000));
    return new Response(JSON.stringify({ ok: true, bytes: this.dbFile.length }), { headers: { 'content-type': 'application/json' } });
  }

  async loadDbFromStorage() {
    if (this.dbFile) return this.dbFile;
    const n = await this.state.storage.get('dbb64_chunks'); if (!n) return null;
    let b64 = ''; for (let i = 0; i < n; i++) b64 += (await this.state.storage.get('dbb64_' + (i * 100000))) || '';
    if (!b64) return null;
    const bin = atob(b64); const arr = new Uint8Array(bin.length); for (let i = 0; i < bin.length; i++) arr[i] = bin.charCodeAt(i);
    this.dbFile = arr; return arr;
  }

  async hardCloseSsh() {
    // close() خودش می‌فرسته SSH_MSG_CHANNEL_CLOSE و بعد سوکت رو می‌بنده، ولی
    // اگه هرجایی گیر کنه (مثلاً write روی یه سوکت نیمه‌باز)، با یه timeout
    // به‌زور سوکت خام رو می‌بندیم تا هیچ‌وقت قطع‌کردن خودش گیر نکنه.
    if (!this.ssh) return;
    const ssh = this.ssh;
    this.ssh = null; // از همین الان هیچ فاز دیگه‌ای بهش write نمی‌کنه
    ssh.closed = true;
    await Promise.race([
      ssh.close().catch(() => {}),
      new Promise((r) => setTimeout(r, 4000)),
    ]);
    try { await ssh.sock.close(); } catch (e) {}
  }

  async handleBegin(request) {
    let steps = null; let panelPort = null;
    try { const body = await request.json(); steps = body && body.steps; panelPort = body && body.panelPort; } catch (e) {}
    this.selectedSteps = steps || this.selectedSteps || DEFAULT_STEPS();
    // پورتی که کاربر برای پنل نوشته (پیش‌فرض 443). اگه عدد معتبر ۱ تا ۶۵۵۳۵ نبود، 443.
    const pn = Number(String(panelPort == null ? '' : panelPort).trim());
    this.panelPortChoice = (Number.isInteger(pn) && pn >= 1 && pn <= 65535) ? pn : DEFAULT_PANEL_PORT;
    if (this.beginResolver) { const r = this.beginResolver; this.beginResolver = null; r(); }
    return new Response(JSON.stringify({ ok: true }));
  }

  async handleExit() {
    this.setDetail('Disconnected by user request.');
    this.setStatus('closed');
    await this.hardCloseSsh();
    try { await this.state.storage.deleteAlarm(); } catch (e) {}
    return new Response(JSON.stringify({ ok: true }));
  }

  async alarm() {
    // Auto-disconnect safety net: if the job finished and nobody hit Exit,
    // close the SSH connection after the scheduled timeout instead of
    // leaving a live shell on the server indefinitely.
    await this.hardCloseSsh();
    if (this.status === 'done' || this.status === 'error') {
      this.setDetail((this.detail || '') + '\n\nAuto-disconnected after the idle timeout.');
    }
    this.setStatus('closed');
  }

  async handleInput(request) {
    const { data } = await request.json();
    if (this.ssh && !this.ssh.closed) { this.manualMode = true; await this.ssh.write(data); }
    return new Response('ok');
  }

  async handleStart(request) {
    if (this.status === 'running' || this.status === 'connecting') return new Response(JSON.stringify({ error: 'already running' }), { status: 409 });
    const body = await request.json();
    const { host, port, user, password } = body;
    if (!host || !user || !password) return new Response(JSON.stringify({ error: 'missing fields' }), { status: 400 });
    this.log = ''; this.result = null; this.manualMode = false;
    this.setStatus('connecting'); this.setDetail('Opening TCP connection to ' + host + ':' + (port || 22) + ' ...');
    // run in background; survives client disconnect because the DO itself keeps the promise alive via waitUntil-like behavior:
    // Durable Objects stay active while they have pending work, independent of any attached WebSocket/HTTP client.
    this.state.waitUntil ? this.state.waitUntil(this.runAutomation(host, port || 22, user, password)) : this.runAutomation(host, port || 22, user, password);
    return new Response(JSON.stringify({ ok: true }));
  }

  async waitFor(markers, timeoutMs, from) {
    // markers می‌تونه رشته (indexOf ساده) یا RegExp باشه (برای پرامپت‌هایی
    // که شکل دقیقشون رو نداریم، مثل "(y/n)" در برابر "[y/n]").
    const arr = Array.isArray(markers) ? markers : [markers];
    // from: اگه داده بشه، جستجو از همون نقطه شروع می‌شه (قبل از نوشتن دستور)،
    // تا اگه جواب سرور خیلی سریع رسید و قبل از شروع waitFor چاپ شد، از دست نره
    // و ۶–۱۰ ثانیه الکی منتظر timeout نمونیم.
    const start = (typeof from === 'number') ? from : (this.buf?.length || 0);
    const deadline = Date.now() + timeoutMs;
    for (;;) {
      for (const m of arr) {
        if (m instanceof RegExp) {
          const re = new RegExp(m.source, m.flags.includes('g') ? m.flags : m.flags + 'g');
          re.lastIndex = Math.max(0, start - 80);
          const match = re.exec(this.buf);
          if (match) return { marker: m, idx: match.index };
        } else {
          const idx = this.buf.indexOf(m, Math.max(0, start - m.length));
          if (idx !== -1) return { marker: m, idx };
        }
      }
      if (Date.now() > deadline) return null;
      await new Promise(r => setTimeout(r, 150));
    }
  }

  async runAutomation(host, port, user, password) {
    this.buf = '';
    try {
      const sock = connect({ hostname: host, port: Number(port) });
      const ssh = new SSH(sock); this.ssh = ssh;
      ssh.onData = (chunk) => { this.buf += chunk; this.appendLog(chunk); };
      ssh.onClose = (err) => {
        if (this.status !== 'done' && this.status !== 'error' && this.status !== 'closed') {
          this.setDetail(err ? ('Connection closed: ' + err.message) : 'Connection closed by remote host.');
          this.setStatus(this.result ? 'done' : 'error');
        }
      };
      this.setDetail('Authenticating as ' + user + ' ...');
      await ssh.connect({ user, password, cols: 200, rows: 50 });
      this.setDetail('Connected. Normalizing shell prompt...');
      await ssh.write(`stty -echo 2>/dev/null; export PS1='\\n${PS1_MARK}\\n'; export TERM=xterm; echo READY_${PS1_MARK}\n`);
      await this.waitFor('READY_' + PS1_MARK, 15000);

      // قبل از شروع واقعی کارها، منتظر کلیک دکمه‌ی Start می‌مونیم (کاربر
      // می‌تونه مرحله‌ها رو هم از این‌جا انتخاب/غیرفعال کنه).
      this.setStatus('ready');
      this.setDetail('Connected to the server. Review the steps below and press Start when ready.');
      await new Promise((resolve) => { this.beginResolver = resolve; });
      if (!this.selectedSteps) this.selectedSteps = DEFAULT_STEPS();
      const steps = this.selectedSteps;

      this.setStatus('running');
      this.setDetail('Starting...');

      // هر فاز جدا try/catch دارد تا شکست یک مرحله (مثلاً یک prompt که با
      // متن حدسی ما از اسکریپت رسمی x-ui جور درنمیاد) بقیه‌ی مراحل مهم‌تر
      // (باز کردن پورت پنل، ریستور دیتابیس، عوض کردن یوزر/پس) را قربانی نکند.
      const warnings = [];
      const phase = async (key, label, fn) => {
        if (steps && steps[key] === false) {
          this.appendLog('\r\n[SKIP] ' + label + ' — unchecked by user.\r\n');
          return;
        }
        try { await fn(); }
        catch (e) {
          const msg = label + ': ' + (e && e.message ? e.message : String(e));
          warnings.push(msg);
          this.appendLog('\r\n[WARN] ' + msg + ' — continuing with the next step...\r\n');
        }
      };

      // ۱) سه اسکریپت
      await phase('installer', 'Step 1: alis-installer.sh (password/DNS/repos/panel install)', () => this.runScriptA(ssh));
      await phase('ufw', 'Step 2: alis-ufw-manager.sh (open ports)', () => this.runScriptB(ssh));
      await phase('ssl', 'Step 3: alis-fake-ssl-manager.sh (domain certificates)', () => this.runScriptC(ssh));

      // ۲) ریستور بکاپ x-ui.db از طریق پنل (با آدرس/پسورد همون لحظه‌ی نصب)
      await phase('restore', 'Step 4: restore panel database backup', () => this.restorePanelBackup(ssh));

      // ۳) ری‌استارت پنل
      await phase('restart', 'Step 5: restart panel (x-ui > 14)', () => this.restartPanel(ssh));

      // ۴) تنظیم پنل: پسورد/یوزر + دامنه (بعد از Restore) — پورت دیگه این‌جا عوض نمی‌شه
      await phase('panelConfig', 'Step 6: set panel password + domain', () => this.applyPanelConfig(ssh, { includeDomain: true }));

      // ۵) پورت پنل (از کادر توی صفحه، پیش‌فرض 443) + ری‌استارت + ufw allow
      await phase('panelPort', 'Step 7: set panel port to ' + this.panelPortChoice + ' + restart + ufw allow', () => this.finalizePanelPort(ssh, this.panelPortChoice));

      // ۶) خوندن تنظیمات نهایی برای فایل نتیجه
      await phase('finalSettings', 'Step 8: read final panel settings (x-ui > 11)', () => this.captureFinalSettings(ssh));

      this.setDetail('Finalizing — preparing the result file...');
      this.result = this.buildResultText(warnings);
      await this.persist();
      this.setStatus('done');
      this.setDetail(warnings.length
        ? 'Finished with ' + warnings.length + ' warning(s) — see the console log for details. Result file is ready below.'
        : 'All steps completed. Result file is ready below.');
      // اگه کسی دستی قطع نکنه، بعد از ۱۰ دقیقه خودش قطع می‌کنه.
      try { await this.state.storage.setAlarm(Date.now() + 10 * 60 * 1000); } catch (e) {}
    } catch (e) {
      this.setDetail('Automation stopped: ' + (e && e.message ? e.message : String(e)) + '. The console is still live — you can continue manually.');
      this.setStatus('error');
      try { await this.state.storage.setAlarm(Date.now() + 10 * 60 * 1000); } catch (e2) {}
    }
  }

  async resync(ssh) {
    // اگه همین الان سر پرامپت خامیم (اکثر وقتا همینه)، هیچ کاری نکن —
    // فرستادن Ctrl+C/خط خالی اضافه فقط نویز اضافه می‌کنه و بعضی‌جاها
    // (مثل یه منوی تعاملی که تازه باز شده) اشتباهی به‌عنوان یه انتخاب
    // نامعتبر خونده می‌شه.
    if (this.buf.slice(-200).includes(PS1_MARK)) return;
    // وسط یه منو یا پرامپت گیر کردیم؛ چندبار Ctrl+C می‌فرستیم تا خارج بشه.
    for (let i = 0; i < 2; i++) {
      try {
        const from = this.buf.length;
        await ssh.write('\x03\x03\n');
        if (await this.waitFor(PS1_MARK, 6000, from)) return;
      } catch (e) {}
    }
  }

  async shellCmd(ssh, cmd, waitMarker = PS1_MARK, timeout = 20000) {
    const from = this.buf.length;
    await ssh.write(cmd + '\n');
    const r = await this.waitFor(waitMarker, timeout, from);
    if (!r) throw new Error('Timed out waiting for: ' + cmd);
    return r;
  }

  async uploadHeredoc(ssh, remotePath, content) {
    const token = 'WRKUP_' + rid(12);
    await ssh.write(`cat > ${remotePath} << '${token}'\n`);
    // send in modest chunks to avoid overwhelming the channel
    for (let i = 0; i < content.length; i += 4000) { await ssh.write(content.slice(i, i + 4000)); await new Promise(r => setTimeout(r, 30)); }
    await ssh.write(`\n${token}\n`);
    await ssh.write(`chmod +x ${remotePath}\necho UPLOADED_${token}\n`);
    const r = await this.waitFor('UPLOADED_' + token, 30000);
    if (!r) throw new Error('Failed to upload ' + remotePath);
  }

  async runScriptA(ssh) {
    this.setDetail('Uploading & running alis-installer.sh ...');
    await this.uploadHeredoc(ssh, '/root/alis-installer.sh', SCRIPT_INSTALLER);
    await ssh.write('bash /root/alis-installer.sh\n');
    await this.waitFor('Please select an option [1-8]:', 20000);

    this.setDetail('Step 2/12: Configuring root & SSH users...');
    await ssh.write('2\n');
    await this.waitFor('Press any key to return to menu...', 60000);
    await ssh.write(' ');
    await this.waitFor('Please select an option [1-8]:', 15000);

    this.setDetail('Step 3/12: Setting DNS to Google (8.8.8.8/8.8.4.4)...');
    await ssh.write('3\n');
    await this.waitFor('Choose an option [1-4]:', 10000);
    await ssh.write('1\n');
    await this.waitFor('Press any key to return to menu...', 20000);
    await ssh.write(' ');
    await this.waitFor('Please select an option [1-8]:', 15000);

    this.setDetail('Step 4/12: Restoring official Ubuntu repositories...');
    await ssh.write('4\n');
    await this.waitFor('Press any key to return to menu...', 60000);
    await ssh.write(' ');
    await this.waitFor('Please select an option [1-8]:', 15000);

    this.setDetail('Step 5/12: Disabling UFW & installing 3x-ui panel (this can take a few minutes)...');
    const beforeLen = this.buf.length;
    await ssh.write('6\n');
    await this.waitFor('Press any key to return to menu...', 10 * 60 * 1000);
    const installOutput = this.buf.slice(beforeLen);
    this.panel = this.parsePanelOutput(installOutput);
    if (this.panel) this.setDetail('3x-ui installed — Access URL: ' + this.panel.url);
    await ssh.write(' ');
    await this.waitFor('Please select an option [1-8]:', 15000);

    await ssh.write('8\n');
    await this.waitFor(PS1_MARK, 15000);

    // حالا دوباره روی پرامپت خام bash هستیم — همین‌جا به‌عنوان یک
    // محافظ زودهنگام (مستقل از موفقیت مراحل بعدی) پورت پنل را باز می‌کنیم.
    if (this.panel && this.panel.port) {
      await this.shellCmd(ssh, `ufw allow ${this.panel.port}/tcp 2>/dev/null || true`, PS1_MARK, 10000).catch(() => {});
    }
  }

  parsePanelOutput(rawText) {
    // خروجی x-ui پر از کد رنگ ANSI (مثل \x1b[0m) هست که اگه پاک نشه،
    // می‌چسبه ته هر مقدار (مثلاً پورت می‌شه "40976\x1b[0m"). قبل از
    // regex پاکش می‌کنیم.
    const text = rawText.replace(/\x1b\[[0-9;]*m/g, '');
    const get = (re) => { const m = text.match(re); return m ? m[1].trim() : null; };
    const username = get(/Username:\s*(\S+)/);
    const password = get(/Password:\s*(\S+)/);
    const port = get(/Port:\s*(\S+)/);
    const base = get(/WebBasePath:\s*(\S+)/);
    const url = get(/Access URL:\s*(\S+)/);
    const token = get(/API Token:\s*(\S+)/);
    if (!username || !password || !url) return null;
    return { username, password, port, base, url, token };
  }

  async fetchPanelPorts() {
    // لیست پورت‌ها رو از گیت‌هاب می‌گیریم تا نیازی نباشه خود پروژه رو هر
    // بار که پورت جدید اضافه شد آپدیت کنیم؛ اگه گرفتنش شکست خورد، از لیست
    // ثابت توی خود کد استفاده می‌کنیم.
    try {
      const sep = PANEL_PORTS_URL.includes('?') ? '&' : '?';
      const r = await fetch(PANEL_PORTS_URL + sep + 't=' + Date.now());
      if (!r.ok) return FALLBACK_PANEL_PORTS;
      const text = await r.text();
      const ports = text.split(/\s+/).map((s) => s.trim()).filter(Boolean);
      return ports.length ? ports : FALLBACK_PANEL_PORTS;
    } catch (e) {
      return FALLBACK_PANEL_PORTS;
    }
  }

  async runScriptB(ssh) {
    await this.resync(ssh);
    this.setDetail('Step 6/12: Uploading & running alis-ufw-manager.sh ...');
    await this.uploadHeredoc(ssh, '/root/alis-ufw-manager.sh', SCRIPT_UFW);
    await ssh.write('bash /root/alis-ufw-manager.sh\n');
    await this.waitFor('Select an option (1-6):', 15000);

    this.setDetail('Step 7/12: Installing & enabling UFW...');
    await ssh.write('1\n');
    await this.waitFor('Press Enter to return to the menu...', 30000);
    await ssh.write('\n');
    await this.waitFor('Select an option (1-6):', 15000);

    this.setDetail('Step 7b/12: Fetching the port list and opening it...');
    const ports = await this.fetchPanelPorts();
    await ssh.write('2\n');
    await this.waitFor("Type 'END' and press Enter when finished:", 10000);
    for (const p of ports) await ssh.write(p + '\n');
    await ssh.write('END\n');
    await this.waitFor('Press Enter to return to the menu...', 30000);
    await ssh.write('\n');
    await this.waitFor('Select an option (1-6):', 15000);

    await ssh.write('6\n');
    await this.waitFor(PS1_MARK, 15000);
  }

  async fetchDomains() {
    // لیست دامنه‌ها رو از گیت‌هاب می‌گیریم (مثل ports.txt)؛ اولین دامنه‌ی
    // این لیست همونیه که بعداً برای مسیر SSL پنل (x-ui > 20 > 5 > 1) هم
    // استفاده می‌شه. اگه گرفتنش شکست بخوره، از لیست ثابت fallback می‌کنیم.
    try {
      const sep = DOMAINS_URL.includes('?') ? '&' : '?';
      const r = await fetch(DOMAINS_URL + sep + 't=' + Date.now());
      if (!r.ok) return FALLBACK_DOMAINS;
      const text = await r.text();
      const domains = text.split(/\s+/).map((s) => s.trim()).filter(Boolean);
      return domains.length ? domains : FALLBACK_DOMAINS;
    } catch (e) {
      return FALLBACK_DOMAINS;
    }
  }

  async runScriptC(ssh) {
    await this.resync(ssh);
    this.domains = await this.fetchDomains();
    this.setDetail('Step 9/12: Uploading & running alis-fake-ssl-manager.sh ...');
    await this.uploadHeredoc(ssh, '/root/alis-fake-ssl-manager.sh', SCRIPT_FAKESSL);
    await ssh.write('bash /root/alis-fake-ssl-manager.sh\n');
    await this.waitFor('Please select an option [1-5]:', 15000);

    for (const d of this.domains) {
      this.setDetail('Step 10/12: Generating SSL for ' + d + ' ...');
      await ssh.write('1\n');
      await this.waitFor('Enter your Domain name', 10000);
      await ssh.write(d + '\n');
      const r = await this.waitFor(['Press any key to return to menu...'], 30000);
      if (!r) { this.setDetail('Warning: SSL generation for ' + d + ' did not finish as expected — check console.'); }
      await ssh.write(' ');
      await this.waitFor('Please select an option [1-5]:', 15000);
    }

    this.setDetail('Step 11/12: Deploying all domains to 3x-ui (Panel, Sub, Inbounds)...');
    await ssh.write('2\n');
    const pick = await this.waitFor(['Which domain for Panel & Subscription?', 'Please select an option [1-5]:'], 10000);
    if (pick && pick.marker.startsWith('Which domain')) {
      await ssh.write('\n'); // accept default (last domain)
      await this.waitFor('Press any key to return to menu...', 60000);
      await ssh.write(' ');
      await this.waitFor('Please select an option [1-5]:', 15000);
    }

    await ssh.write('5\n');
    await this.waitFor(PS1_MARK, 15000);
  }

  async applyPanelConfig(ssh, { includeDomain = true } = {}) {
    // یه "دور" تنظیم پنل: پسورد/یوزر، و اختیاری مسیر دامنه/گواهی.
    // (تغییر پورت از این‌جا جدا شد و مرحله‌ی خودش رو داره: finalizePanelPort)
    // دور اول (قبل از Restore) عمداً دامنه رو ست نمی‌کنه، تا Restore با
    // همون آدرس IP:port انجام بشه؛ دور دوم (بعد از ری‌استارت) هر سه‌تا رو
    // می‌زنه، چون Restore ممکنه یوزر/پس رو هم از روی فایل بکاپ برگردونه.
    await this.resetPanelCredentials(ssh);
    if (includeDomain) await this.setPanelCertPath(ssh);
  }

  async restorePanelBackup(ssh) {
    await this.resync(ssh);
    if (!this.panel) { this.setDetail('Could not read panel credentials automatically — check the console and finish the remaining steps manually.'); this.setStatus('need_input'); return; }

    // open the panel port in ufw just in case (the earlier big list already includes most common ports, but ensure the actual one is open)
    if (this.panel.port) {
      this.setDetail('Ensuring panel port ' + this.panel.port + ' is open in UFW...');
      await this.shellCmd(ssh, `ufw allow ${this.panel.port}/tcp`, PS1_MARK, 15000).catch(() => {});
    }

    // fetch the backup db — either user-uploaded, or from the GitHub repo
    this.setDetail('Preparing panel database backup file...');
    const db = await this.loadDbFromStorage();
    let dbBytes = db;
    if (!dbBytes) {
      try {
        const resp = await fetch(PANEL_DB_RAW_URL);
        if (resp.ok) dbBytes = new Uint8Array(await resp.arrayBuffer());
      } catch (e) {}
    }

    if (dbBytes && this.env.BROWSER) {
      await this.restoreViaBrowser(dbBytes).then(() => {
        this.restoreStatus = 'OK — restored automatically via the browser.';
      }).catch((e) => {
        this.restoreStatus = 'FAILED — ' + e.message;
        this.setDetail('Automatic panel restore failed (' + e.message + '). Log in manually at ' + this.panel.url + ' and restore the backup yourself, then continue.');
        this.appendLog('\r\n[WARN] automatic panel restore failed: ' + e.message + ' — restore it manually at ' + this.panel.url + '\r\n');
      });
    } else if (!this.env.BROWSER) {
      this.restoreStatus = 'SKIPPED — Browser Rendering is not configured on this deployment (see README).';
      this.setDetail('Browser Rendering binding is not configured — skipping automatic panel restore. See README to enable it, or restore the backup manually at ' + this.panel.url + '.');
      this.appendLog('\r\n[WARN] Browser Rendering binding is not configured — automatic restore skipped. Restore manually at ' + this.panel.url + '\r\n');
    } else {
      this.restoreStatus = 'SKIPPED — no backup .db file was available (upload one, or check the GitHub ports/backup URLs are reachable).';
      this.setDetail('No backup .db file available (upload one or ensure the GitHub repo is reachable) — skipping automatic restore.');
      this.appendLog('\r\n[WARN] no backup .db bytes available — automatic restore skipped.\r\n');
    }
  }

  async restartPanel(ssh) {
    // کنسول: x-ui -> 14) Restart. بعد از ری‌استارت یه پیغام "Press enter to
    // return to the main menu:" میاد که باید صریح Enter بزنیم، وگرنه
    // ورودی بعدی‌مون (مثلاً "0") اشتباهی روی همون پرامپت می‌افته.
    await this.resync(ssh);
    this.setDetail('Restarting the panel (x-ui > 14 Restart)...');
    await ssh.write('x-ui\n');
    const menu = await this.waitFor(['Please choose an option', 'Please enter'], 15000);
    if (!menu) { this.appendLog('\r\n[WARN] x-ui menu not detected — restart the panel manually: x-ui > 14\r\n'); return; }
    await ssh.write('14\n');
    await this.waitFor(['Press enter to return', 'Restarted successfully'], 20000).catch(() => {});
    await ssh.write('\n');
    await new Promise((r) => setTimeout(r, 500));
    await ssh.write('0\n');
    await this.resync(ssh);
    // چند ثانیه مهلت بده تا xray/پنل کامل بالا بیاد قبل از دور دوم تنظیمات
    await new Promise((r) => setTimeout(r, 4000));
  }

  async setPanelCertPath(ssh) {
    // x-ui -> 20 (SSL Certificate Management) -> 5 (Set Cert paths for the
    // panel) -> 1 (Use a certificate from /root/cert) -> اولین دامنه‌ی
    // لیست domains.txt (یا fallback اگه گرفتنش شکست خورده بود).
    const certDomain = (this.domains && this.domains[0]) || FALLBACK_DOMAINS[0];
    this.certDomain = certDomain;
    await this.resync(ssh);
    this.setDetail(`Setting panel SSL cert path via the x-ui menu (20 > 5 > 1 > ${certDomain})...`);
    await ssh.write('x-ui\n');
    const menu = await this.waitFor(['Please choose an option', 'Please enter'], 15000);
    if (!menu) { this.appendLog(`\r\n[WARN] x-ui menu not detected — set the cert path manually: x-ui > 20 > 5 > 1 > ${certDomain}\r\n`); return; }
    // توجه: این دو زیرمنو متن پرامپتشون "Choose an option:" هست، نه
    // "Please choose"/"Please enter" (که مال منوی اصلیه) — قبلاً به‌خاطر
    // این فرق، کد ۱۰ ثانیه الکی صبر می‌کرد.
    await ssh.write('20\n');
    await this.waitFor('Choose an option:', 10000);
    await ssh.write('5\n');
    await this.waitFor('Choose an option:', 10000);
    await ssh.write('1\n');
    await this.waitFor(['domain', 'Domain'], 10000);
    await ssh.write(certDomain + '\n');
    await this.waitFor(['Press enter to return', PS1_MARK], 20000).catch(() => {});
    await ssh.write('\n');
    await new Promise((r) => setTimeout(r, 500));
    await ssh.write('0\n');
    await this.resync(ssh);
  }

  async finalizePanelPort(ssh, port = DEFAULT_PANEL_PORT) {
    // x-ui -> 10) Change Port -> هر پورتی که کاربر توی کادر نوشته (پیش‌فرض
    // 443). نکته‌ی مهم: این صفحه بعد از ثبت پورت یه پرامپت
    // "Restart the panel ... [Default y]:" هم می‌پرسه که باید صریح
    // جوابش بدیم (y = ری‌استارت پنل) — وگرنه ورودی بعدیِ ما (مثلاً "0" برای
    // خروج) اشتباهی روی همین پرامپت می‌افته. بعدش ufw allow همون پورت.
    port = Number(port) || DEFAULT_PANEL_PORT;
    await this.resync(ssh);
    this.setDetail('Setting the panel port to ' + port + ' (x-ui > 10)...');
    await ssh.write('x-ui\n');
    const menu = await this.waitFor(['Please choose an option', 'Please enter'], 15000);
    if (!menu) { this.appendLog(`\r\n[WARN] x-ui menu not detected — run \`x-ui\` then option 10 manually to set the port to ${port}, then: ufw allow ${port}/tcp\r\n`); return; }

    await ssh.write('10\n');
    const portPrompt = await this.waitFor(/port/i, 10000);
    if (!portPrompt) { this.appendLog('\r\n[WARN] port prompt not detected on option 10.\r\n'); await ssh.write('0\n'); await this.resync(ssh); return; }
    const fromPort = this.buf.length;
    await ssh.write(port + '\n');

    const restartPrompt = await this.waitFor('Restart the panel', 15000, fromPort);
    if (restartPrompt) await ssh.write('y\n');
    await new Promise((r) => setTimeout(r, 2000)); // مهلت تا ری‌استارت واقعاً انجام بشه

    await ssh.write('0\n');
    await this.resync(ssh);

    // حالا روی پرامپت خام bash هستیم — پورت رو هم توی UFW باز می‌کنیم.
    this.setDetail('Opening port ' + port + ' in UFW...');
    await this.shellCmd(ssh, `ufw allow ${port}/tcp 2>/dev/null || true`, PS1_MARK, 10000).catch(() => {});
    this.portForced = true;
    this.panel = this.panel || {};
    const oldPort = this.panel.port;
    this.panel.port = String(port);
    // اگه مرحله‌ی ۸ رد بشه، آدرس نتیجه هم پورت جدید رو داشته باشه
    if (this.panel.url && oldPort && String(oldPort) !== String(port)) {
      this.panel.url = this.panel.url.replace(':' + oldPort, ':' + port);
    }
  }

  parseLiveSettings(rawText) {
    // فرمت خروجی x-ui > 11 توی این نسخه با فرمت لحظه‌ی نصب فرق داره و
    // اصلاً یوزرنیم/پسورد/API Token رو نشون نمی‌ده، فقط اینا رو داره:
    //   port: 2083
    //   webBasePath: /xxxxx/
    //   Access URL: https://domain:2083/xxxxx/
    const text = rawText.replace(/\x1b\[[0-9;]*m/g, '');
    const get = (re) => { const m = text.match(re); return m ? m[1].trim() : null; };
    const port = get(/\bport:\s*(\d+)/i);
    const base = get(/webBasePath:\s*(\S+)/i);
    const url = get(/Access URL:\s*(\S+)/i);
    if (!port && !url) return null;
    return { port, base, url };
  }

  async captureFinalSettings(ssh) {
    // مرحله‌ی آخر خودِ آخر: بعد از عوض شدن مسیر SSL، یوزر/پس و پورت، یه بار
    // دیگه x-ui -> 11 (View Current Settings) رو می‌زنیم. به‌جای حدس زدن
    // اینکه منو کِی دوباره ظاهر می‌شه، منتظر پایان خروجی (پرامپت bash یا منو) می‌مونیم.
    await this.resync(ssh);
    this.setDetail('Reading final panel settings (x-ui > 11)...');
    await ssh.write('x-ui\n');
    const menu = await this.waitFor(['Please choose an option', 'Please enter'], 15000);
    if (!menu) { this.appendLog('\r\n[WARN] could not re-open the x-ui menu to read final settings — the result below may still show install-time values.\r\n'); return; }

    const before = this.buf.length;
    await ssh.write('11\n');
    // آخر خروجیِ گزینه‌ی ۱۱ یا خودِ پرامپت bash هست (اسکریپت بعد از نمایش
    // تنظیمات می‌پره بیرون) یا برمی‌گرده به منو. هر کدوم اومد یعنی خروجی
    // کامل شده — دیگه صبر ثابت نداریم. جستجو از قبل از نوشتن شروع می‌شه.
    const end = await this.waitFor([PS1_MARK, 'Press enter to return', 'Please enter your selection'], 12000, before);
    const settings = this.buf.slice(before);
    const live = this.parseLiveSettings(settings);
    if (live) {
      this.panel = this.panel || {};
      if (live.port) this.panel.port = live.port;
      if (live.base) this.panel.base = live.base;
      if (live.url) this.panel.url = live.url;
      // این نسخه‌ی x-ui دیگه یوزر/پس رو توی option 11 نشون نمی‌ده؛ چون
      // خودمون با گزینه‌ی ۷ ست‌شون کردیم، همون مقادیر رو می‌دونیم.
      if (this.credsReset) { this.panel.username = 'adminas'; this.panel.password = 'alirezavps'; }
      this.liveSettingsOk = true;
    } else {
      this.appendLog('\r\n[WARN] could not parse the option-11 output — the result below falls back to earlier values, double-check them against the console.\r\n');
    }

    // اگه اسکریپت خودش به bash برگشته، دیگه '0' نمی‌فرستیم (قبلاً می‌شد
    // "0: command not found"). فقط وقتی هنوز تو منوئیم خارج می‌شیم.
    if (end && end.marker !== PS1_MARK) {
      if (end.marker === 'Press enter to return') await ssh.write('\n');
      await ssh.write('0\n');
    }
    await this.resync(ssh);
  }

  async resetPanelCredentials(ssh) {
    await this.resync(ssh);
    // متن دقیق پرامپت‌های x-ui > 7 رو از لاگ واقعی خودت داریم، پس دیگه
    // حدس نمی‌زنیم؛ هر پرامپت با یه رشته‌ی دقیق و یکتا شناسایی می‌شه:
    //   "Are you sure to reset the username and password of the panel? [Default n]: "
    //   "Please set the login username [default is a random username]: "
    //   "Please set the login password [default is a random password]: "
    //   (اگه 2FA از قبل فعال بوده) "Do you want to disable currently configured two-factor authentication? (y/n): "
    //   "Restart the panel, Attention: Restarting the panel will also restart xray [Default y]: "
    this.setDetail('Resetting panel username & password to adminas / alirezavps...');
    await ssh.write('x-ui\n');
    const menu = await this.waitFor(['Please choose an option', 'Please enter'], 15000);
    if (!menu) { this.appendLog('\r\n[WARN] x-ui menu not detected — run `x-ui` then option 7 manually to set the final username/password.\r\n'); return; }

    await ssh.write('7\n');
    if (!(await this.waitFor('reset the username and password of the panel', 10000))) {
      this.appendLog('\r\n[WARN] confirm prompt not detected for option 7.\r\n');
      await ssh.write('0\n'); await this.resync(ssh); return;
    }
    await ssh.write('y\n');

    if (!(await this.waitFor('set the login username', 10000))) {
      this.appendLog('\r\n[WARN] username prompt not detected during credential reset.\r\n');
      await this.resync(ssh); return;
    }
    await ssh.write('adminas\n');

    if (!(await this.waitFor('set the login password', 10000))) {
      this.appendLog('\r\n[WARN] password prompt not detected during credential reset.\r\n');
      await this.resync(ssh); return;
    }
    await ssh.write('alirezavps\n');

    // این پرامپت فقط وقتی میاد که 2FA از قبل (مثلاً از فایل بکاپ ریستورشده) فعال بوده باشه
    const after = await this.waitFor(['two-factor authentication', 'Restart the panel'], 15000);
    if (after && after.marker === 'two-factor authentication') {
      await ssh.write('y\n');
      await this.waitFor('Restart the panel', 15000).catch(() => {});
    }
    await ssh.write('y\n'); // جواب "Restart the panel ... [Default y]:"
    await new Promise((r) => setTimeout(r, 2000)); // مهلت تا ری‌استارت واقعاً انجام بشه

    await ssh.write('0\n');
    await this.resync(ssh);

    this.credsReset = true;
  }

  async restoreViaBrowser(dbBytes) {
    const puppeteer = await import('@cloudflare/puppeteer');
    const browser = await puppeteer.launch(this.env.BROWSER, { ignoreHTTPSErrors: true });
    try {
      const page = await browser.newPage();
      await page.setBypassCSP(true).catch(() => {});
      try {
        const client = await page.createCDPSession();
        await client.send('Security.setIgnoreCertificateErrors', { ignore: true });
      } catch (e) {}
      await page.goto(this.panel.url, { waitUntil: 'networkidle0', timeout: 30000 });
      await this.loginIfNeeded(page);

      // طبق اسکرین‌شاتی که دادی: تب بالای پنل «Backup & Restore» رو می‌زنیم
      // تا مودال باز بشه، بعد مستقیم فایل رو روی input[type=file] داخل
      // همون مودال ست می‌کنیم (دکمه‌ی آبی کوچیک خودش یه input مخفی داره؛
      // چون مستقیم .files رو ست می‌کنیم، نیازی به کلیک خود دکمه نیست).
      const opened = await this.clickByText(page, ['Backup & Restore']);
      if (!opened) throw new Error('could not find the "Backup & Restore" tab');
      await new Promise((r) => setTimeout(r, 1000));

      const uploaded = await page.evaluate((b64) => {
        const bin = atob(b64); const arr = new Uint8Array(bin.length);
        for (let i = 0; i < bin.length; i++) arr[i] = bin.charCodeAt(i);
        const file = new File([arr], 'x-ui.db', { type: 'application/octet-stream' });
        const dt = new DataTransfer(); dt.items.add(file);
        // چند تا input[type=file] ممکنه توی صفحه باشه (مثلاً خود Back Up
        // یه لینک دانلوده نه input)؛ اونی که به متن «Restore» نزدیک‌تره
        // رو انتخاب می‌کنیم، وگرنه اولین موردی که پیدا بشه.
        const inputs = Array.from(document.querySelectorAll('input[type=file]'));
        if (inputs.length === 0) return false;
        let target = inputs[0];
        let best = Infinity;
        for (const inp of inputs) {
          let el = inp, depth = 0, dist = Infinity;
          while (el && depth < 6) {
            const t = (el.textContent || '').toLowerCase();
            if (t.includes('restore') && !t.includes('back up')) { dist = depth; break; }
            el = el.parentElement; depth++;
          }
          if (dist < best) { best = dist; target = inp; }
        }
        target.files = dt.files;
        target.dispatchEvent(new Event('change', { bubbles: true }));
        target.dispatchEvent(new Event('input', { bubbles: true }));
        return true;
      }, btoa(String.fromCharCode(...dbBytes)));
      if (!uploaded) throw new Error('could not find the restore file-upload control');

      await new Promise((r) => setTimeout(r, 2500));
      // بعضی نسخه‌ها بعد از ست‌شدن فایل یه دکمه‌ی تایید جدا هم دارن؛ اگه
      // نبود این خط فقط بی‌اثره، خطا نمی‌ده.
      await this.clickByText(page, ['Upload', 'Confirm', 'OK']).catch(() => {});
      await new Promise((r) => setTimeout(r, 2500));
      this.setDetail('Panel database restored from backup.');
    } finally {
      await browser.close().catch(() => {});
    }
  }

  async loginIfNeeded(page) {
    const userSel = await page.$('input[placeholder*="sername" i], input[name="username"]');
    if (!userSel) return;
    await userSel.type(this.panel.username, { delay: 20 });
    const passSel = await page.$('input[type=password]');
    if (passSel) await passSel.type(this.panel.password, { delay: 20 });
    await this.clickByText(page, ['Login', 'Sign in', 'ورود']);
    await page.waitForTimeout(1500);
  }

  async clickByText(page, candidates) {
    const handle = await page.evaluateHandle((cands) => {
      const all = Array.from(document.querySelectorAll('button, a, div, span, li'));
      for (const c of cands) {
        const el = all.find(e => e.children.length === 0 && e.textContent && e.textContent.trim().toLowerCase().includes(c.toLowerCase()));
        if (el) return el;
      }
      return null;
    }, candidates);
    const el = handle.asElement();
    if (el) { await el.click(); return true; }
    return false;
  }

  buildResultText(warnings = []) {
    const p = this.panel || {};
    const finalUser = this.credsReset ? 'adminas' : (p.username || '?');
    const finalPass = this.credsReset ? 'alirezavps' : (p.password || '?');
    return [
      '=== Server ===',
      `Status: automation finished`,
      '',
      '=== 3x-ui Panel (read live via x-ui > 11 at the very end) ===',
      `Username:    ${finalUser}${this.credsReset ? '  (reset at the end, via x-ui > 7)' : ''}`,
      `Password:    ${finalPass}${this.credsReset ? '  (reset at the end, via x-ui > 7)' : ''}`,
      `Port:        ${p.port || '?'}`,
      `WebBasePath: ${p.base || '?'}`,
      `Access URL:  ${p.url || '?'}`,
      `API Token:   ${p.token || '?'}`,
      '',
      '=== TLS domains ===',
      ...((this.domains || FALLBACK_DOMAINS).map(d => ' - ' + d)),
      '',
      `Panel cert path set to: ${this.certDomain || (this.domains && this.domains[0]) || FALLBACK_DOMAINS[0]} (via x-ui > 20 > 5 > 1)`,
      `Database restore: ${this.restoreStatus || 'UNKNOWN — the restore step may not have run at all; check the console log.'}`,
      '',
      ...(warnings.length ? ['=== Warnings (steps that may need a manual check) ===', ...warnings.map(w => ' - ' + w), ''] : []),
      'Generated by the automation worker.',
    ].join('\n');
  }
}
