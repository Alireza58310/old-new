// Helpers مشترک برای ربات تلگرام (فقط fetch استاندارد — بدون وابستگی)

export const STEP_LABELS = {
  installer: '۱) نصب (رمز/DNS/ریپو/3x-ui)',
  ufw: '۲) باز کردن پورت‌ها (UFW)',
  ssl: '۳) سرتیفیکیت دامنه‌ها',
  restore: '۴) ریستور بکاپ پنل',
  restart: '۵) ری‌استارت پنل',
  panelConfig: '۶) یوزر/پسورد/دامنه‌ی پنل',
  panelPort: '۷) پورت پنل + ufw',
  finalSettings: '۸) تنظیمات نهایی + نتیجه',
};
export const STEP_KEYS_UI = Object.keys(STEP_LABELS);

export const ICON = { idle: '⚪', connecting: '🔌', ready: '🟢', running: '⚙️', done: '✅', error: '❌', closed: '🔒', need_input: '✋', waiting_db_upload: '📦' };

export function esc(s) {
  return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

// حذف escape-code های ترمینال تا متن توی تلگرام خوانا باشه
export function stripAnsi(s) {
  return String(s || '')
    .replace(/\x1b\[[0-9;?]*[ -\/]*[@-~]/g, '')
    .replace(/\x1b\][^\x07]*\x07/g, '')
    .replace(/\x1b[()][A-Za-z0-9]/g, '')
    .replace(/\r\n/g, '\n')
    .replace(/[^\n]*\r/g, '')
    .replace(/[\x00-\x08\x0b\x0c\x0e-\x1f]/g, '');
}

export function tail(s, n) {
  n = n || 3400;
  s = stripAnsi(s).split('###WRKRDY###').join('').replace(/\n{3,}/g, '\n\n').trim();
  return s.length > n ? '…' + s.slice(-n) : s;
}

export async function tgApi(token, method, body) {
  try {
    const r = await fetch('https://api.telegram.org/bot' + token + '/' + method, {
      method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(body || {}),
    });
    try { return await r.json(); } catch (e) { return { ok: false, description: 'HTTP ' + r.status }; }
  } catch (e) {
    return { ok: false, description: 'network: ' + (e && e.message ? e.message : String(e)) };
  }
}

export async function tgSendDoc(token, chatId, filename, content, caption) {
  try {
    const fd = new FormData();
    fd.append('chat_id', String(chatId));
    if (caption) fd.append('caption', caption.slice(0, 900));
    fd.append('document', new Blob([content], { type: 'text/plain' }), filename);
    const r = await fetch('https://api.telegram.org/bot' + token + '/sendDocument', { method: 'POST', body: fd });
    try { return await r.json(); } catch (e) { return { ok: false }; }
  } catch (e) { return { ok: false, description: String(e) }; }
}

export function stepsKeyboard(sid, steps, port) {
  steps = steps || {};
  const rows = STEP_KEYS_UI.map((k) => [{ text: (steps[k] !== false ? '✅ ' : '⬜ ') + STEP_LABELS[k], callback_data: 't:' + sid + ':' + k }]);
  rows.push([{ text: '🔌 پورت پنل: ' + port + '  (تغییر)', callback_data: 'p:' + sid }]);
  rows.push([{ text: '▶️ Start', callback_data: 'b:' + sid }]);
  return { inline_keyboard: rows };
}

export function controlKeyboard(sid) {
  return { inline_keyboard: [
    [{ text: '📊 وضعیت', callback_data: 's:' + sid }, { text: '📜 لاگ', callback_data: 'l:' + sid }, { text: '📄 نتیجه', callback_data: 'r:' + sid }],
    [{ text: '⌨️ کنسول', callback_data: 'c:' + sid }, { text: '⛔ قطع اتصال', callback_data: 'x:' + sid }],
  ] };
}

export function keysKeyboard(sid) {
  const b = (t, k) => ({ text: t, callback_data: 'k:' + sid + ':' + k });
  return { inline_keyboard: [
    [b('Ctrl+C', 'c'), b('Ctrl+D', 'd'), b('Ctrl+Z', 'z'), b('Tab', 't')],
    [b('Enter', 'e'), b('↑', 'u'), b('↓', 'n'), { text: '📜 لاگ', callback_data: 'l:' + sid }],
    [{ text: '🚪 خروج از حالت کنسول', callback_data: 'co:off' }],
  ] };
}

export const KEY_CODES = { c: '\x03', d: '\x04', z: '\x1a', t: '\t', e: '\r', u: '\x1b[A', n: '\x1b[B' };
