// متدهای تلگرام برای SessionDO (با Object.assign روی prototype اضافه می‌شن)
import { tgApi, tgSendDoc, esc, tail, ICON, controlKeyboard, stepsKeyboard } from './tg.js';

const J = (o, s) => new Response(JSON.stringify(o), { status: s || 200, headers: { 'content-type': 'application/json' } });

export const tgMethods = {
  // مسیرهای داخلی (فقط از داخل Worker قابل دسترسی‌ان: kv و tg-*)
  async tgRoute(request, url) {
    const sidH = request.headers.get('x-sid');
    if (sidH) this.sid = sidH;
    const p = url.pathname;
    if (p.endsWith('/kv-get')) { const v = await this.state.storage.get('kv_' + url.searchParams.get('k')); return J({ v: v === undefined ? null : v }); }
    if (p.endsWith('/kv-set') && request.method === 'POST') { const b = await request.json(); await this.state.storage.put('kv_' + b.k, b.v); return J({ ok: true }); }
    if (p.endsWith('/kv-del') && request.method === 'POST') { const b = await request.json(); await this.state.storage.delete('kv_' + b.k); return J({ ok: true }); }
    if (p.endsWith('/tg-info')) {
      return J({ status: this.status, detail: this.detail, host: this.tgHost || null, steps: this.selectedSteps || {}, port: this.panelPortChoice, readyMsgId: this.tgReadyMsgId || null, hasResult: !!this.result, ssh: !!(this.ssh && !this.ssh.closed) });
    }
    if (p.endsWith('/tg-toggle') && request.method === 'POST') {
      const { key } = await request.json();
      if (this.status !== 'ready') return J({ ok: false, error: 'not ready' });
      if (!this.selectedSteps) this.selectedSteps = {};
      this.selectedSteps[key] = this.selectedSteps[key] === false;
      return J({ ok: true, steps: this.selectedSteps, port: this.panelPortChoice });
    }
    if (p.endsWith('/tg-port') && request.method === 'POST') {
      const { port } = await request.json();
      const n = Number(port);
      if (!(Number.isInteger(n) && n >= 1 && n <= 65535)) return J({ ok: false, error: 'bad port' });
      this.panelPortChoice = n;
      return J({ ok: true, steps: this.selectedSteps || {}, port: n });
    }
    if (p.endsWith('/tg-begin') && request.method === 'POST') {
      if (this.status !== 'ready' || !this.beginResolver) return J({ ok: false, error: 'not ready' });
      if (!this.selectedSteps) this.selectedSteps = {};
      const r = this.beginResolver; this.beginResolver = null; r();
      return J({ ok: true });
    }
    if (p.endsWith('/tg-tail')) return J({ text: tail(this.log, Number(url.searchParams.get('n')) || 3400) });
    if (p.endsWith('/tg-result')) return J({ result: this.result || null });
    if (p.endsWith('/tg-exec') && request.method === 'POST') {
      const { data } = await request.json();
      if (!this.ssh || this.ssh.closed) return J({ ok: false, error: 'اتصال SSH فعالی وجود ندارد' });
      this.manualMode = true;
      const from = this.log.length;
      await this.ssh.write(String(data));
      let last = this.log.length; let idleSince = Date.now(); const t0 = Date.now();
      while (Date.now() - t0 < 9000) {
        await new Promise((r) => setTimeout(r, 300));
        if (this.log.length !== last) { last = this.log.length; idleSince = Date.now(); }
        else if (Date.now() - idleSince >= 1200) break;
      }
      return J({ ok: true, out: tail(this.log.slice(from), 3400) });
    }
    return null;
  },

  async tgCfg() {
    const now = Date.now();
    if (this._tgc !== undefined && now - (this._tgcAt || 0) < 20000) return this._tgc;
    try {
      const stub = this.env.SESSIONS.get(this.env.SESSIONS.idFromName('__cfg__'));
      const j = await (await stub.fetch('https://do/kv-get?k=tg')).json();
      this._tgc = (j && j.v && j.v.token && j.v.owner) ? j.v : null;
    } catch (e) { this._tgc = null; }
    this._tgcAt = now;
    return this._tgc;
  },

  async tgKvSet(k, v) {
    const stub = this.env.SESSIONS.get(this.env.SESSIONS.idFromName('__cfg__'));
    await stub.fetch('https://do/kv-set', { method: 'POST', body: JSON.stringify({ k, v }) });
  },

  tgQueue(fn) {
    this._tgq = (this._tgq || Promise.resolve()).then(fn).catch(() => {});
    try { if (this.state.waitUntil) this.state.waitUntil(this._tgq); } catch (e) {}
    return this._tgq;
  },

  // شروع Session (همزمان از handleStart صدا زده می‌شه)
  tgBeginSession(host) {
    this.tgActive = true; this.tgHost = host; this.tgMsgId = null; this.tgReadyMsgId = null; this._tgLastText = null; this._tgLast = 0;
    this.tgQueue(async () => {
      const c = await this.tgCfg();
      if (!c) { this.tgActive = false; return; }
      try { if (this.sid) await this.tgKvSet('active', this.sid); } catch (e) {}
      await this.tgFlushProgress();
    });
  },

  tgProgressText() {
    const icon = ICON[this.status] || 'ℹ️';
    return icon + ' <b>' + esc(this.status) + '</b>' + (this.tgHost ? ' — <code>' + esc(this.tgHost) + '</code>' : '') + '\n\n' + esc(String(this.detail || '').slice(0, 3000));
  },

  tgTouch() {
    if (!this.tgActive || this._tgTimer) return;
    const wait = Math.max(0, 3000 - (Date.now() - (this._tgLast || 0)));
    this._tgTimer = setTimeout(() => { this._tgTimer = null; this.tgQueue(() => this.tgFlushProgress()); }, wait);
  },

  async tgFlushProgress() {
    if (!this.tgActive) return;
    const c = await this.tgCfg();
    if (!c) { this.tgActive = false; return; }
    this._tgLast = Date.now();
    const text = this.tgProgressText();
    if (text === this._tgLastText) return;
    this._tgLastText = text;
    const kb = this.sid ? controlKeyboard(this.sid) : undefined;
    if (this.tgMsgId) {
      const r = await tgApi(c.token, 'editMessageText', { chat_id: c.owner, message_id: this.tgMsgId, text, parse_mode: 'HTML', reply_markup: kb });
      if (r && (r.ok || /not modified/i.test(r.description || ''))) return;
    }
    const r = await tgApi(c.token, 'sendMessage', { chat_id: c.owner, text, parse_mode: 'HTML', reply_markup: kb });
    if (r && r.ok) this.tgMsgId = r.result.message_id;
  },

  tgOnStatus(s) {
    if (!this.tgActive) return;
    if (s === 'ready') this.tgQueue(() => this.tgSendReady());
    else if (s === 'running') this.tgQueue(() => this.tgMarkBegun());
    else if (s === 'done') this.tgQueue(() => this.tgSendFinal());
    else if (s === 'error') this.tgQueue(() => this.tgSendError());
    else if (s === 'closed') this.tgQueue(async () => { await this.tgFlushProgress(); this.tgActive = false; });
    else this.tgTouch();
  },

  async tgSendReady() {
    await this.tgFlushProgress();
    const c = await this.tgCfg(); if (!c || !this.sid) return;
    const r = await tgApi(c.token, 'sendMessage', {
      chat_id: c.owner, parse_mode: 'HTML',
      text: '🟢 <b>به سرور وصل شد</b> — <code>' + esc(this.tgHost || '') + '</code>\nمراحلی که می‌خوای اجرا بشن رو انتخاب کن، بعد <b>Start</b> بزن:',
      reply_markup: stepsKeyboard(this.sid, this.selectedSteps || {}, this.panelPortChoice),
    });
    if (r && r.ok) this.tgReadyMsgId = r.result.message_id;
  },

  async tgMarkBegun() {
    const c = await this.tgCfg(); if (!c) return;
    if (this.tgReadyMsgId) {
      await tgApi(c.token, 'editMessageText', { chat_id: c.owner, message_id: this.tgReadyMsgId, text: '▶️ اجرای مراحل شروع شد.' });
      this.tgReadyMsgId = null;
    }
    await this.tgFlushProgress();
  },

  async tgSendFinal() {
    await this.tgFlushProgress();
    const c = await this.tgCfg(); if (!c) return;
    const res = this.result || '(نتیجه‌ای ثبت نشد)';
    await tgApi(c.token, 'sendMessage', { chat_id: c.owner, parse_mode: 'HTML', text: '✅ <b>کار تموم شد — نتیجه نهایی</b>\n<pre>' + esc(res.slice(0, 3600)) + '</pre>' });
    await tgSendDoc(c.token, c.owner, 'server-result.txt', res, 'server-result.txt — ' + (this.tgHost || ''));
  },

  async tgSendError() {
    await this.tgFlushProgress();
    const c = await this.tgCfg(); if (!c) return;
    await tgApi(c.token, 'sendMessage', {
      chat_id: c.owner, parse_mode: 'HTML',
      text: '❌ <b>اتوماسیون متوقف شد</b>\nآخرین خروجی کنسول:\n<pre>' + esc(tail(this.log, 1800) || '(خالی)') + '</pre>\nاتصال هنوز زنده‌ست؛ با ⌨️ کنسول می‌تونی دستی ادامه بدی.',
      reply_markup: this.sid ? controlKeyboard(this.sid) : undefined,
    });
  },
};
